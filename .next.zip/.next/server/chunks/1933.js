exports.id = 1933;
exports.ids = [1933];
exports.modules = {

/***/ 2799:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueDivHabituales": "estilosConversor_bloqueDivHabituales__qyizk",
	"bloqueTituloSuperior": "estilosConversor_bloqueTituloSuperior__74DMI",
	"tituloDivisaHabitual": "estilosConversor_tituloDivisaHabitual__PGZAm",
	"divisasHabituales": "estilosConversor_divisasHabituales__wvaj_",
	"bloqueDer": "estilosConversor_bloqueDer__1r6FN",
	"bloqueDerInput": "estilosConversor_bloqueDerInput__uyeMl",
	"contenedorInput": "estilosConversor_contenedorInput__CD1eT",
	"dolar": "estilosConversor_dolar__12tBB",
	"libra": "estilosConversor_libra__24Kgr",
	"imgMoneda": "estilosConversor_imgMoneda__HHN3D",
	"nombreMoneda": "estilosConversor_nombreMoneda__uLZQj",
	"contenedorInputSuperior": "estilosConversor_contenedorInputSuperior__BuNfk",
	"contenedorInputInferior": "estilosConversor_contenedorInputInferior__K07c_",
	"bloqueIzqInput": "estilosConversor_bloqueIzqInput__pY5w4",
	"select": "estilosConversor_select__r14rR",
	"select_monedas": "estilosConversor_select_monedas__tU665",
	"contenedor_list": "estilosConversor_contenedor_list__Iv4HH",
	"moneda": "estilosConversor_moneda__e9fmD",
	"nombre": "estilosConversor_nombre__oQa2Z",
	"select_activo": "estilosConversor_select_activo__YC9ym",
	"bandera": "estilosConversor_bandera__CBFAR",
	"botonSwith": "estilosConversor_botonSwith__PZb3B",
	"monedaInferior": "estilosConversor_monedaInferior__SUADS",
	"botonLlamarTienda": "estilosConversor_botonLlamarTienda__Wa2aZ",
	"contenedorDolarGoogle": "estilosConversor_contenedorDolarGoogle__k2s_b",
	"nombreDolarGoogle": "estilosConversor_nombreDolarGoogle__qalvU",
	"contenedorBanderaGoogle": "estilosConversor_contenedorBanderaGoogle___K2IY",
	"contenedorDatosGoogle": "estilosConversor_contenedorDatosGoogle__YcAvc",
	"contendorSectionDos": "estilosConversor_contendorSectionDos__HIxka",
	"contendorBloques": "estilosConversor_contendorBloques__pdSOR",
	"bloqueIzq": "estilosConversor_bloqueIzq__wQobJ",
	"contenedorInfo": "estilosConversor_contenedorInfo__irZOi",
	"botonComprar": "estilosConversor_botonComprar__bauEz",
	"botonVender": "estilosConversor_botonVender__H63uR",
	"botonActivo": "estilosConversor_botonActivo___r_D_",
	"contenedorBotones": "estilosConversor_contenedorBotones__4CKf_",
	"inputInferior": "estilosConversor_inputInferior__cN7AX"
};


/***/ }),

/***/ 5923:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__20XvF",
	"linea": "section_uno_linea__0lcC2",
	"bloqueIzq": "section_uno_bloqueIzq__QlI3k",
	"bloqueDer": "section_uno_bloqueDer__2R8Xy",
	"madridMobil": "section_uno_madridMobil__VmgRw",
	"botones": "section_uno_botones__L1FKI"
};


/***/ }),

/***/ 7707:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionDos": "section_2_contenedorSectionDos__uiBaz",
	"bloqueIzq": "section_2_bloqueIzq__f8APY",
	"bloqueDer": "section_2_bloqueDer___uubY",
	"contenedorInfo": "section_2_contenedorInfo__h9PEy",
	"contenedorBotones": "section_2_contenedorBotones__cGo6k",
	"botonComprar": "section_2_botonComprar__ZFxtL",
	"botonVender": "section_2_botonVender___2y0k",
	"botonActivo": "section_2_botonActivo__X23hE"
};


/***/ }),

/***/ 7720:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorContenidoUno": "sectionTres_contenedorContenidoUno__5MCgy",
	"contenedorSectionTres": "sectionTres_contenedorSectionTres__fi_eA",
	"linea": "sectionTres_linea__4EjPX",
	"bloqueDer": "sectionTres_bloqueDer__B31y0",
	"bloqueIzq": "sectionTres_bloqueIzq__TD30s",
	"contenedorInfoTres": "sectionTres_contenedorInfoTres____VSH",
	"cards": "sectionTres_cards__EicOu"
};


/***/ }),

/***/ 1921:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCuatro": "sectionCuatro_contenedorSectionCuatro__3E8i2",
	"bloqueIzq": "sectionCuatro_bloqueIzq__xfvXP",
	"bloqueDer": "sectionCuatro_bloqueDer__2XMVe",
	"linea": "sectionCuatro_linea__p36EV"
};


/***/ }),

/***/ 9692:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_uno_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5923);
/* harmony import */ var _section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_LocationOnOutlined__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3804);
/* harmony import */ var _mui_icons_material_LocationOnOutlined__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocationOnOutlined__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);


//import Image from "next/image";




const Section_uno = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().contenedorSectionUno),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().bloqueIzq),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        children: [
                            ciudad?.acf?.h1_sin_la_ciudad,
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().linea),
                                children: ciudad?.acf?.ciudad
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: ciudad?.acf?.parrafo_section_uno
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().botones),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_scroll__WEBPACK_IMPORTED_MODULE_3__.Link, {
                                to: "contenedorMapa",
                                smooth: true,
                                offset: -110,
                                spy: true,
                                duration: 500,
                                title: "texto",
                                passive: "true",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LocationOnOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {}),
                                    "encuentra tu tienda"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: `tel:${ciudad?.acf?.telefono}`,
                                title: "Tel\xe9fono",
                                children: "Llama gratis"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().bloqueDer),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                    src: "/assets/divisa.png",
                    alt: `Casas de cambio ${ciudad?.acf?.ciudad}`,
                    className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().madridMobil),
                    width: 480,
                    height: 364,
                    priority: true
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_uno);


/***/ }),

/***/ 9581:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Section_2_SectionDos)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/casasDeCambioDivisasCiudades/ConversorDivisa/estilosConversor.module.css
var estilosConversor_module = __webpack_require__(2799);
var estilosConversor_module_default = /*#__PURE__*/__webpack_require__.n(estilosConversor_module);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowDown"
var KeyboardArrowDown_ = __webpack_require__(4845);
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_);
// EXTERNAL MODULE: external "@mui/icons-material/PowerInput"
var PowerInput_ = __webpack_require__(8711);
var PowerInput_default = /*#__PURE__*/__webpack_require__.n(PowerInput_);
// EXTERNAL MODULE: external "@mui/icons-material/ImportExport"
var ImportExport_ = __webpack_require__(5579);
var ImportExport_default = /*#__PURE__*/__webpack_require__.n(ImportExport_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/componentes/casasDeCambioDivisasCiudades/ConversorDivisa/Comprar.js







//import { useFetchData } from "../../utilities/DataTiendas";
const Comprar = ({ ciudad , setSelectDivisa , selectDivisa  })=>{
    const nombreCiudad = ciudad?.acf?.ciudad_oro;
    const [data, setData] = (0,external_react_.useState)([]);
    const [select, setSelect] = (0,external_react_.useState)(null);
    const [loading, setLoading] = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        fetch(`https://panel.quickgold.es/archivos-cache/Fixing${nombreCiudad}.txt`, {
            cache: "no-cache"
        }).then((response)=>response.json()).then((response)=>{
            setData(response?.result?.Tarifas?.Divisas_Compra.reverse());
            setLoading(true);
        });
    }, []);
    const [valorMoneda, setValorMoneda] = (0,external_react_.useState)("0");
    const [DataAcronimo, setAcronimo] = (0,external_react_.useState)("");
    const [valorInput, setValorInput] = (0,external_react_.useState)("");
    const [switched, setSwitched] = (0,external_react_.useState)(null);
    const precioDividido = valorMoneda / 1000;
    const precioDividido2 = 1 / precioDividido;
    const valorFinal = valorInput * precioDividido;
    const valorFinal2 = valorInput / precioDividido;
    const captureCodigo = (e)=>{
        setAcronimo(e.target.dataset.acronimo);
        //setDataNombre(e.target.dataset.nombre);
        setValorMoneda(e.target.dataset.precio);
    };
    const MonedaSeleccionada = ()=>{
        setSelectDivisa(false);
    };
    const captureHabitual = (e)=>{
        setAcronimo(e.target.dataset.acronimo);
        setValorMoneda(e.target.dataset.precio);
        setSelectDivisa(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (estilosConversor_module_default()).bloqueDer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueDivHabituales,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueTituloSuperior,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h6", {
                                children: [
                                    "Conversor ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                    " de divisa"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (estilosConversor_module_default()).tituloDivisaHabitual,
                                children: "Divisas m\xe1s habituales"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).divisasHabituales,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).dolar,
                                onClick: (e)=>{
                                    captureHabitual(e);
                                    setSelect(false);
                                },
                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                "data-precio": data[1]?.Productos[0].Precio,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).imgMoneda,
                                        onClick: (e)=>{
                                            captureHabitual(e);
                                            setSelect(false);
                                        },
                                        "data-acronimo": data[1]?.Productos[0].Acronimo,
                                        "data-precio": data[1]?.Productos[0].Precio,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "/assets/banderaUSA.png",
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                "data-precio": data[1]?.Productos[0].Precio,
                                                width: 40,
                                                height: 30,
                                                alt: "Bandera USA"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                "data-precio": data[1]?.Productos[0].Precio,
                                                children: "USD"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).nombreMoneda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                "data-precio": data[1]?.Productos[0].Precio,
                                                children: "D\xf3lar USA"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                "data-precio": data[1]?.Productos[0].Precio,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    onClick: (e)=>{
                                                        captureHabitual(e);
                                                        setSelect(false);
                                                    },
                                                    "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                    "data-precio": data[1]?.Productos[0].Precio,
                                                    children: [
                                                        loading ? (data[1].Productos[0].Precio / 1000).toFixed(4) : "Cargando...",
                                                        " ",
                                                        "€"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).libra,
                                onClick: (e)=>{
                                    captureHabitual(e);
                                    setSelect(false);
                                },
                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                "data-precio": data[0]?.Productos[0].Precio,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).imgMoneda,
                                        onClick: (e)=>{
                                            captureHabitual(e);
                                            setSelect(false);
                                        },
                                        "data-acronimo": data[0]?.Productos[0].Acronimo,
                                        "data-precio": data[0]?.Productos[0].Precio,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "/assets/banderaGBP.png",
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                "data-precio": data[0]?.Productos[0].Precio,
                                                width: 40,
                                                height: 30,
                                                alt: "Bandera GBP"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                "data-precio": data[0]?.Productos[0].Precio,
                                                children: "GBP"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).nombreMoneda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                "data-precio": data[0]?.Productos[0].Precio,
                                                children: "Libra Esterlina"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                "data-precio": data[0]?.Productos[0].Precio,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    onClick: (e)=>{
                                                        captureHabitual(e);
                                                        setSelect(false);
                                                    },
                                                    "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                    "data-precio": data[0]?.Productos[0].Precio,
                                                    children: [
                                                        loading ? (data[0].Productos[0].Precio / 1000).toFixed(4) : "Cargando...",
                                                        " ",
                                                        "€"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).contenedorInputSuperior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).bloqueIzqInput,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (estilosConversor_module_default()).select,
                            onClick: ()=>{
                                setSelect(!select);
                            },
                            children: [
                                selectDivisa ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Seleccione Divisa"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                    ]
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        DataAcronimo,
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: select ? `${(estilosConversor_module_default()).select_monedas} ${(estilosConversor_module_default()).select_activo}` : `${(estilosConversor_module_default()).select_monedas}`,
                                    children: data.filter((currency)=>currency.Name !== "HRK" && currency.Name !== "DKK" && currency.Name !== "RUB" && currency.Name !== "NOK" && currency.Name !== "SEK").map((data, i)=>select ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (estilosConversor_module_default()).contenedor_list,
                                            "data-acronimo": data?.Productos[0].Acronimo,
                                            "data-precio": data?.Productos[0].Precio,
                                            onClick: (e)=>{
                                                captureCodigo(e);
                                                MonedaSeleccionada();
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (estilosConversor_module_default()).bandera,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        width: 35,
                                                        height: 23,
                                                        src: `/assets/img/${data?.Productos[0].Acronimo}.png`,
                                                        "data-acronimo": data?.Productos[0].Acronimo,
                                                        "data-precio": data?.Productos[0].Precio,
                                                        alt: data?.Productos[0].Acronimo
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: (estilosConversor_module_default()).moneda,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            "data-acronimo": data?.Productos[0].Acronimo,
                                                            "data-precio": data?.Productos[0].Precio,
                                                            children: data?.Productos[0].Acronimo
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: (estilosConversor_module_default()).nombre,
                                                            "data-acronimo": data?.Productos[0].Acronimo,
                                                            "data-precio": data?.Productos[0].Precio,
                                                            children: data?.Productos[0].Nombre
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, i) : "")
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueDerInput,
                        children: [
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInput,
                                children: [
                                    switched ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        style: {
                                            border: "none"
                                        },
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "0.00",
                                        inputMode: "numeric",
                                        readOnly: true,
                                        value: valorFinal2.toFixed(2)
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "0.00",
                                        inputMode: "numeric",
                                        className: (estilosConversor_module_default()).inputInferior,
                                        onChange: (event)=>setValorInput(event.target.value)
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: DataAcronimo
                                    })
                                ]
                            }),
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "1",
                                    DataAcronimo,
                                    " = ",
                                    precioDividido.toFixed(4),
                                    "EUR"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (estilosConversor_module_default()).botonSwith,
                children: /*#__PURE__*/ jsx_runtime_.jsx((ImportExport_default()), {
                    onClick: (e)=>{
                        setSwitched(!switched);
                    }
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).contenedorInputInferior,
                children: [
                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).monedaInferior,
                        children: "EUR"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueDerInput,
                        children: [
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInput,
                                children: [
                                    switched ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "Cantidad",
                                        inputMode: "numeric",
                                        className: (estilosConversor_module_default()).inputInferior,
                                        onChange: (event)=>setValorInput(event.target.value)
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "Cantidad",
                                        inputMode: "numeric",
                                        value: valorFinal.toFixed(2),
                                        readOnly: true,
                                        style: {
                                            border: "none"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "EUR"
                                    })
                                ]
                            }),
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "1EUR = ",
                                    precioDividido2.toFixed(4),
                                    DataAcronimo
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                className: (estilosConversor_module_default()).botonLlamarTienda,
                href: `tel:${ciudad?.acf?.telefono}`,
                children: [
                    "LLAMA GRATIS AL ",
                    ciudad?.acf?.telefono
                ]
            })
        ]
    });
};
/* harmony default export */ const ConversorDivisa_Comprar = (Comprar);

// EXTERNAL MODULE: ./src/componentes/casasDeCambioDivisasCiudades/Section_2/section_2.module.css
var section_2_module = __webpack_require__(7707);
var section_2_module_default = /*#__PURE__*/__webpack_require__.n(section_2_module);
;// CONCATENATED MODULE: ./src/componentes/casasDeCambioDivisasCiudades/ConversorDivisa/Vender.js







const Vender_Comprar = ({ ciudad , setSelectDivisa , selectDivisa  })=>{
    const nombreCiudad = ciudad?.acf?.ciudad_oro;
    const [data, setData] = (0,external_react_.useState)([]);
    const [loading, setLoading] = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        fetch(`https://panel.quickgold.es/archivos-cache/Fixing${nombreCiudad}.txt`, {
            cache: "no-cache"
        }).then((response)=>response.json()).then((response)=>{
            setData(response?.result?.Tarifas?.Divisas_Venta.reverse());
            setLoading(true);
        });
    }, []);
    const [switched, setSwitched] = (0,external_react_.useState)(null);
    const [select, setSelect] = (0,external_react_.useState)(null);
    const [valorMoneda, setValorMoneda] = (0,external_react_.useState)("0");
    const [DataAcronimo, setAcronimo] = (0,external_react_.useState)(/*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}));
    const [valorInput, setValorInput] = (0,external_react_.useState)("");
    const precioDividido = valorMoneda / 1000;
    const precioDividido2 = 1 / precioDividido;
    const valorFinal = valorInput * precioDividido;
    const valorFinal2 = valorInput / precioDividido;
    const captureCodigo = (e)=>{
        setAcronimo(e.target.dataset.acronimo);
        //setDataNombre(e.target.dataset.nombre);
        setValorMoneda(e.target.dataset.precio);
    };
    const MonedaSeleccionada = ()=>{
        setSelectDivisa(false);
    };
    const captureHabitual = (e)=>{
        setAcronimo(e.target.dataset.acronimo);
        setValorMoneda(e.target.dataset.precio);
        setSelectDivisa(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (estilosConversor_module_default()).bloqueDer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueDivHabituales,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueTituloSuperior,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h6", {
                                children: [
                                    "Conversor ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                    " de divisa"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (estilosConversor_module_default()).tituloDivisaHabitual,
                                children: "Divisas m\xe1s habituales"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).divisasHabituales,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).dolar,
                                onClick: (e)=>{
                                    captureHabitual(e);
                                    setSelect(false);
                                },
                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                "data-precio": data[1]?.Productos[0].Precio,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).imgMoneda,
                                        onClick: (e)=>{
                                            captureHabitual(e);
                                            setSelect(false);
                                        },
                                        "data-acronimo": data[1]?.Productos[0].Acronimo,
                                        "data-precio": data[1]?.Productos[0].Precio,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "/assets/banderaUSA.png",
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                "data-precio": data[1]?.Productos[0].Precio,
                                                width: 40,
                                                height: 30,
                                                alt: "Bandera USA"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                "data-precio": data[1]?.Productos[0].Precio,
                                                children: "USD"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).nombreMoneda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                "data-precio": data[1]?.Productos[0].Precio,
                                                children: "D\xf3lar USA"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                "data-precio": data[1]?.Productos[0].Precio,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    onClick: (e)=>{
                                                        captureHabitual(e);
                                                        setSelect(false);
                                                    },
                                                    "data-acronimo": data[1]?.Productos[0].Acronimo,
                                                    "data-precio": data[1]?.Productos[0].Precio,
                                                    children: [
                                                        loading ? (data[1]?.Productos[0].Precio / 1000).toFixed(4) : "Cargando...",
                                                        " ",
                                                        "€"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).libra,
                                onClick: (e)=>{
                                    captureHabitual(e);
                                    setSelect(false);
                                },
                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                "data-precio": data[0]?.Productos[0].Precio,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).imgMoneda,
                                        onClick: (e)=>{
                                            captureHabitual(e);
                                            setSelect(false);
                                        },
                                        "data-acronimo": data[0]?.Productos[0].Acronimo,
                                        "data-precio": data[0]?.Productos[0].Precio,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "/assets/banderaGBP.png",
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                "data-precio": data[0]?.Productos[0].Precio,
                                                width: 40,
                                                height: 30,
                                                alt: "Bandera GBP"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                "data-precio": data[0]?.Productos[0].Precio,
                                                children: "GBP"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).nombreMoneda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                "data-precio": data[0]?.Productos[0].Precio,
                                                children: "Libra Esterlina"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    setSelect(false);
                                                },
                                                "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                "data-precio": data[0]?.Productos[0].Precio,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    onClick: (e)=>{
                                                        captureHabitual(e);
                                                        setSelect(false);
                                                    },
                                                    "data-acronimo": data[0]?.Productos[0].Acronimo,
                                                    "data-precio": data[0]?.Productos[0].Precio,
                                                    children: [
                                                        loading ? (data[0]?.Productos[0].Precio / 1000).toFixed(4) : "Cargando...",
                                                        " ",
                                                        "€"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).contenedorInputSuperior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).bloqueIzqInput,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (estilosConversor_module_default()).select,
                            onClick: ()=>{
                                setSelect(!select);
                            },
                            children: [
                                selectDivisa ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Seleccione Divisa"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                    ]
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        DataAcronimo,
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: select ? `${(estilosConversor_module_default()).select_monedas} ${(estilosConversor_module_default()).select_activo}` : `${(estilosConversor_module_default()).select_monedas}`,
                                    children: data?.filter((currency)=>currency.Name !== "HRK").map((data, i)=>select ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (estilosConversor_module_default()).contenedor_list,
                                            "data-acronimo": data?.Productos[0].Acronimo,
                                            "data-precio": data?.Productos[0].Precio,
                                            onClick: (e)=>{
                                                captureCodigo(e);
                                                MonedaSeleccionada();
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (estilosConversor_module_default()).bandera,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        width: 35,
                                                        height: 23,
                                                        src: `/assets/img/${data?.Productos[0].Acronimo}.png`,
                                                        "data-acronimo": data?.Productos[0].Acronimo,
                                                        "data-precio": data?.Productos[0].Precio,
                                                        alt: data?.Productos[0].Acronimo
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: (estilosConversor_module_default()).moneda,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            "data-acronimo": data?.Productos[0].Acronimo,
                                                            "data-precio": data?.Productos[0].Precio,
                                                            children: data?.Productos[0].Acronimo
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: (estilosConversor_module_default()).nombre,
                                                            "data-acronimo": data?.Productos[0].Acronimo,
                                                            "data-precio": data?.Productos[0].Precio,
                                                            children: data?.Productos[0].Nombre
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, i) : "")
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueDerInput,
                        children: [
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInput,
                                children: [
                                    switched ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        style: {
                                            border: "none"
                                        },
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "0.00",
                                        inputMode: "numeric",
                                        readOnly: true,
                                        value: valorFinal.toFixed(2)
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "0.00",
                                        inputMode: "numeric",
                                        className: (estilosConversor_module_default()).inputInferior,
                                        onChange: (event)=>setValorInput(event.target.value)
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "EUR"
                                    })
                                ]
                            }),
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "1EUR = ",
                                    precioDividido2.toFixed(4),
                                    DataAcronimo
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (estilosConversor_module_default()).botonSwith,
                children: /*#__PURE__*/ jsx_runtime_.jsx((ImportExport_default()), {
                    onClick: (e)=>{
                        setSwitched(!switched);
                    }
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).contenedorInputInferior,
                children: [
                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).monedaInferior,
                        children: DataAcronimo
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueDerInput,
                        children: [
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInput,
                                children: [
                                    switched ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "Cantidad",
                                        inputMode: "numeric",
                                        className: (estilosConversor_module_default()).inputInferior,
                                        onChange: (event)=>setValorInput(event.target.value)
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "Cantidad",
                                        inputMode: "numeric",
                                        value: valorFinal2.toFixed(2),
                                        readOnly: true,
                                        style: {
                                            border: "none"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: DataAcronimo
                                    })
                                ]
                            }),
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "1",
                                    DataAcronimo,
                                    " = ",
                                    precioDividido.toFixed(4),
                                    "EUR"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                className: (estilosConversor_module_default()).botonLlamarTienda,
                href: `tel:${ciudad?.acf?.telefono}`,
                children: [
                    "LLAMA GRATIS AL ",
                    ciudad?.acf?.telefono
                ]
            })
        ]
    });
};
/* harmony default export */ const Vender = (Vender_Comprar);

;// CONCATENATED MODULE: ./src/componentes/casasDeCambioDivisasCiudades/Section_2/SectionDos.js






const SectionDos = ({ ciudad , comprar  })=>{
    const [switched, setSwitched] = (0,external_react_.useState)(null);
    const [selectDivisa, setSelectDivisa] = (0,external_react_.useState)(true);
    const url = ciudad?.acf?.ciudad_minuscula;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            backgroundImage: `url(/assets/degradado${url}.png)`
        },
        className: (section_2_module_default()).contenedorSectionDos,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_2_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/assets/imagen_calc.png",
                            alt: "Logo Divisa",
                            width: 80,
                            height: 80,
                            priority: true
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_2_module_default()).contenedorInfo,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    "Cambio de Divisas ",
                                    ciudad?.acf?.ciudad
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "Conoce el tipo de cambio en nuestras",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    " casas de cambio de moneda en ",
                                    ciudad?.acf?.ciudad,
                                    "."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (section_2_module_default()).contenedorBotones,
                        children: comprar ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: ()=>{
                                        setSwitched(false);
                                        setSelectDivisa(true);
                                    },
                                    className: switched ? `${(section_2_module_default()).botonComprar}` : `${(section_2_module_default()).botonComprar} ${(section_2_module_default()).botonActivo}`,
                                    children: "QUIERO EUROS"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: switched ? `${(section_2_module_default()).botonVender} ${(section_2_module_default()).botonActivo}` : ` ${(section_2_module_default()).botonVender}`,
                                    onClick: ()=>{
                                        setSwitched(true);
                                        setSelectDivisa(true);
                                    },
                                    children: "TENGO EUROS"
                                })
                            ]
                        }) : null
                    })
                ]
            }),
            switched ? /*#__PURE__*/ jsx_runtime_.jsx(Vender, {
                ciudad: ciudad,
                setSelectDivisa: setSelectDivisa,
                selectDivisa: selectDivisa
            }) : /*#__PURE__*/ jsx_runtime_.jsx(ConversorDivisa_Comprar, {
                ciudad: ciudad,
                setSelectDivisa: setSelectDivisa,
                selectDivisa: selectDivisa
            })
        ]
    });
};
/* harmony default export */ const Section_2_SectionDos = (SectionDos);


/***/ }),

/***/ 5991:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7720);
/* harmony import */ var _sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2__);



const SectionTres = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorSectionTres),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorContenidoUno),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().bloqueIzq),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                children: [
                                    ciudad?.acf?.texto_section_tres?.titulo_del_bloque_izq,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().linea),
                                        children: [
                                            " ",
                                            ciudad?.acf?.ciudad,
                                            "?"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            ciudad?.acf?.texto_section_tres?.texto_bloque_izq,
                                            " "
                                        ]
                                    }),
                                    ciudad?.acf?.texto_section_tres?.texto_bloque_izq_negrita
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().bloqueDer),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: ciudad?.acf?.texto_section_tres?.titulo_bloque_der
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: ciudad?.acf?.texto_section_tres?.texto_bloque_der
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                children: [
                    ciudad?.acf?.textos_section_cuatro?.titulo_bloque_cuatro_parte_uno,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().linea),
                        children: ciudad?.acf?.ciudad
                    }),
                    " ",
                    ciudad?.acf?.textos_section_cuatro?.titulo_bloque_cuatro_parte_dos
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorInfoTres),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().cards),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: ciudad?.acf?.textos_section_cuatro?.texto_cuadro_uno
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().cards),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: ciudad?.acf?.textos_section_cuatro?.texto_cuadro_dos
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().cards),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: ciudad?.acf?.textos_section_cuatro?.texto_cuadro_tres
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionTres);


/***/ }),

/***/ 7867:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sectionCuatro_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1921);
/* harmony import */ var _sectionCuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_sectionCuatro_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);


//import Image from "next/image";


const SectionCuatro = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_sectionCuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionCuatro),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sectionCuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueIzq),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            ciudad?.acf?.texto_section_con_imagen?.titulo_bloqueizq,
                            " ",
                            "",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_sectionCuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().linea),
                                children: ciudad?.acf?.ciudad
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: ciudad?.acf?.texto_section_con_imagen?.texto_bloque_izq
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sectionCuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueDer),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: `/assets/casa-cambio-${ciudad?.acf?.ciudad_minuscula}.webp`,
                    alt: `Cambiar Dólares a Euros ${ciudad?.acf?.ciudad}`,
                    className: (_sectionCuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().Image),
                    width: 480,
                    height: 390
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionCuatro);


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ })

};
;