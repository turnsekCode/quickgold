exports.id = 8626;
exports.ids = [8626];
exports.modules = {

/***/ 6062:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorAccordion": "accordion_contenedorAccordion__wR88_",
	"tituloServicio": "accordion_tituloServicio__vL3Bl",
	"subTituloServicio": "accordion_subTituloServicio__dP9qv",
	"contenedorTituloServicio": "accordion_contenedorTituloServicio__w0igv",
	"accordionActivo": "accordion_accordionActivo__cFRWZ",
	"details": "accordion_details__I_w_T",
	"rayaAdorno": "accordion_rayaAdorno__XWIyl",
	"textoMenos": "accordion_textoMenos__zJUK8"
};


/***/ }),

/***/ 9605:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorBannerUno": "bannerPromoDos_contenedorBannerUno__xsmnM",
	"bannerDesktop": "bannerPromoDos_bannerDesktop__4ie_G",
	"bannerMobil": "bannerPromoDos_bannerMobil__potrp"
};


/***/ }),

/***/ 9086:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorBannerUno": "bannerPromoUno_contenedorBannerUno__DQlbR",
	"bannerDesktop": "bannerPromoUno_bannerDesktop__Bxbu8",
	"bannerMobil": "bannerPromoUno_bannerMobil__t7iWc"
};


/***/ }),

/***/ 9698:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorBannerWallapop": "bannerWallapop_contenedorBannerWallapop__leBAV",
	"bannerWallapopDesktop": "bannerWallapop_bannerWallapopDesktop__RTGQa"
};


/***/ }),

/***/ 5711:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorConversor": "conversor_contenedorConversor__sudjN",
	"contenedor": "conversor_contenedor__Kc3Ij",
	"conversorTitulo": "conversor_conversorTitulo__DnYoj",
	"conversorTexto": "conversor_conversorTexto__1feXN",
	"botonLlamarTienda": "conversor_botonLlamarTienda__WFlVd",
	"contenedorAmbosBloquesEmpeno": "conversor_contenedorAmbosBloquesEmpeno__2Ff6v",
	"contenedorBloqueEmpeno": "conversor_contenedorBloqueEmpeno__AP524",
	"contenedorTresBloques": "conversor_contenedorTresBloques__eWaCW",
	"contenedorBloques": "conversor_contenedorBloques__1UTkI",
	"bloqueIzq": "conversor_bloqueIzq__POe9G",
	"bloqueDer": "conversor_bloqueDer__gSYRU",
	"contenedorImagen": "conversor_contenedorImagen__gU352",
	"contenedorPrecioOro": "conversor_contenedorPrecioOro__BkR0S",
	"contenedorPrecioPlata": "conversor_contenedorPrecioPlata__8zqJ5",
	"contenedorBloqueMasDe": "conversor_contenedorBloqueMasDe__XXUuG",
	"contenedorPrecios": "conversor_contenedorPrecios__GcsBO",
	"precios": "conversor_precios__Urqy5",
	"contenedorInfo": "conversor_contenedorInfo__iAA9p",
	"primerParrafo": "conversor_primerParrafo__8LxhE",
	"segundoParrafo": "conversor_segundoParrafo__yXemb",
	"ejemplo": "conversor_ejemplo__oAhNj",
	"tercerParrafo": "conversor_tercerParrafo__oyUeH",
	"cuartoParrafo": "conversor_cuartoParrafo__jYicw",
	"contenedorBotonLlamar": "conversor_contenedorBotonLlamar__RqtSX",
	"preciosDelOro": "conversor_preciosDelOro__S4PPj",
	"contenedorBotones": "conversor_contenedorBotones__uZmat",
	"botonUno": "conversor_botonUno__Mkcgc",
	"botonDos": "conversor_botonDos__ACxOs",
	"botonActivo": "conversor_botonActivo__v7wGO"
};


/***/ }),

/***/ 9657:
/***/ ((module) => {

// Exports
module.exports = {
	"botonLlamar": "botonLamarFijo_botonLlamar__ywd7X"
};


/***/ }),

/***/ 9911:
/***/ ((module) => {

// Exports
module.exports = {
	"botonLlamar": "botonesLlamar_botonLlamar__c3u_8",
	"botonWhatsapp": "botonesLlamar_botonWhatsapp__2CULg",
	"contenedorBotones": "botonesLlamar_contenedorBotones__oTO56"
};


/***/ }),

/***/ 762:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorBreadcrumbs": "breadcrumbs_contenedorBreadcrumbs__oEfH7",
	"breadcrumbsRaiz": "breadcrumbs_breadcrumbsRaiz__v5kVj",
	"sectionBreadcrumbs": "breadcrumbs_sectionBreadcrumbs__jsGFF"
};


/***/ }),

/***/ 8612:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorHtml": "html_contenedorHtml__h65BV"
};


/***/ }),

/***/ 3460:
/***/ ((module) => {

// Exports
module.exports = {
	"botonLlamarTienda": "estilosConversor_botonLlamarTienda__OYSNc",
	"botonComprar": "estilosConversor_botonComprar__ha0Zn",
	"botonVender": "estilosConversor_botonVender__0LNLU",
	"botonActivo": "estilosConversor_botonActivo__RAfdw",
	"contenedorBotones": "estilosConversor_contenedorBotones__z4waJ",
	"bloqueCalculadora": "estilosConversor_bloqueCalculadora__mAlFL",
	"select": "estilosConversor_select__qtRpq",
	"select_monedas": "estilosConversor_select_monedas__z_APQ",
	"select_activo": "estilosConversor_select_activo__wy5D2",
	"contenedor_list": "estilosConversor_contenedor_list__ZmsWq",
	"moneda": "estilosConversor_moneda__X78ch",
	"nombre": "estilosConversor_nombre__2qR4i",
	"acronimo": "estilosConversor_acronimo__Q0mn0",
	"bandera": "estilosConversor_bandera__V42nK",
	"contenedorInputs": "estilosConversor_contenedorInputs__kn_tM",
	"inputSuperior": "estilosConversor_inputSuperior__qEHU_",
	"inputInferior": "estilosConversor_inputInferior__cmQCu",
	"contenedorTipoCambio": "estilosConversor_contenedorTipoCambio__geIoK",
	"tipoCambioIzq": "estilosConversor_tipoCambioIzq__5brW9",
	"tipoCambioDer": "estilosConversor_tipoCambioDer__XZ2mN",
	"bloqueCalculadoraTextoSup": "estilosConversor_bloqueCalculadoraTextoSup__mAe6A",
	"bloqueBotonLamar": "estilosConversor_bloqueBotonLamar__UogBa",
	"bloqueBotonLamarTexto": "estilosConversor_bloqueBotonLamarTexto__4TCMR",
	"bloqueDivisaHabitualTexto": "estilosConversor_bloqueDivisaHabitualTexto__dxBcS",
	"bloqueDivisaHabitual": "estilosConversor_bloqueDivisaHabitual__vpT0A",
	"contenedorDivisaHabitual": "estilosConversor_contenedorDivisaHabitual__BWH5C",
	"bloqueDivisaHabitual1": "estilosConversor_bloqueDivisaHabitual1__QdW3u",
	"bloqueDivisaHabitual2": "estilosConversor_bloqueDivisaHabitual2__UDFBc",
	"bloqueDivisaHabitual3": "estilosConversor_bloqueDivisaHabitual3__C_MW_",
	"bloqueDivisaHabitual4": "estilosConversor_bloqueDivisaHabitual4__6H8_N",
	"bloqueDivisaHabitual5": "estilosConversor_bloqueDivisaHabitual5__mwn1B",
	"bloqueDivisaHabitual6": "estilosConversor_bloqueDivisaHabitual6__Wozcb",
	"bloqueIzq": "estilosConversor_bloqueIzq__4N1Ut",
	"bloqueDer": "estilosConversor_bloqueDer__1vasI",
	"acronimoTexto": "estilosConversor_acronimoTexto__BlE4L"
};


/***/ }),

/***/ 7741:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorConversor": "conversor_contenedorConversor__CWQNx",
	"conversorTitulo": "conversor_conversorTitulo__e9dzq",
	"conversorTexto": "conversor_conversorTexto__xGwjn",
	"botonLlamarTienda": "conversor_botonLlamarTienda__xJhg1",
	"contenedorAmbosBloquesOro": "conversor_contenedorAmbosBloquesOro__jB1gn",
	"contenedorBloqueSuperior": "conversor_contenedorBloqueSuperior__YnWEZ",
	"contenedorBloqueSuperiorPlata": "conversor_contenedorBloqueSuperiorPlata__EY1JJ",
	"botones": "conversor_botones__FX1Pe",
	"button": "conversor_button__xtM1c",
	"botonActivo": "conversor_botonActivo__GDVtR",
	"contenedorPrecios": "conversor_contenedorPrecios__3a5F_",
	"contenedorPreciosPlata": "conversor_contenedorPreciosPlata__S6k8H",
	"contenedorprecioDestacado": "conversor_contenedorprecioDestacado__qdZZi",
	"precioDestacado": "conversor_precioDestacado___DI6i",
	"contenedorprecioDestacadoPlata": "conversor_contenedorprecioDestacadoPlata__fdj3a",
	"precioDestacadoPlata": "conversor_precioDestacadoPlata__V5zOJ",
	"masde": "conversor_masde__aYJtx",
	"precio18k": "conversor_precio18k__tEwgL",
	"precio999": "conversor_precio999__X6QR3",
	"kilates": "conversor_kilates__9VvK6",
	"contenedorOtrosPrecios": "conversor_contenedorOtrosPrecios__VTwI9",
	"OtrosPrecios": "conversor_OtrosPrecios__wCKTc",
	"precio": "conversor_precio__8VOV7",
	"preciok": "conversor_preciok__pT5WY",
	"contenedorCalculadora": "conversor_contenedorCalculadora__IchYz",
	"contenedorSelect": "conversor_contenedorSelect__DEQ9M",
	"Select": "conversor_Select___Zv_e",
	"input": "conversor_input__z6wsX",
	"tituloInferior": "conversor_tituloInferior__m_q30",
	"precioFinal": "conversor_precioFinal__gXXE0",
	"promocion": "conversor_promocion__O5qwK",
	"linea": "conversor_linea__GME8W",
	"contenedorPrecioPlata": "conversor_contenedorPrecioPlata__PgLDe"
};


/***/ }),

/***/ 7578:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorAmbosTablaLingotes": "Lingotes_contenedorAmbosTablaLingotes__shiHb",
	"botonLlamar": "Lingotes_botonLlamar__GW28P",
	"contenedorImagen": "Lingotes_contenedorImagen__Vu9yH",
	"nombrePrecio": "Lingotes_nombrePrecio__col3a",
	"oroFino": "Lingotes_oroFino__HDfMs",
	"medidaBlister": "Lingotes_medidaBlister__DM_hB",
	"separador": "Lingotes_separador__PqPwb",
	"contenedorTablas": "Lingotes_contenedorTablas__tr4sr",
	"contenedorConversor": "Lingotes_contenedorConversor__F5MGu",
	"conversorTitulo": "Lingotes_conversorTitulo__uohOh",
	"conversorTexto": "Lingotes_conversorTexto__dwENu",
	"botonLlamarTienda": "Lingotes_botonLlamarTienda__6a7yO"
};


/***/ }),

/***/ 8874:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Home_main__EtNt2",
	"contenedorMapaVisible": "Home_contenedorMapaVisible__piXgh",
	"contenedorSeccionUnoDos": "Home_contenedorSeccionUnoDos__pegsP",
	"contenedorMapaVisibleCasaCambio": "Home_contenedorMapaVisibleCasaCambio__A5Ti8"
};


/***/ }),

/***/ 7215:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AccordionServicios)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: external "@mui/material/Accordion"
var Accordion_ = __webpack_require__(9409);
var Accordion_default = /*#__PURE__*/__webpack_require__.n(Accordion_);
// EXTERNAL MODULE: external "@mui/material/AccordionSummary"
var AccordionSummary_ = __webpack_require__(4604);
var AccordionSummary_default = /*#__PURE__*/__webpack_require__.n(AccordionSummary_);
// EXTERNAL MODULE: external "@mui/material/AccordionDetails"
var AccordionDetails_ = __webpack_require__(8279);
var AccordionDetails_default = /*#__PURE__*/__webpack_require__.n(AccordionDetails_);
// EXTERNAL MODULE: external "@mui/icons-material/ArrowDropDown"
var ArrowDropDown_ = __webpack_require__(765);
var ArrowDropDown_default = /*#__PURE__*/__webpack_require__.n(ArrowDropDown_);
// EXTERNAL MODULE: ./src/componentes/AccordionServicios/accordion.module.css
var accordion_module = __webpack_require__(6062);
var accordion_module_default = /*#__PURE__*/__webpack_require__.n(accordion_module);
// EXTERNAL MODULE: ./src/componentes/ConversorPlata/conversor.module.css
var conversor_module = __webpack_require__(7741);
var conversor_module_default = /*#__PURE__*/__webpack_require__.n(conversor_module);
;// CONCATENATED MODULE: ./src/componentes/ConversorPlata/CalculadoraOro.js



const CalculadoraOro = ({ ciudad  })=>{
    const nombreCiudad = ciudad?.acf?.ciudad_oro;
    const [data, setData] = (0,external_react_.useState)([]);
    const [loading, setLoading] = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        fetch(`https://panel.quickgold.es/archivos-cache/Fixing${nombreCiudad}.txt`, {
            cache: "no-cache"
        }).then((response)=>response.json()).then((response)=>{
            setData(response);
            setLoading(true);
        });
    }, []);
    const [valorInput, setValorInput] = (0,external_react_.useState)("0.00");
    const [valorSelect, setValorSelect] = (0,external_react_.useState)("0.00");
    const [masDe, setMasDe] = (0,external_react_.useState)(true);
    const precio24k = data?.result?.Tarifas?.Oro[12].Productos[0].Precio / 1000;
    const precio18k = data?.result?.Tarifas?.Oro[2].Productos[0].Precio / 1000;
    const precio14k = data?.result?.Tarifas?.Oro[10].Productos[0].Precio / 1000;
    const masDeOro = ciudad?.acf?.precio_mas_de_oro;
    const precioMas24k = (precio24k + parseFloat(masDeOro)).toFixed(2);
    const precioMas18k = (precio18k + parseFloat(masDeOro)).toFixed(2);
    const precioMas14k = (precio14k + parseFloat(masDeOro)).toFixed(2);
    const paraMasOro = ciudad?.acf?.para_mas_de_oro;
    const valorSelectSuma = parseFloat(valorSelect) + parseFloat(masDeOro);
    const valorSelectNormal = parseFloat(valorSelect);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (conversor_module_default()).contenedorAmbosBloquesOro,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (conversor_module_default()).contenedorBloqueSuperior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).botones,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                onClick: ()=>{
                                    setMasDe(true);
                                },
                                className: masDe ? `${(conversor_module_default()).button} ${(conversor_module_default()).botonActivo}` : `${(conversor_module_default()).button} `,
                                children: [
                                    "M\xe1s de ",
                                    paraMasOro,
                                    "g"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                onClick: ()=>{
                                    setMasDe(false);
                                },
                                className: masDe ? `${(conversor_module_default()).button} ` : `${(conversor_module_default()).button} ${(conversor_module_default()).botonActivo}`,
                                children: [
                                    "Menos de ",
                                    paraMasOro,
                                    "g"
                                ]
                            })
                        ]
                    }),
                    masDe ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).contenedorPrecios,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (conversor_module_default()).contenedorprecioDestacado,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (conversor_module_default()).precioDestacado,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (conversor_module_default()).kilates,
                                            children: "18K"
                                        }),
                                        !loading ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (conversor_module_default()).precio18k,
                                            children: "Cargando"
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: (conversor_module_default()).precio18k,
                                            children: [
                                                precioMas18k,
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "€/g"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (conversor_module_default()).contenedorOtrosPrecios,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (conversor_module_default()).OtrosPrecios,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).preciok,
                                                children: "24K"
                                            }),
                                            !loading ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).precio,
                                                children: "Cargando"
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (conversor_module_default()).precio,
                                                children: [
                                                    precioMas24k,
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (conversor_module_default()).OtrosPrecios,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).preciok,
                                                children: "14K"
                                            }),
                                            !loading ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).precio,
                                                children: "Cargando"
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (conversor_module_default()).precio,
                                                children: [
                                                    precioMas14k,
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).contenedorPrecios,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (conversor_module_default()).contenedorprecioDestacado,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (conversor_module_default()).precioDestacado,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (conversor_module_default()).kilates,
                                            children: "18K"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: (conversor_module_default()).precio18k,
                                            children: [
                                                precio18k.toFixed(2),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "€/g"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (conversor_module_default()).contenedorOtrosPrecios,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (conversor_module_default()).OtrosPrecios,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).preciok,
                                                children: "24K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (conversor_module_default()).precio,
                                                children: [
                                                    precio24k.toFixed(2),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (conversor_module_default()).OtrosPrecios,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).preciok,
                                                children: "14K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (conversor_module_default()).precio,
                                                children: [
                                                    precio14k.toFixed(2),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (conversor_module_default()).contenedorCalculadora,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        children: [
                            "\xbfCu\xe1nto ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "te vamos a dar"
                            }),
                            " por tus joyas?"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).contenedorSelect,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (conversor_module_default()).Select,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Selecciona kilates"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                        onChange: (e)=>{
                                            setValorSelect(e.target.value);
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: 0,
                                                children: "---"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: precio14k.toFixed(2),
                                                children: "14K"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: precio18k.toFixed(2),
                                                children: "18K"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: precio24k.toFixed(2),
                                                children: "24K"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (conversor_module_default()).input,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Introduce gramos"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "number",
                                        placeholder: "Cantidad",
                                        onChange: (event)=>setValorInput(event.target.value)
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "g"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (conversor_module_default()).tituloInferior,
                        children: "Te daremos por tu oro"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (conversor_module_default()).precioFinal,
                        children: [
                            valorInput >= parseFloat(paraMasOro) ? (valorInput * valorSelectSuma).toLocaleString("es", {
                                style: "currency",
                                currency: "EUR"
                            }) : (valorInput * valorSelectNormal).toLocaleString("es", {
                                style: "currency",
                                currency: "EUR"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: (conversor_module_default()).promocion,
                children: "Promoci\xf3n Online"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                title: `Llamar a Quickgold ${ciudad?.acf?.ciudad_landing}`,
                className: (conversor_module_default()).botonLlamarTienda,
                href: `tel:${ciudad?.acf?.telefono}`,
                children: "LLAMA GRATIS"
            })
        ]
    });
};
/* harmony default export */ const ConversorPlata_CalculadoraOro = (CalculadoraOro);

// EXTERNAL MODULE: ./src/componentes/ConversorDivisa/estilosConversor.module.css
var estilosConversor_module = __webpack_require__(3460);
var estilosConversor_module_default = /*#__PURE__*/__webpack_require__.n(estilosConversor_module);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowDown"
var KeyboardArrowDown_ = __webpack_require__(4845);
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_);
;// CONCATENATED MODULE: ./src/componentes/ConversorDivisa/Comprar.js




function NuevoConversor2({ ciudad , setSelectDivisa , selectDivisa  }) {
    const nombreCiudad = ciudad?.acf?.ciudad_oro;
    const [currencyOptions, setCurrencyOptions] = (0,external_react_.useState)([]);
    const [fromAcronimo, setFromAcronimo] = (0,external_react_.useState)("");
    const [nombreDivisa, setNombreDivisa] = (0,external_react_.useState)("");
    const [exchangeRate, setExchangeRate] = (0,external_react_.useState)("");
    const [amount, setAmount] = (0,external_react_.useState)("");
    const [amountInFromCurrency, setAmountInFromCurrency] = (0,external_react_.useState)(true);
    const [select, setSelect] = (0,external_react_.useState)(null);
    const precioDividido2 = 1 / exchangeRate;
    let toAmount, fromAmount;
    if (amountInFromCurrency) {
        fromAmount = amount;
        toAmount = (amount * exchangeRate).toFixed(2);
    } else {
        toAmount = amount;
        fromAmount = (amount / exchangeRate).toFixed(2);
    }
    (0,external_react_.useEffect)(()=>{
        fetch(`https://panel.quickgold.es/archivos-cache/Fixing${nombreCiudad}.txt`).then((res)=>res.json()).then((data)=>{
            setCurrencyOptions(data?.result?.Tarifas?.Divisas_Compra.reverse());
        });
    }, []);
    function handleFromAmountChange(e) {
        setAmount(e.target.value);
        setAmountInFromCurrency(true);
    }
    function handleToAmountChange(e) {
        setAmount(e.target.value);
        setAmountInFromCurrency(false);
    }
    function onChangeCurrency2(e) {
        setNombreDivisa(e.target.dataset.nombre);
        setExchangeRate(e.target.dataset.precio);
        setFromAcronimo(e.target.dataset.acronimo);
        setSelectDivisa(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (estilosConversor_module_default()).contenedorCalculadora,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueCalculadora,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (estilosConversor_module_default()).bloqueCalculadoraTextoSup,
                        children: "Selecciona divisa para ver el tipo de cambio"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).select,
                        onClick: ()=>{
                            setSelect(!select);
                        },
                        children: [
                            selectDivisa ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Seleccione Divisa"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    fromAcronimo,
                                    " | ",
                                    nombreDivisa,
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: select ? `${(estilosConversor_module_default()).select_monedas} ${(estilosConversor_module_default()).select_activo}` : `${(estilosConversor_module_default()).select_monedas}`,
                                children: currencyOptions?.filter((currency)=>currency.Name !== "HRK" && currency.Name !== "DKK" && currency.Name !== "RUB" && currency.Name !== "NOK" && currency.Name !== "ILS" && currency.Name !== "SEK").map((data, i)=>select ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).contenedor_list,
                                        "data-acronimo": data?.Productos[0].Acronimo,
                                        "data-nombre": data?.Productos[0].Nombre,
                                        "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                        onClick: (e)=>{
                                            onChangeCurrency2(e);
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                "data-acronimo": data?.Productos[0].Acronimo,
                                                "data-nombre": data?.Productos[0].Nombre,
                                                "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                className: (estilosConversor_module_default()).bandera,
                                                onClick: (e)=>{
                                                    onChangeCurrency2(e);
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    onClick: (e)=>{
                                                        onChangeCurrency2(e);
                                                    },
                                                    width: 35,
                                                    height: 23,
                                                    src: `/assets/img/${data?.Productos[0].Acronimo}.png`,
                                                    "data-acronimo": data?.Productos[0].Acronimo,
                                                    "data-nombre": data?.Productos[0].Nombre,
                                                    "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                    alt: data?.Productos[0].Acronimo
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                "data-acronimo": data?.Productos[0].Acronimo,
                                                "data-nombre": data?.Productos[0].Nombre,
                                                "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                className: (estilosConversor_module_default()).moneda,
                                                onClick: (e)=>{
                                                    onChangeCurrency2(e);
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: (estilosConversor_module_default()).acronimo,
                                                        onClick: (e)=>{
                                                            onChangeCurrency2(e);
                                                        },
                                                        "data-acronimo": data?.Productos[0].Acronimo,
                                                        "data-nombre": data?.Productos[0].Nombre,
                                                        "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                        children: data?.Productos[0].Acronimo
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        onClick: (e)=>{
                                                            onChangeCurrency2(e);
                                                        },
                                                        className: (estilosConversor_module_default()).nombre,
                                                        "data-acronimo": data?.Productos[0].Acronimo,
                                                        "data-nombre": data?.Productos[0].Nombre,
                                                        "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                        children: [
                                                            "| ",
                                                            data?.Productos[0].Nombre
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i) : "")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).contenedorTipoCambio,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (estilosConversor_module_default()).tipoCambioIzq,
                                children: selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "-"
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        "1 ",
                                        fromAcronimo,
                                        " = ",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                exchangeRate,
                                                " €"
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (estilosConversor_module_default()).tipoCambioDer,
                                children: selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "-"
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        "1 EUR =",
                                        " ",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                precioDividido2.toFixed(4),
                                                " ",
                                                fromAcronimo
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).contenedorInputs,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInputSuperior,
                                children: [
                                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "-"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (estilosConversor_module_default()).acronimoTexto,
                                        children: fromAcronimo
                                    }),
                                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "number",
                                        className: (estilosConversor_module_default()).inputSuperior,
                                        value: "",
                                        disabled: true,
                                        placeholder: "Cantidad"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        className: (estilosConversor_module_default()).inputSuperior,
                                        type: "number",
                                        value: fromAmount,
                                        onChange: handleFromAmountChange,
                                        placeholder: "Cantidad"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInputSuperior,
                                children: [
                                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "-"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (estilosConversor_module_default()).acronimoTexto,
                                        children: "EUR"
                                    }),
                                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        className: (estilosConversor_module_default()).inputInferior,
                                        value: "",
                                        placeholder: "Cantidad",
                                        disabled: true,
                                        type: "number"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "number",
                                        className: (estilosConversor_module_default()).inputInferior,
                                        value: toAmount,
                                        onChange: handleToAmountChange,
                                        placeholder: "Cantidad"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueBotonLamar,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (estilosConversor_module_default()).bloqueBotonLamarTexto,
                        children: [
                            "\xbfSab\xedas que hacemos ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "mejoras de precio por cantidad"
                            }),
                            "?. \xa1LL\xc1MANOS!"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        title: `Llamar a Quickgold ${ciudad?.acf?.ciudad_landing}`,
                        href: `tel:${ciudad?.acf?.telefono}`,
                        className: (estilosConversor_module_default()).botonLlamarTienda,
                        children: "LLAMA GRATIS"
                    })
                ]
            }),
            " ",
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: (estilosConversor_module_default()).bloqueDivisaHabitualTexto,
                children: "Cambios de divisa m\xe1s habituales"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueDivisaHabitual,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).contenedorDivisaHabitual,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[0]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[0]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[0]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual1,
                                children: "Libra a Euro"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[1]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[1]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[1]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual2,
                                children: "D\xf3lar USA a Euro"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[5]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[5]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[5]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual3,
                                children: "Franco Suizo a Euro"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).contenedorDivisaHabitual,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[12]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[12]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[12]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual4,
                                children: "Real brasile\xf1o a Euro"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[15]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[15]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[15]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual5,
                                children: "Corona checa a Euro"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[19]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[19]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[19]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual6,
                                children: "Peso chileno a Euro"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Comprar = (NuevoConversor2);

;// CONCATENATED MODULE: ./src/componentes/ConversorDivisa/Vender.js




function Vender_NuevoConversor2({ ciudad , setSelectDivisa , selectDivisa  }) {
    const nombreCiudad = ciudad?.acf?.ciudad_oro;
    const [currencyOptions, setCurrencyOptions] = (0,external_react_.useState)([]);
    const [fromAcronimo, setFromAcronimo] = (0,external_react_.useState)("");
    const [nombreDivisa, setNombreDivisa] = (0,external_react_.useState)("");
    const [exchangeRate, setExchangeRate] = (0,external_react_.useState)("");
    const [amount, setAmount] = (0,external_react_.useState)("");
    const [amountInFromCurrency, setAmountInFromCurrency] = (0,external_react_.useState)(true);
    const [select, setSelect] = (0,external_react_.useState)(null);
    const precioDividido2 = 1 / exchangeRate;
    let toAmount, fromAmount;
    if (amountInFromCurrency) {
        fromAmount = amount;
        toAmount = (amount * exchangeRate).toFixed(2);
    } else {
        toAmount = amount;
        fromAmount = (amount / exchangeRate).toFixed(2);
    }
    (0,external_react_.useEffect)(()=>{
        fetch(`https://panel.quickgold.es/archivos-cache/Fixing${nombreCiudad}.txt`).then((res)=>res.json()).then((data)=>{
            setCurrencyOptions(data?.result?.Tarifas?.Divisas_Venta.reverse());
        });
    }, []);
    function handleFromAmountChange(e) {
        setAmount(e.target.value);
        setAmountInFromCurrency(true);
    }
    function handleToAmountChange(e) {
        setAmount(e.target.value);
        setAmountInFromCurrency(false);
    }
    function onChangeCurrency2(e) {
        setNombreDivisa(e.target.dataset.nombre);
        setExchangeRate(e.target.dataset.precio);
        setFromAcronimo(e.target.dataset.acronimo);
        setSelectDivisa(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (estilosConversor_module_default()).contenedorCalculadora,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueCalculadora,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (estilosConversor_module_default()).bloqueCalculadoraTextoSup,
                        children: "Selecciona divisa para ver el tipo de cambio"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).select,
                        onClick: ()=>{
                            setSelect(!select);
                        },
                        children: [
                            selectDivisa ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Seleccione Divisa"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    fromAcronimo,
                                    " | ",
                                    nombreDivisa,
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: select ? `${(estilosConversor_module_default()).select_monedas} ${(estilosConversor_module_default()).select_activo}` : `${(estilosConversor_module_default()).select_monedas}`,
                                children: currencyOptions.filter((currency)=>currency.Name !== "HRK" && currency.Name !== "DKK" && currency.Name !== "RUB" && currency.Name !== "NOK" && currency.Name !== "ILS" && currency.Name !== "SEK").map((data, i)=>select ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).contenedor_list,
                                        "data-acronimo": data?.Productos[0].Acronimo,
                                        "data-nombre": data?.Productos[0].Nombre,
                                        "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                        onClick: (e)=>{
                                            onChangeCurrency2(e);
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                "data-acronimo": data?.Productos[0].Acronimo,
                                                "data-nombre": data?.Productos[0].Nombre,
                                                "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                className: (estilosConversor_module_default()).bandera,
                                                onClick: (e)=>{
                                                    onChangeCurrency2(e);
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    onClick: (e)=>{
                                                        onChangeCurrency2(e);
                                                    },
                                                    width: 35,
                                                    height: 23,
                                                    src: `/assets/img/${data?.Productos[0].Acronimo}.png`,
                                                    "data-acronimo": data?.Productos[0].Acronimo,
                                                    "data-nombre": data?.Productos[0].Nombre,
                                                    "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                    alt: data?.Productos[0].Acronimo
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                "data-acronimo": data?.Productos[0].Acronimo,
                                                "data-nombre": data?.Productos[0].Nombre,
                                                "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                className: (estilosConversor_module_default()).moneda,
                                                onClick: (e)=>{
                                                    onChangeCurrency2(e);
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: (estilosConversor_module_default()).acronimo,
                                                        onClick: (e)=>{
                                                            onChangeCurrency2(e);
                                                        },
                                                        "data-acronimo": data?.Productos[0].Acronimo,
                                                        "data-nombre": data?.Productos[0].Nombre,
                                                        "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                        children: data?.Productos[0].Acronimo
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        onClick: (e)=>{
                                                            onChangeCurrency2(e);
                                                        },
                                                        className: (estilosConversor_module_default()).nombre,
                                                        "data-acronimo": data?.Productos[0].Acronimo,
                                                        "data-nombre": data?.Productos[0].Nombre,
                                                        "data-precio": (data?.Productos[0].Precio / 1000).toFixed(4),
                                                        children: [
                                                            "| ",
                                                            data?.Productos[0].Nombre
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i) : "")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).contenedorTipoCambio,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (estilosConversor_module_default()).tipoCambioIzq,
                                children: selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "-"
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        "1 EUR =",
                                        " ",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                precioDividido2.toFixed(4),
                                                " ",
                                                fromAcronimo
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (estilosConversor_module_default()).tipoCambioDer,
                                children: selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "-"
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        "1 ",
                                        fromAcronimo,
                                        " =",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                exchangeRate,
                                                "€"
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).contenedorInputs,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInputSuperior,
                                children: [
                                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "-"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (estilosConversor_module_default()).acronimoTexto,
                                        children: "EUR"
                                    }),
                                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        className: (estilosConversor_module_default()).inputSuperior,
                                        value: "",
                                        placeholder: "Cantidad",
                                        disabled: true,
                                        type: "number"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        className: (estilosConversor_module_default()).inputSuperior,
                                        type: "number",
                                        value: toAmount,
                                        onChange: handleToAmountChange,
                                        placeholder: "Cantidad"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInputSuperior,
                                children: [
                                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "-"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (estilosConversor_module_default()).acronimoTexto,
                                        children: fromAcronimo
                                    }),
                                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        className: (estilosConversor_module_default()).inputInferior,
                                        value: "",
                                        placeholder: "Cantidad",
                                        disabled: true,
                                        type: "number"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "number",
                                        className: (estilosConversor_module_default()).inputInferior,
                                        value: fromAmount,
                                        onChange: handleFromAmountChange,
                                        placeholder: "Cantidad"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueBotonLamar,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (estilosConversor_module_default()).bloqueBotonLamarTexto,
                        children: [
                            "\xbfSab\xedas que hacemos ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "mejoras de precio por cantidad"
                            }),
                            "?. \xa1LL\xc1MANOS!"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        title: `Llamar a Quickgold ${ciudad?.acf?.ciudad_landing}`,
                        href: `tel:${ciudad?.acf?.telefono}`,
                        className: (estilosConversor_module_default()).botonLlamarTienda,
                        children: "LLAMA GRATIS"
                    })
                ]
            }),
            " ",
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: (estilosConversor_module_default()).bloqueDivisaHabitualTexto,
                children: "Cambios de divisa m\xe1s habituales"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueDivisaHabitual,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).contenedorDivisaHabitual,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[0]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[0]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[0]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual1,
                                children: "Euro a Libra"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[1]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[1]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[1]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual2,
                                children: "Euro a D\xf3lar USA"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[5]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[5]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[5]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual3,
                                children: "Euro a Franco Suizo"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).contenedorDivisaHabitual,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[12]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[12]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[12]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual4,
                                children: "Euro a Real brasile\xf1o"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[15]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[15]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[15]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual5,
                                children: "Euro a Corona checa"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: (e)=>onChangeCurrency2(e),
                                "data-nombre": currencyOptions[19]?.Productos[0].Nombre,
                                "data-acronimo": currencyOptions[19]?.Productos[0].Acronimo,
                                "data-precio": (currencyOptions[19]?.Productos[0].Precio / 1000).toFixed(4),
                                className: (estilosConversor_module_default()).bloqueDivisaHabitual6,
                                children: "Euro a Peso chileno"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Vender = (Vender_NuevoConversor2);

;// CONCATENATED MODULE: ./src/componentes/ConversorDivisa/ConversorDivisa.js





const ConversorDivisa = ({ ciudad  })=>{
    const [selectDivisa, setSelectDivisa] = (0,external_react_.useState)(true);
    const [switched, setSwitched] = (0,external_react_.useState)(null);
    const comprar = ciudad?.acf?.vende_divisa;
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (estilosConversor_module_default()).contendorSectionDos,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (estilosConversor_module_default()).contendorBloques,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (estilosConversor_module_default()).bloqueIzq,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).contenedorBotones,
                        children: comprar ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: ()=>{
                                        setSwitched(false);
                                        setSelectDivisa(true);
                                    },
                                    className: switched ? `${(estilosConversor_module_default()).botonComprar}` : `${(estilosConversor_module_default()).botonComprar} ${(estilosConversor_module_default()).botonActivo}`,
                                    children: "Vender divisa"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: switched ? `${(estilosConversor_module_default()).botonVender} ${(estilosConversor_module_default()).botonActivo}` : ` ${(estilosConversor_module_default()).botonVender}`,
                                    onClick: ()=>{
                                        setSwitched(true);
                                        setSelectDivisa(true);
                                    },
                                    children: "Comprar divisa"
                                })
                            ]
                        }) : null
                    })
                }),
                switched ? /*#__PURE__*/ jsx_runtime_.jsx(Vender, {
                    ciudad: ciudad,
                    setSelectDivisa: setSelectDivisa,
                    selectDivisa: selectDivisa
                }) : /*#__PURE__*/ jsx_runtime_.jsx(Comprar, {
                    ciudad: ciudad,
                    setSelectDivisa: setSelectDivisa,
                    selectDivisa: selectDivisa
                })
            ]
        })
    });
};
/* harmony default export */ const ConversorDivisa_ConversorDivisa = (ConversorDivisa);

;// CONCATENATED MODULE: ./src/componentes/ConversorPlata/BloquePrecioPlata.js



const BloquePrecioPlata_CalculadoraOro = ({ ciudad  })=>{
    const nombreCiudad = ciudad?.acf?.ciudad_oro;
    const [data, setData] = (0,external_react_.useState)([]);
    const [loading, setLoading] = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        fetch(`https://panel.quickgold.es/archivos-cache/Fixing${nombreCiudad}.txt`, {
            cache: "no-cache"
        }).then((response)=>response.json()).then((response)=>{
            setData(response);
            setLoading(true);
        });
    }, []);
    const [valorInput, setValorInput] = (0,external_react_.useState)("0.00");
    const [valorSelect, setValorSelect] = (0,external_react_.useState)("0.00");
    const [masDe, setMasDe] = (0,external_react_.useState)(true);
    const precio999 = data?.result?.Tarifas?.Plata[3].Productos[0].Precio.toFixed(2);
    const precio925 = data?.result?.Tarifas?.Plata[2].Productos[0].Precio.toFixed(2);
    const precio800 = data?.result?.Tarifas?.Plata[0].Productos[0].Precio.toFixed(2);
    const masDePlata = ciudad?.acf?.para_mas_de_plata;
    const PrecioMasPlata = ciudad?.acf?.precio_mas_de_plata;
    const precio999Suma = (parseFloat(precio999) + parseFloat(PrecioMasPlata)).toFixed(2);
    const precio925Suma = (parseFloat(precio925) + parseFloat(PrecioMasPlata)).toFixed(2);
    const precio800Suma = (parseFloat(precio800) + parseFloat(PrecioMasPlata)).toFixed(2);
    const valorSelectSuma = (parseFloat(valorSelect) + parseFloat(PrecioMasPlata)).toFixed(2);
    const valorSelectNormal = parseFloat(valorSelect).toFixed(2);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (conversor_module_default()).contenedorAmbosBloquesOro,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (conversor_module_default()).contenedorBloqueSuperior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).botones,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                onClick: ()=>{
                                    setMasDe(true);
                                },
                                className: masDe ? `${(conversor_module_default()).button} ${(conversor_module_default()).botonActivo}` : `${(conversor_module_default()).button} `,
                                children: [
                                    "M\xe1s de ",
                                    masDePlata,
                                    "kg"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                onClick: ()=>{
                                    setMasDe(false);
                                },
                                className: masDe ? `${(conversor_module_default()).button} ` : `${(conversor_module_default()).button} ${(conversor_module_default()).botonActivo}`,
                                children: [
                                    "Menos de ",
                                    masDePlata,
                                    "kg"
                                ]
                            })
                        ]
                    }),
                    masDe ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).contenedorPrecios,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (conversor_module_default()).contenedorprecioDestacado,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (conversor_module_default()).precioDestacado,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (conversor_module_default()).kilates,
                                            children: "999"
                                        }),
                                        !loading ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (conversor_module_default()).precio18k,
                                            children: "Cargando"
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: (conversor_module_default()).precio999,
                                            children: [
                                                precio999Suma,
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "€/kg"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (conversor_module_default()).contenedorOtrosPrecios,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (conversor_module_default()).OtrosPrecios,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).preciok,
                                                children: "925"
                                            }),
                                            !loading ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).precio,
                                                children: "Cargando"
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (conversor_module_default()).precio,
                                                children: [
                                                    precio925Suma,
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "€/kg"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (conversor_module_default()).OtrosPrecios,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).preciok,
                                                children: "800"
                                            }),
                                            !loading ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).precio,
                                                children: "Cargando"
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (conversor_module_default()).precio,
                                                children: [
                                                    precio800Suma,
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "€/kg"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).contenedorPrecios,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (conversor_module_default()).contenedorprecioDestacado,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (conversor_module_default()).precioDestacado,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (conversor_module_default()).kilates,
                                            children: "999"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: (conversor_module_default()).precio999,
                                            children: [
                                                precio999,
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "€/kg"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (conversor_module_default()).contenedorOtrosPrecios,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (conversor_module_default()).OtrosPrecios,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).preciok,
                                                children: "925"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (conversor_module_default()).precio,
                                                children: [
                                                    precio925,
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "€/kg"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (conversor_module_default()).OtrosPrecios,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (conversor_module_default()).preciok,
                                                children: "800"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (conversor_module_default()).precio,
                                                children: [
                                                    precio800,
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "€/kg"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (conversor_module_default()).contenedorCalculadora,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        children: [
                            "\xbfCu\xe1nto ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "te vamos a dar"
                            }),
                            " por tus joyas?"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).contenedorSelect,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (conversor_module_default()).Select,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Selecciona pureza"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                        onChange: (e)=>{
                                            setValorSelect(e.target.value);
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: 0,
                                                children: "---"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: precio800,
                                                children: "800"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: precio925,
                                                children: "925"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: precio999,
                                                children: "999"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (conversor_module_default()).input,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Introduce gramos"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "number",
                                        placeholder: "Cantidad",
                                        onChange: (event)=>setValorInput(event.target.value)
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "g"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (conversor_module_default()).tituloInferior,
                        children: "Te daremos por tu plata"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (conversor_module_default()).precioFinal,
                        children: [
                            valorInput >= parseFloat(masDePlata * 1000) ? (valorInput / 1000 * valorSelectSuma).toLocaleString("es", {
                                style: "currency",
                                currency: "EUR"
                            }) : (valorInput / 1000 * valorSelectNormal).toLocaleString("es", {
                                style: "currency",
                                currency: "EUR"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: (conversor_module_default()).promocion,
                children: "Promoci\xf3n Online"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                title: `Llamar a Quickgold ${ciudad?.acf?.ciudad_landing}`,
                className: (conversor_module_default()).botonLlamarTienda,
                href: `tel:${ciudad?.acf?.telefono}`,
                children: "LLAMA GRATIS"
            })
        ]
    });
};
/* harmony default export */ const BloquePrecioPlata = (BloquePrecioPlata_CalculadoraOro);

// EXTERNAL MODULE: ./src/componentes/InvertirEnOro/Lingotes.module.css
var Lingotes_module = __webpack_require__(7578);
var Lingotes_module_default = /*#__PURE__*/__webpack_require__.n(Lingotes_module);
;// CONCATENATED MODULE: ./src/componentes/InvertirEnOro/Tabla2Lingotes.js
//import Image from "next/image";



//import imagenMarcaLingotes from "../../../public/assets/imagenMarcaLingote.png";
//import lingote2_5 from "../../../assets/lingote2.5.png";
//import lingote5 from "../../../public/assets/lingote5.png";
//import lingote10 from "../../../public/assets/lingote10.png";
//import lingote20 from "../../../public/assets/lingote20.png";
//import lingote1oz from "../../../public/assets/lingote1oz.png";
//import lingote50 from "../../../public/assets/lingote50.png";
//import lingote100 from "../../../public/assets/lingote100.png";
//import lingote250 from "../../../public/assets/lingote250.png";
//import lingote500 from "../../../public/assets/lingote500.png";
//import lingote1000 from "../../../public/assets/lingote1000.png";
const Tabla2Lingotes = ({ ciudad  })=>{
    const nombreCiudad = ciudad?.acf?.ciudad_oro;
    const [data, setData] = (0,external_react_.useState)([]);
    //const [loading, setLoading] = useState(null);
    (0,external_react_.useEffect)(()=>{
        fetch(`https://panel.quickgold.es/archivos-cache/Fixing${nombreCiudad}.txt`, {
            cache: "no-cache"
        }).then((response)=>response.json()).then((response)=>{
            setData(response);
        //setLoading(true);
        });
    }, []);
    const precio2_5 = (data?.result?.Tarifas?.Lingotes[4].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio5 = (data?.result?.Tarifas?.Lingotes[5].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio10 = (data?.result?.Tarifas?.Lingotes[10].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio20 = (data?.result?.Tarifas?.Lingotes[11].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio1Oz = (data?.result?.Tarifas?.Lingotes[12].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio50 = (data?.result?.Tarifas?.Lingotes[13].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio100 = (data?.result?.Tarifas?.Lingotes[14].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio250 = (data?.result?.Tarifas?.Lingotes[15].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio500 = (data?.result?.Tarifas?.Lingotes[0].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const precio1000 = (data?.result?.Tarifas?.Lingotes[16].Productos[0].Precio / 1000).toLocaleString("es", {
        style: "currency",
        currency: "EUR"
    });
    const arrayLingotes = [
        {
            id: 1,
            //imagenLingote: lingote2_5,
            nombreLingote: "Lingote de 2.5gr",
            precioLingote: precio2_5,
            medidaBlister: "17,82 x 10,82 x 1,349mm",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 2,
            //imagenLingote: lingote5,
            nombreLingote: "Lingote de 5gr",
            precioLingote: precio5,
            medidaBlister: "14,95 x 7,95 x 0,437mm",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 3,
            //imagenLingote: lingote10,
            nombreLingote: "Lingote de 10gr",
            precioLingote: precio10,
            medidaBlister: "27,82 x 13,82 x 1,358mm",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 4,
            //imagenLingote: lingote20,
            nombreLingote: "Lingote de 20gr",
            precioLingote: precio20,
            medidaBlister: "31,82 x 15,82 x 2,070mm",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 5,
            //imagenLingote: lingote1oz,
            nombreLingote: "Lingote de 1oz",
            precioLingote: precio1Oz,
            medidaBlister: "31,82 x 15,82 x 3,219mm",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 6,
            //imagenLingote: lingote50,
            nombreLingote: "Lingote de 50gr",
            precioLingote: precio50,
            medidaBlister: "41,82 x 23,82 x 2,610pxmm",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 7,
            //imagenLingote: lingote100,
            nombreLingote: "Lingote de 100gr",
            precioLingote: precio100,
            medidaBlister: "41,82 x 23,82 x 5,220mm",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 8,
            //imagenLingote: lingote250,
            nombreLingote: "Lingote de 250gr",
            precioLingote: precio250,
            medidaBlister: "sin blister",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 9,
            //imagenLingote: lingote500,
            nombreLingote: "Lingote de 500gr",
            precioLingote: precio500,
            medidaBlister: "sin blister",
            telefono: ciudad?.acf?.telefono
        },
        {
            id: 10,
            //imagenLingote: lingote1000,
            nombreLingote: "Lingote de 1000gr",
            precioLingote: precio1000,
            medidaBlister: "sin blister",
            telefono: ciudad?.acf?.telefono
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Lingotes_module_default()).contenedorAmbosTablaLingotes,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Lingotes_module_default()).contenedorTablas,
            children: arrayLingotes.map((lingote, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Lingotes_module_default()).contendorDatos,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (Lingotes_module_default()).nombrePrecio,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: lingote.nombreLingote
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        lingote.precioLingote,
                                        "€"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (Lingotes_module_default()).oroFino,
                            children: "Oro fino 999,9"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (Lingotes_module_default()).medidaBlister,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "Medidas del blister:"
                                }),
                                " ",
                                lingote.medidaBlister
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (Lingotes_module_default()).separador
                        })
                    ]
                }, index))
        })
    });
};
/* harmony default export */ const InvertirEnOro_Tabla2Lingotes = (Tabla2Lingotes);

// EXTERNAL MODULE: ./src/componentes/BloqueInfo/conversor.module.css
var BloqueInfo_conversor_module = __webpack_require__(5711);
var BloqueInfo_conversor_module_default = /*#__PURE__*/__webpack_require__.n(BloqueInfo_conversor_module);
;// CONCATENATED MODULE: ./src/componentes/BloqueInfo/Empenos.js



function Empenos({ ciudad  }) {
    const nombreCiudad = ciudad?.acf?.ciudad_oro;
    const [data, setData] = (0,external_react_.useState)([]);
    (0,external_react_.useEffect)(()=>{
        fetch(`https://panel.quickgold.es/archivos-cache/Fixing${nombreCiudad}.txt`, {
            cache: "no-cache"
        }).then((response)=>response.json()).then((response)=>{
            setData(response);
        });
    }, []);
    const precio18k = data?.result?.Tarifas?.Oro[2].Productos[0].Precio / 1000;
    const paraMasOro = ciudad?.acf?.para_mas_de_oro;
    const masDeOro = ciudad?.acf?.precio_mas_de_oro;
    const precioMas18k = (precio18k + parseFloat(masDeOro)).toFixed(2);
    const primerMes = ciudad?.acf?.primer_mes;
    const tasacion = ciudad?.acf?.tasacion;
    const intereStandar = ciudad?.acf?.interes_standard;
    const costeTasacion = ciudad.acf.coste_de_tasacion;
    const telefono = ciudad?.acf?.telefono;
    const precio = 100;
    const percibes = precio - costeTasacion;
    const [botonActivo, setBotonActivo] = (0,external_react_.useState)(null);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (BloqueInfo_conversor_module_default()).contenedorBotones,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>{
                            setBotonActivo(false);
                        },
                        className: botonActivo ? `${(BloqueInfo_conversor_module_default()).botonUno}` : `${(BloqueInfo_conversor_module_default()).botonUno} ${(BloqueInfo_conversor_module_default()).botonActivo}`,
                        children: "INFO"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>{
                            setBotonActivo(true);
                        },
                        className: botonActivo ? `${(BloqueInfo_conversor_module_default()).botonUno} ${(BloqueInfo_conversor_module_default()).botonActivo}` : `${(BloqueInfo_conversor_module_default()).botonUno} `,
                        children: "EJEMPLO"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (BloqueInfo_conversor_module_default()).contenedor,
                children: botonActivo ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (BloqueInfo_conversor_module_default()).contenidoEjemplo,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (BloqueInfo_conversor_module_default()).contenedorInfo,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                children: "PONGAMOS UN EJEMPLO"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: (BloqueInfo_conversor_module_default()).segundoParrafo,
                                children: [
                                    "Para un empe\xf1o con inter\xe9s al",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        children: [
                                            intereStandar,
                                            "% mensual y ",
                                            primerMes,
                                            "% de inter\xe9s primer mes:"
                                        ]
                                    }),
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (BloqueInfo_conversor_module_default()).ejemplo,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: (BloqueInfo_conversor_module_default()).primerParrafo,
                                        children: [
                                            "Con un valor de tus joyas de ",
                                            precio,
                                            "€, recibes ",
                                            percibes,
                                            "€."
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: (BloqueInfo_conversor_module_default()).tercerParrafo,
                                        children: [
                                            "Conlleva un peque\xf1o gasto de gesti\xf3n del ",
                                            costeTasacion,
                                            "%"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (BloqueInfo_conversor_module_default()).cuartoParrafo,
                                children: "Para recuperar las piezas empe\xf1adas pasado el primer mes y finalizar el contrato deber\xedas abonar 100€."
                            })
                        ]
                    })
                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (BloqueInfo_conversor_module_default()).contenidoInfo,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (BloqueInfo_conversor_module_default()).contenedorAmbosBloquesEmpeno,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (BloqueInfo_conversor_module_default()).contenedorBloqueEmpeno,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                    children: [
                                        primerMes,
                                        "% inter\xe9s ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "primer mes"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: (BloqueInfo_conversor_module_default()).preciosDelOro,
                                    children: [
                                        "Precio del oro: ",
                                        precioMas18k,
                                        " €/g 18k m\xe1s de ",
                                        paraMasOro,
                                        "g."
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (BloqueInfo_conversor_module_default()).contenedorTresBloques,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (BloqueInfo_conversor_module_default()).contenedorBloques,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (BloqueInfo_conversor_module_default()).bloqueIzq,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        children: [
                                                            intereStandar,
                                                            "%"
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (BloqueInfo_conversor_module_default()).bloqueDer,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Inter\xe9s mensual"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (BloqueInfo_conversor_module_default()).contenedorBloques,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (BloqueInfo_conversor_module_default()).bloqueIzq,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        children: [
                                                            tasacion,
                                                            "%"
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (BloqueInfo_conversor_module_default()).bloqueDer,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Tasaci\xf3n"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (BloqueInfo_conversor_module_default()).contenedorBloques,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (BloqueInfo_conversor_module_default()).bloqueIzq,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        children: [
                                                            primerMes,
                                                            "%"
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (BloqueInfo_conversor_module_default()).bloqueDer,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Primer mes"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (BloqueInfo_conversor_module_default()).contenedorBotonLlamar,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    className: (BloqueInfo_conversor_module_default()).botonLlamarTienda,
                    href: `tel:${telefono}`,
                    children: "LLAMAR A LA TIENDA"
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/componentes/AccordionServicios/AccordionServicios.js













const Accordion = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()), {
        disableGutters: true,
        elevation: 0,
        square: true,
        ...props
    }))(({ theme  })=>({
        border: `1px solid ${theme.palette.divider}`,
        "&:not(:last-child)": {
            borderBottom: 0
        },
        "&:before": {
            display: "none"
        }
    }));
const AccordionSummary = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((AccordionSummary_default()), {
        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx((ArrowDropDown_default()), {
            sx: {
                fontSize: "2.5rem",
                color: "#fff",
                background: "#061B2D",
                borderRadius: "50%"
            }
        }),
        ...props
    }))(({ theme  })=>({
        "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded svg": {
            transform: "rotate(360deg)",
            background: "#0692D0"
        },
        "& .MuiAccordionSummary-content": {
            marginLeft: theme.spacing(1)
        }
    }));
const AccordionDetails = (0,styles_.styled)((AccordionDetails_default()))(({ theme  })=>({
        padding: theme.spacing(2)
    }));
function AccordionServicios({ ciudad  }) {
    const [expanded, setExpanded] = external_react_default().useState("panel3");
    const handleChange = (panel)=>(event, newExpanded)=>{
            setExpanded(newExpanded ? panel : false);
        };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("article", {
        className: (accordion_module_default()).contenedorAccordion,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                    style: {
                        background: "#0F2D45",
                        borderRadius: "8px",
                        border: "none",
                        padding: "10px 20px 0 20px"
                    },
                    className: (accordion_module_default()).contendorAccordion3,
                    expanded: expanded === "panel3",
                    onChange: handleChange("panel3"),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionSummary, {
                            style: {
                                padding: "0",
                                borderBottom: "2px solid #fff"
                            },
                            "aria-controls": "panel3d-content",
                            id: "panel3d-header",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (accordion_module_default()).contenedorTituloServicio,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: expanded === "panel3" ? `${(accordion_module_default()).tituloServicio} ${(accordion_module_default()).accordionActivo}` : `${(accordion_module_default()).tituloServicio}`,
                                        children: "Cambio de divisas"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                        className: (accordion_module_default()).subTituloServicio,
                                        children: [
                                            "Somos la ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                children: "casa de cambio"
                                            }),
                                            " preferida por miles de personas al a\xf1o en ",
                                            ciudad?.acf?.ciudad_landing,
                                            ". ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                children: "Cambiar divisa"
                                            }),
                                            " en Quickgold siempre es sin comisiones y, f\xe1cil y r\xe1pido."
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                            className: (accordion_module_default()).details,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ConversorDivisa_ConversorDivisa, {
                                ciudad: ciudad
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                    style: {
                        background: "#0F2D45",
                        borderRadius: "8px",
                        border: "none",
                        padding: "10px 20px 0 20px"
                    },
                    className: (accordion_module_default()).contendorAccordion1,
                    expanded: expanded === "panel1",
                    onChange: handleChange("panel1"),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionSummary, {
                            style: {
                                padding: "0",
                                borderBottom: "2px solid #fff"
                            },
                            "aria-controls": "panel1d-content",
                            id: "panel1d-header",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (accordion_module_default()).contenedorTituloServicio,
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: expanded === "panel1" ? `${(accordion_module_default()).tituloServicio} ${(accordion_module_default()).accordionActivo}` : `${(accordion_module_default()).tituloServicio}`,
                                        children: "Precio del oro"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                        className: (accordion_module_default()).subTituloServicio,
                                        children: [
                                            "Vender ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                children: "oro al mejor precio"
                                            }),
                                            " es f\xe1cil en nuestras tiendas ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                children: "Compro oro"
                                            }),
                                            " en ",
                                            ciudad?.acf?.ciudad_landing,
                                            ". M\xe1s de 15 a\xf1os en el sector siendo la empresa referente en las ciudades donde estamos."
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                            className: (accordion_module_default()).details,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ConversorPlata_CalculadoraOro, {
                                ciudad: ciudad
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                    style: {
                        background: "#0F2D45",
                        borderRadius: "8px",
                        border: "none",
                        padding: "10px 20px 0 20px"
                    },
                    className: (accordion_module_default()).contendorAccordion2,
                    expanded: expanded === "panel2",
                    onChange: handleChange("panel2"),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionSummary, {
                            style: {
                                padding: "0",
                                borderBottom: "2px solid #fff"
                            },
                            "aria-controls": "panel2d-content",
                            id: "panel2d-header",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (accordion_module_default()).contenedorTituloServicio,
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: expanded === "panel2" ? `${(accordion_module_default()).tituloServicio} ${(accordion_module_default()).accordionActivo}` : `${(accordion_module_default()).tituloServicio}`,
                                        children: "Precio de la plata"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                        className: (accordion_module_default()).subTituloServicio,
                                        children: [
                                            "Compramos ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                children: "plata al mejor precio"
                                            }),
                                            ": joyas, cuberter\xedas, etc. Somos los l\xedderes en la ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                children: "compra de joyas"
                                            }),
                                            " en ",
                                            ciudad?.acf?.ciudad_landing,
                                            "."
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                            className: (accordion_module_default()).details,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(BloquePrecioPlata, {
                                ciudad: ciudad
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                    style: {
                        background: "#0F2D45",
                        borderRadius: "8px",
                        border: "none",
                        padding: "10px 20px 0 20px"
                    },
                    className: (accordion_module_default()).contendorAccordion4,
                    expanded: expanded === "panel4",
                    onChange: handleChange("panel4"),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionSummary, {
                            style: {
                                padding: "0",
                                borderBottom: "2px solid #fff"
                            },
                            "aria-controls": "panel4d-content",
                            id: "panel4d-header",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (accordion_module_default()).contenedorTituloServicio,
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: expanded === "panel4" ? `${(accordion_module_default()).tituloServicio} ${(accordion_module_default()).accordionActivo}` : `${(accordion_module_default()).tituloServicio}`,
                                        children: "Empe\xf1o de joyas"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                        className: (accordion_module_default()).subTituloServicio,
                                        children: [
                                            "Nuestros ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                children: "empe\xf1os sin inter\xe9s el primer mes"
                                            }),
                                            " hacen que empe\xf1ar oro sea mucho m\xe1s c\xf3modo y f\xe1cil para nuestros clientes."
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                            className: (accordion_module_default()).details,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Empenos, {
                                ciudad: ciudad
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                    style: {
                        background: "#0F2D45",
                        borderRadius: "8px",
                        border: "none",
                        padding: "10px 20px 0 20px"
                    },
                    className: (accordion_module_default()).contendorAccordion5,
                    expanded: expanded === "panel5",
                    onChange: handleChange("panel5"),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionSummary, {
                            style: {
                                padding: "0"
                            },
                            "aria-controls": "panel5d-content",
                            id: "panel5d-header",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (accordion_module_default()).contenedorTituloServicio,
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: expanded === "panel5" ? `${(accordion_module_default()).tituloServicio} ${(accordion_module_default()).accordionActivo}` : `${(accordion_module_default()).tituloServicio}`,
                                        children: "Invertir en oro"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: (accordion_module_default()).subTituloServicio,
                                        children: "Venta de lingotes de oro con las mejores condiciones. El oro, como valor refugio est\xe1 claramente por encima de otro tipo de inversiones."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                            style: {
                                border: "none"
                            },
                            className: (accordion_module_default()).details,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(InvertirEnOro_Tabla2Lingotes, {
                                ciudad: ciudad
                            })
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 7967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _bannerPromoDos_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9605);
/* harmony import */ var _bannerPromoDos_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_bannerPromoDos_module_css__WEBPACK_IMPORTED_MODULE_2__);



const BannerPromoGeneral = ({ general  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_bannerPromoDos_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorBannerUno),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: (_bannerPromoDos_module_css__WEBPACK_IMPORTED_MODULE_2___default().bannerDesktop),
                src: general?.acf?.imagen_general_desktop,
                alt: "Banner general"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: (_bannerPromoDos_module_css__WEBPACK_IMPORTED_MODULE_2___default().bannerMobil),
                src: general?.acf?.imagen_general_mobil,
                alt: "Banner general mobil"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerPromoGeneral);


/***/ }),

/***/ 2810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _bannerPromoUno_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9086);
/* harmony import */ var _bannerPromoUno_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_bannerPromoUno_module_css__WEBPACK_IMPORTED_MODULE_2__);



const BannerPromoTiendas = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_bannerPromoUno_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorBannerUno),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: (_bannerPromoUno_module_css__WEBPACK_IMPORTED_MODULE_2___default().bannerDesktop),
                src: ciudad?.acf?.foto_1,
                alt: "Banner tienda"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: (_bannerPromoUno_module_css__WEBPACK_IMPORTED_MODULE_2___default().bannerMobil),
                src: ciudad?.acf?.foto_2,
                alt: "Banner tienda mobil"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerPromoTiendas);


/***/ }),

/***/ 3428:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _bannerWallapop_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9698);
/* harmony import */ var _bannerWallapop_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_bannerWallapop_module_css__WEBPACK_IMPORTED_MODULE_2__);



const BannerWallapop = ({ ciudad  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_bannerWallapop_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorBannerWallapop),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            target: "_blank",
            href: ciudad?.acf?.url_del_banner_wallapop,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                loading: "lazy",
                className: (_bannerWallapop_module_css__WEBPACK_IMPORTED_MODULE_2___default().bannerWallapopDesktop),
                src: ciudad?.acf?.imagen_del_banner_wallapop,
                alt: "Banner tienda"
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerWallapop);


/***/ }),

/***/ 7186:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _botonLamarFijo_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9657);
/* harmony import */ var _botonLamarFijo_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_botonLamarFijo_module_css__WEBPACK_IMPORTED_MODULE_2__);



const BotonLamarFijo = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_botonLamarFijo_module_css__WEBPACK_IMPORTED_MODULE_2___default().botonLlamar),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            title: "Tel\xe9fono",
            href: "tel:900 373 629",
            children: "LLAMAR A 900 373 629"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BotonLamarFijo);


/***/ }),

/***/ 2911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _botonesLlamar_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9911);
/* harmony import */ var _botonesLlamar_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_botonesLlamar_module_css__WEBPACK_IMPORTED_MODULE_2__);



const BotonesLlamar = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_botonesLlamar_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorBotones),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: (_botonesLlamar_module_css__WEBPACK_IMPORTED_MODULE_2___default().botonLlamar),
                href: `tel:${ciudad?.acf?.telefono}`,
                children: "LLAMAR"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: (_botonesLlamar_module_css__WEBPACK_IMPORTED_MODULE_2___default().botonWhatsapp),
                target: "_blank",
                href: `https://wa.me/+34${ciudad?.acf?.mobile?.replace(/\s+/g, "")}`,
                children: "WHATSAPP"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BotonesLlamar);


/***/ }),

/***/ 942:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _breadcrumbs_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(762);
/* harmony import */ var _breadcrumbs_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_breadcrumbs_module_css__WEBPACK_IMPORTED_MODULE_2__);



const Breadcrumbs = ({ raiz , tiendas , nombreCiudad , nombreTienda , ubicacionActual , urlNombreCiudad , urlNombreTienda , iconoRaiz , iconoTiendas , iconoUbiccionActual  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_breadcrumbs_module_css__WEBPACK_IMPORTED_MODULE_2___default().sectionBreadcrumbs),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_breadcrumbs_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorBreadcrumbs),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "/",
                        title: `Ir a ${raiz}`,
                        children: raiz
                    }),
                    iconoRaiz,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "/tiendas",
                        title: `Ir a ${tiendas}`,
                        children: tiendas
                    }),
                    iconoTiendas,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: urlNombreCiudad,
                        title: `Ir a ${nombreCiudad}`,
                        children: nombreCiudad
                    }),
                    iconoUbiccionActual,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: urlNombreTienda,
                        title: `Ir a ${nombreTienda}`,
                        children: nombreTienda
                    }),
                    iconoTiendas
                ]
            }),
            ubicacionActual
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Breadcrumbs);


/***/ }),

/***/ 38:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _html_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8612);
/* harmony import */ var _html_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_html_module_css__WEBPACK_IMPORTED_MODULE_2__);



const Html = ({ ciudad  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_html_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorHtml),
        dangerouslySetInnerHTML: {
            __html: ciudad?.acf?.html
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Html);


/***/ })

};
;