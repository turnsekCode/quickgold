exports.id = 7699;
exports.ids = [7699];
exports.modules = {

/***/ 7459:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "header_header__m90mM",
	"contenedorLogo": "header_contenedorLogo__A23yT",
	"menuHamburquesa": "header_menuHamburquesa__ORRf6",
	"css-1160xiw-MuiPaper-root-MuiDrawer-paper": "header_css-1160xiw-MuiPaper-root-MuiDrawer-paper__Ot6T7",
	"contenedorRedes": "header_contenedorRedes___aLiz",
	"closeBoton": "header_closeBoton__023Ci",
	"contenedorIconos": "header_contenedorIconos__CtQpt",
	"botonLlamar": "header_botonLlamar__kG7iW",
	"linkedin": "header_linkedin__ZUB84",
	"vector": "header_vector__mz4tH"
};


/***/ }),

/***/ 5319:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footerMobil_footer__bVAKO",
	"logo": "footerMobil_logo__Xh2FQ",
	"telefono": "footerMobil_telefono__ri74O",
	"redes": "footerMobil_redes__sAt4s",
	"contenedorRedes": "footerMobil_contenedorRedes__D4FWD",
	"listaMenuTitulo": "footerMobil_listaMenuTitulo___oOab",
	"ul": "footerMobil_ul__lwTrG",
	"menuActive": "footerMobil_menuActive__ULjAJ",
	"menuActivo1": "footerMobil_menuActivo1__xSrVM",
	"textoFooter": "footerMobil_textoFooter__N80EE"
};


/***/ }),

/***/ 7420:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorFooter": "footer_contenedorFooter__dIRp5",
	"contenedorContenidoFooter": "footer_contenedorContenidoFooter__bZfry",
	"contenedorEnlaces": "footer_contenedorEnlaces__Swl9R",
	"enlaces": "footer_enlaces__ryhqp",
	"iconosRedes": "footer_iconosRedes__2_GQ_",
	"twitter": "footer_twitter__ObDwB",
	"politicaPrivacidad": "footer_politicaPrivacidad__a3_VZ",
	"linea": "footer_linea__9g7KO",
	"registro": "footer_registro__Btk3v"
};


/***/ }),

/***/ 6088:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor": "layout_contenedor__ry__i"
};


/***/ }),

/***/ 1230:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorMenuMobil": "menuMobil_contenedorMenuMobil__va89i",
	"menuMobil": "menuMobil_menuMobil__d5PVr",
	"listasMenu": "menuMobil_listasMenu__73Wc4",
	"contacto": "menuMobil_contacto__o3x2E",
	"servicios": "menuMobil_servicios__Grhfe",
	"subServicios": "menuMobil_subServicios__TlrIt",
	"subMenuActivoServicios": "menuMobil_subMenuActivoServicios__XKnfP",
	"subMenuActivo": "menuMobil_subMenuActivo__gvcCi",
	"menuActive": "menuMobil_menuActive__BT1PM",
	"menuActive1": "menuMobil_menuActive1__zj1EE",
	"contenedorListasMenu": "menuMobil_contenedorListasMenu__tdozh",
	"menuInferiorMobil": "menuMobil_menuInferiorMobil__qyEXM",
	"background": "menuMobil_background__NW_a3",
	"serviciosTiendas": "menuMobil_serviciosTiendas___8Rqx"
};


/***/ }),

/***/ 9615:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorMenuSticky": "menuOrdenador_contenedorMenuSticky__chvFE",
	"contenedorMenu": "menuOrdenador_contenedorMenu__sE59o",
	"botonLlamar": "menuOrdenador_botonLlamar___H4BC",
	"headersticky": "menuOrdenador_headersticky__7cmlh",
	"contenedorSubMenuTiendas": "menuOrdenador_contenedorSubMenuTiendas__YzUms",
	"subMenuTiendas": "menuOrdenador_subMenuTiendas__c9raA",
	"contenedorSubMenuServicios": "menuOrdenador_contenedorSubMenuServicios__nyoiV",
	"servicios": "menuOrdenador_servicios__uwQD1",
	"subMenuServicios": "menuOrdenador_subMenuServicios__ePSbN"
};


/***/ }),

/***/ 7699:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/componentes/Layout/layout.module.css
var layout_module = __webpack_require__(6088);
var layout_module_default = /*#__PURE__*/__webpack_require__.n(layout_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/componentes/Cabecera/header.module.css
var header_module = __webpack_require__(7459);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
// EXTERNAL MODULE: external "@mui/icons-material/LinkedIn"
var LinkedIn_ = __webpack_require__(5939);
var LinkedIn_default = /*#__PURE__*/__webpack_require__.n(LinkedIn_);
// EXTERNAL MODULE: external "@mui/icons-material/Facebook"
var Facebook_ = __webpack_require__(7666);
var Facebook_default = /*#__PURE__*/__webpack_require__.n(Facebook_);
// EXTERNAL MODULE: external "@mui/icons-material/Instagram"
var Instagram_ = __webpack_require__(3281);
var Instagram_default = /*#__PURE__*/__webpack_require__.n(Instagram_);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowDown"
var KeyboardArrowDown_ = __webpack_require__(4845);
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_);
// EXTERNAL MODULE: ./src/componentes/MenuOrdenador/menuOrdenador.module.css
var menuOrdenador_module = __webpack_require__(9615);
var menuOrdenador_module_default = /*#__PURE__*/__webpack_require__.n(menuOrdenador_module);
;// CONCATENATED MODULE: ./src/componentes/MenuOrdenador/MenuOrdenador.js




const MenuOrdenador = ({ menu_list , sticky , stickyRef  })=>{
    const datos = menu_list?.items;
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        ref: stickyRef,
        className: sticky ? `${(menuOrdenador_module_default()).contenedorMenuSticky} ${(menuOrdenador_module_default()).headersticky}` : `${(menuOrdenador_module_default()).contenedorMenu}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: (menuOrdenador_module_default()).contenedorMenu,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "/",
                        title: "Ir a quickgold",
                        children: "INICIO"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: (menuOrdenador_module_default()).contenedorSubMenuServicios,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (menuOrdenador_module_default()).servicios,
                            children: [
                                "servicios ",
                                /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (menuOrdenador_module_default()).subMenuServicios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/compro-oro",
                                    title: "Ir a compro oro",
                                    children: "COMPRO ORO"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/cambio-divisas",
                                    title: "Ir a cambio divisas",
                                    children: "CAMBIO DE DIVISAS"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/empeno-de-joyas",
                                    title: "Ir a empe\xf1o de joyas",
                                    children: "EMPE\xd1O DE JOYAS"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    title: "Ir a compra de plata",
                                    href: "/compro-plata",
                                    children: "COMPRA DE PLATA"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    title: "Ir a joyer\xeda de ocasi\xf3n",
                                    href: "/joyeria-de-ocasion",
                                    children: "JOYER\xcdA OCASI\xd3N"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    title: "Ir a invertir en oro",
                                    href: "/invertir-en-oro",
                                    children: "ORO DE INVERSI\xd3N"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    title: "Ir a compra de diamantes",
                                    href: "/vender-diamantes",
                                    children: "COMPRA DE DIAMANTES"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: (menuOrdenador_module_default()).contenedorSubMenuTiendas,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: "/tiendas",
                            title: "Tiendas Quickgold",
                            children: [
                                "Tiendas ",
                                /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (menuOrdenador_module_default()).subMenuTiendas,
                            children: datos?.map((tienda, index)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `${tienda.url}`,
                                    title: tienda.title,
                                    children: tienda.title
                                }, index))
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "/expansion",
                        title: "Ir a expansion",
                        children: "SOBRE QUICKGOLD"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const MenuOrdenador_MenuOrdenador = (MenuOrdenador);

// EXTERNAL MODULE: ./src/componentes/MenuMobil/menuMobil.module.css
var menuMobil_module = __webpack_require__(1230);
var menuMobil_module_default = /*#__PURE__*/__webpack_require__.n(menuMobil_module);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowUp"
var KeyboardArrowUp_ = __webpack_require__(9881);
var KeyboardArrowUp_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowUp_);
;// CONCATENATED MODULE: ./src/componentes/MenuMobil/MenuMobil.js





const MenuMobil = ({ menuAbieto , menu_list  })=>{
    const datos = menu_list?.items;
    const [subMenuAbieto, setSubMenuAbierto] = (0,external_react_.useState)(false);
    const [subMenuTienda, setSubMenuTienda] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: menuAbieto ? `${(menuMobil_module_default()).contenedorMenuMobil} ${(menuMobil_module_default()).menuActive1}` : `${(menuMobil_module_default()).contenedorMenuMobil} `,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (menuMobil_module_default()).menuMobil,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (menuMobil_module_default()).contenedorListasMenu,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (menuMobil_module_default()).listasMenu,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/",
                                title: "Ir a quickgold",
                                children: "INICIO"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (menuMobil_module_default()).servicios,
                                onClick: ()=>{
                                    setSubMenuTienda(!subMenuTienda), setSubMenuAbierto(false);
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (menuMobil_module_default()).serviciosTiendas,
                                        href: "/tiendas",
                                        children: "Tiendas"
                                    }),
                                    subMenuTienda ? /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowUp_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: subMenuTienda ? `${(menuMobil_module_default()).subServicios} ${(menuMobil_module_default()).subMenuActivo}` : `${(menuMobil_module_default()).subServicios} `,
                                children: datos?.map((tienda, index)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: `${tienda.url}`,
                                        title: tienda?.title,
                                        children: tienda?.title
                                    }, index))
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (menuMobil_module_default()).servicios,
                                onClick: ()=>{
                                    setSubMenuAbierto(!subMenuAbieto), setSubMenuTienda(false);
                                },
                                children: [
                                    "servicios",
                                    subMenuAbieto ? /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowUp_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: subMenuAbieto ? `${(menuMobil_module_default()).subServicios} ${(menuMobil_module_default()).subMenuActivoServicios}` : `${(menuMobil_module_default()).subServicios} `,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/compro-oro",
                                        title: "Ir a compro oro",
                                        children: "COMPRO ORO"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/cambio-divisas",
                                        title: "Ir a cambio de divisa",
                                        children: "CAMBIO DE DIVISAS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "s/empeno-de-joyas",
                                        title: "Ir a empe\xf1o de joyas",
                                        children: "EMPE\xd1O DE JOYAS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/compro-plata",
                                        children: "COMPRA DE PLATA"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/joyeria-de-ocasion",
                                        children: "JOYER\xcdA OCASI\xd3N"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/invertir-en-oro",
                                        children: "ORO DE INVERSI\xd3N"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/vender-diamantes",
                                        children: "COMPRA DE DIAMANTES"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (menuMobil_module_default()).menuInferiorMobil,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/expansion",
                                        title: "ABRIR TIENDA QUICKGOLD",
                                        children: "ABRIR TIENDA QUICKGOLD"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/trabaja-con-nosotros",
                                        title: "TRABAJA CON NOSOTROS",
                                        children: "TRABAJA CON NOSOTROS"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/preguntas-frecuentes",
                                        title: "PREGUNTA FRECUENTES",
                                        children: "PREGUNTA FRECUENTES"
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const MenuMobil_MenuMobil = (MenuMobil);

// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(3365);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/material/SwipeableDrawer"
var SwipeableDrawer_ = __webpack_require__(4180);
var SwipeableDrawer_default = /*#__PURE__*/__webpack_require__.n(SwipeableDrawer_);
// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(3819);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/componentes/Cabecera/Header.js













const Header = ({ menu_list , sticky , stickyRef  })=>{
    const [state, setState] = external_react_default().useState({
        right: false
    });
    const toggleDrawer = (anchor, open)=>()=>{
            setState({
                ...state,
                [anchor]: open
            });
        };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: (header_module_default()).header,
        id: "to_top",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: (header_module_default()).contenedorLogo,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/",
                            title: "Logo Quickgold",
                            rel: "noopener noreferrer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/assets/img/logo.png",
                                alt: "Quickgold Logo",
                                className: (header_module_default()).logo,
                                width: 163,
                                height: 30
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (header_module_default()).menuHamburquesa,
                        children: [
                            "right"
                        ].map((anchor)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        "aria-label": "Menu Hamburguesa",
                                        onClick: toggleDrawer(anchor, true),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Menu_default()), {})
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((SwipeableDrawer_default()), {
                                        className: (header_module_default()).contenidoMenuMobil,
                                        anchor: anchor,
                                        open: state[anchor],
                                        onClose: toggleDrawer(anchor, false),
                                        onOpen: toggleDrawer(anchor, true),
                                        children: [
                                            " ",
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (header_module_default()).closeBoton,
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {
                                                        onClick: toggleDrawer(anchor, false)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(MenuMobil_MenuMobil, {
                                                menu_list: menu_list,
                                                setState: setState
                                            })
                                        ]
                                    })
                                ]
                            }, anchor))
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (header_module_default()).contenedorRedes,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (header_module_default()).contenedorIconos,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        target: "_blank",
                                        className: (header_module_default()).linkedin,
                                        href: "https://www.linkedin.com/company/quickgold",
                                        title: "Linkedin",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "/assets/img/Vector12.png",
                                                alt: "Quickgold Logo",
                                                className: (header_module_default()).vector,
                                                width: 12,
                                                height: 12
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((LinkedIn_default()), {})
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://www.facebook.com/quickgold.es/",
                                        title: "Facebook",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Facebook_default()), {})
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://www.instagram.com/quickgold.es/",
                                        title: "Instagram",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Instagram_default()), {})
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (header_module_default()).botonLlamar,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "tel:900373629",
                                    title: "Tel\xe9fono",
                                    children: "LLAMA GRATIS"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MenuOrdenador_MenuOrdenador, {
                menu_list: menu_list,
                sticky: sticky,
                stickyRef: stickyRef
            })
        ]
    });
};
/* harmony default export */ const Cabecera_Header = (Header);

// EXTERNAL MODULE: ./src/componentes/Footer/footer.module.css
var footer_module = __webpack_require__(7420);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
// EXTERNAL MODULE: external "@mui/icons-material/Twitter"
var Twitter_ = __webpack_require__(5631);
var Twitter_default = /*#__PURE__*/__webpack_require__.n(Twitter_);
// EXTERNAL MODULE: external "@mui/icons-material/Lock"
var Lock_ = __webpack_require__(2906);
var Lock_default = /*#__PURE__*/__webpack_require__.n(Lock_);
// EXTERNAL MODULE: external "@mui/icons-material/CheckCircle"
var CheckCircle_ = __webpack_require__(6741);
var CheckCircle_default = /*#__PURE__*/__webpack_require__.n(CheckCircle_);
;// CONCATENATED MODULE: ./src/componentes/Footer/Footer.js










const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: (footer_module_default()).contenedorFooter,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (footer_module_default()).contenedorContenidoFooter,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "/",
                        title: "texto",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/assets/img/logo.png",
                            alt: "Quickgold Logo",
                            className: (footer_module_default()).logo,
                            width: 221,
                            height: 42
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (footer_module_default()).contenedorEnlaces,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).enlaces,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: "servicios"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a compro oro",
                                                href: "/compro-oro",
                                                children: "Compra de oro"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a compra divisa",
                                                href: "/cambio-divisas",
                                                children: "Compra de divisas"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a compra plata",
                                                href: "/compro-plata",
                                                children: "Compra de plata"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a compra diamantes",
                                                href: "/vender-diamantes",
                                                children: "Compra de diamantes"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir oro de inversi\xf3n",
                                                href: "/invertir-en-oro",
                                                children: "Oro de inversi\xf3n"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).enlaces,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: "acerca de nosotros"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a conoce quickgold",
                                                href: "/expansion",
                                                children: "Conoce Quickgold"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a localizador tiendas",
                                                href: "/tiendas",
                                                children: "Localizador de tiendas"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a mapa del sitio",
                                                href: "/tiendas",
                                                children: "Mapa del sitio"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).enlaces,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: "\xfanete a quickgold"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a abrir tienda quickgold",
                                                href: "/expansion",
                                                children: "Abrir un tienda Quickgold"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "Ir a trabaja con nosotros",
                                                href: "/trabaja-con-nosotros",
                                                children: "Trabaja con nosotros"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).enlaces,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Llama gratis al"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    title: "Tel\xe9fono",
                                    href: "te:900373629",
                                    children: "900 373 629"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (footer_module_default()).iconosRedes,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            target: "_blank",
                                            title: "Linkedin",
                                            href: "https://www.linkedin.com/company/quickgold",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((LinkedIn_default()), {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            target: "_blank",
                                            title: "Twitter",
                                            className: (footer_module_default()).twitter,
                                            href: "https://twitter.com/quickgoldqg",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Twitter_default()), {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            title: "Facebook",
                                            href: "https://www.facebook.com/quickgold.es/",
                                            target: "_blank",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Facebook_default()), {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            target: "_blank",
                                            title: "Instagram",
                                            href: "https://www.instagram.com/quickgold.es/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Instagram_default()), {})
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (footer_module_default()).politicaPrivacidad,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            title: "pol\xedtica de privacidad",
                            href: "/politica-de-privacidad",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Lock_default()), {}),
                                    " pol\xedtica de privacidad"
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            target: "_blank",
                            title: "pol\xedtica de calidad",
                            href: "https://quickgold.es/doc/politica-calidad-quickgold.pdf",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((CheckCircle_default()), {}),
                                    "pol\xedtica de calidad"
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: (footer_module_default()).linea
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: (footer_module_default()).registro,
                    children: "\xa9 2023 Quickgold | GRUNGO, S.L. - B53910071 - RONDA AUGUSTE Y LOUIS LUMIERE, 23, NAVE 9 46980 PATERNA, VALENCIA - central@quickgold.es - 900 373 629 Registro Mercantil de Valencia , Tomo 9220, Libro 6503, Folio 215, Hoja V-140170, Inscripci\xf3n 2\xaa."
                })
            ]
        })
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

// EXTERNAL MODULE: ./src/componentes/FooterMovil/footerMobil.module.css
var footerMobil_module = __webpack_require__(5319);
var footerMobil_module_default = /*#__PURE__*/__webpack_require__.n(footerMobil_module);
;// CONCATENATED MODULE: ./src/componentes/FooterMovil/FooterMobil.js









const FooterMobil = ()=>{
    const [menuAbierto, setMenuAbierto] = (0,external_react_.useState)(null);
    const [menuAbierto2, setMenuAbierto2] = (0,external_react_.useState)(null);
    const [menuAbierto3, setMenuAbierto3] = (0,external_react_.useState)(null);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (footerMobil_module_default()).footer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/",
                    style: {
                        marginBottom: "14px"
                    },
                    title: "texto",
                    rel: "noopener noreferrer",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        loading: "lazy",
                        src: "/assets/img/logo.png",
                        alt: "Quickgold Logo",
                        className: (footerMobil_module_default()).logo,
                        width: 163,
                        height: 30
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (footerMobil_module_default()).contenedorRedes,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (footerMobil_module_default()).telefono,
                        href: "tel:900373629",
                        children: "900 373 629"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footerMobil_module_default()).redes,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                title: "Linkedin",
                                target: "_blank",
                                href: "https://www.linkedin.com/company/quickgold",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((LinkedIn_default()), {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                title: "Facebook",
                                target: "_blank",
                                href: "https://www.facebook.com/quickgold.es/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Facebook_default()), {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                title: "Instagram",
                                target: "_blank",
                                href: "https://www.instagram.com/quickgold.es/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Instagram_default()), {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                title: "Twitter",
                                target: "_blank",
                                href: "https://twitter.com/quickgoldqg",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Twitter_default()), {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        title: "pol\xedtica de privacidad",
                        href: "/politica-de-privacidad",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "pol\xedtica de privacidad"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        title: "pol\xedtica de calidad",
                        href: "/politica-de-calidad",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "pol\xedtica de calidad"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (footerMobil_module_default()).contenedorMenuFooter,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footerMobil_module_default()).listaMenu,
                        onClick: ()=>{
                            setMenuAbierto(!menuAbierto);
                            setMenuAbierto3(false);
                            setMenuAbierto2(false);
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footerMobil_module_default()).listaMenuTitulo,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "SERVICIOS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: menuAbierto ? `${(footerMobil_module_default()).ul} ${(footerMobil_module_default()).menuActive} ${(footerMobil_module_default()).menuActivo1}` : `${(footerMobil_module_default()).ul}`,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/compro-oro",
                                            title: "Ir a compro oro",
                                            children: "Compra de oro"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/cambio-divisas",
                                            title: "Ir a cambiar divisa",
                                            children: "Cambio divisas"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/compro-plata",
                                            title: "Ir a compro plata",
                                            children: "Compro plata"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/vender-diamantes",
                                            title: "Ir a compra diamantes",
                                            children: "Compra de diamantes"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/invertir-en-oro",
                                            title: "Ir a oro de inversi\xf3n",
                                            children: "Oro de inversion"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footerMobil_module_default()).listaMenu,
                        onClick: ()=>{
                            setMenuAbierto2(!menuAbierto2);
                            setMenuAbierto(false);
                            setMenuAbierto3(false);
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footerMobil_module_default()).listaMenuTitulo,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "ACERCA DE NOSOTROS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: menuAbierto2 ? `${(footerMobil_module_default()).ul} ${(footerMobil_module_default()).menuActive} ${(footerMobil_module_default()).menuActivo1}` : `${(footerMobil_module_default()).ul}`,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/expansion",
                                            title: "Ir a conoce quickgold",
                                            children: "Conoce Quickgold"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/tiendas",
                                            title: "Ir a localizador de tiendas",
                                            children: "Localizador de tiendas"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/",
                                            title: "Ir a mapa del sitio",
                                            children: "Mapa del sitio"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footerMobil_module_default()).listaMenu,
                        onClick: ()=>{
                            setMenuAbierto3(!menuAbierto3);
                            setMenuAbierto(false);
                            setMenuAbierto2(false);
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footerMobil_module_default()).listaMenuTitulo,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "\xdaNETE A QUICKGOLD"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: menuAbierto3 ? `${(footerMobil_module_default()).ul} ${(footerMobil_module_default()).menuActive} ${(footerMobil_module_default()).menuActivo1}` : `${(footerMobil_module_default()).ul}`,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/expansion",
                                            title: "Ir abrir tienda quickgold",
                                            children: "Abrir una tienda Quickgold"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/trabaja-con-nosotros",
                                            title: "Ir a trabaja con nosotros",
                                            children: "Trabaja con nosotros"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: (footerMobil_module_default()).textoFooter,
                children: "\xa9 2023 Quickgold | GRUNGO, S.L. - B53910071 - RONDA AUGUSTE Y LOUIS LUMIERE, 23, NAVE 9 46980 PATERNA, VALENCIA - central@quickgold.es - 900 373 629 Registro Mercantil de Valencia , Tomo 9220, Libro 6503, Folio 215, Hoja V-140170, Inscripci\xf3n 2\xaa. Pol\xedtica de privacidad \xb7 Pol\xedtica de Calidad"
            })
        ]
    });
};
/* harmony default export */ const FooterMovil_FooterMobil = (FooterMobil);

;// CONCATENATED MODULE: ./src/utilities/useSticky.js

const useSticky = ()=>{
    const stickyRef = (0,external_react_.useRef)(null);
    const [sticky, setSticky] = (0,external_react_.useState)(false);
    const [offset, setOffset] = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        if (!stickyRef.current) {
            return;
        }
        setOffset(stickyRef.current.offsetTop);
    }, [
        stickyRef,
        setOffset
    ]);
    (0,external_react_.useEffect)(()=>{
        const handleScroll = ()=>{
            if (!stickyRef.current) {
                return;
            }
            setSticky(window.scrollY > offset);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, [
        setSticky,
        stickyRef,
        offset
    ]);
    return {
        stickyRef,
        sticky
    };
};
/* harmony default export */ const utilities_useSticky = (useSticky);

// EXTERNAL MODULE: external "react-scroll-to-top"
var external_react_scroll_to_top_ = __webpack_require__(5337);
var external_react_scroll_to_top_default = /*#__PURE__*/__webpack_require__.n(external_react_scroll_to_top_);
;// CONCATENATED MODULE: ./src/componentes/Layout/Layout.js







function Layout({ children , menu_list , ciudad  }) {
    const { sticky , stickyRef  } = utilities_useSticky();
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
            className: (layout_module_default()).contenedor,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Cabecera_Header, {
                    menu_list: menu_list,
                    sticky: sticky,
                    stickyRef: stickyRef
                }),
                children,
                /*#__PURE__*/ jsx_runtime_.jsx(FooterMovil_FooterMobil, {}),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {}),
                /*#__PURE__*/ jsx_runtime_.jsx((external_react_scroll_to_top_default()), {
                    smooth: true
                })
            ]
        })
    });
}


/***/ })

};
;