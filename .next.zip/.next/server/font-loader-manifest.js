self.__FONT_LOADER_MANIFEST={
  "pages": {
    "/": [
      "static/media/2aaf0723e720e8b9.p.woff2"
    ]
  },
  "app": {}
}