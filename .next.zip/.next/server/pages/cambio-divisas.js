(() => {
var exports = {};
exports.id = 9107;
exports.ids = [9107];
exports.modules = {

/***/ 4574:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueDer": "selecCiudad_bloqueDer__StNdY",
	"contenidoBloqueDer": "selecCiudad_contenidoBloqueDer__zLQZD",
	"linea": "selecCiudad_linea__cEeRj",
	"bloqueSuperiorTexto": "selecCiudad_bloqueSuperiorTexto__r36Mb",
	"bloqueIzqInferior": "selecCiudad_bloqueIzqInferior__U2Vnc",
	"bloqueInferior": "selecCiudad_bloqueInferior__rRsaR",
	"bloqueInferiorTexto1": "selecCiudad_bloqueInferiorTexto1__wmlkt",
	"bloqueInferiorTexto2": "selecCiudad_bloqueInferiorTexto2__ryBP4",
	"bloqueInferiorTexto3": "selecCiudad_bloqueInferiorTexto3__WMpk7",
	"ContenedorSelect": "selecCiudad_ContenedorSelect__42WIJ",
	"select": "selecCiudad_select__Vwxjm",
	"botonIrCiudad": "selecCiudad_botonIrCiudad__p_AhZ",
	"bloqueInferiorTexto4": "selecCiudad_bloqueInferiorTexto4__YnaK_",
	"botonLlamar": "selecCiudad_botonLlamar__o1lvf"
};


/***/ }),

/***/ 2116:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__e5pKc",
	"linea": "section_uno_linea__xlEVS",
	"bloqueIzq": "section_uno_bloqueIzq__l6uTH",
	"bloqueDer": "section_uno_bloqueDer__egEYK",
	"madridMobil": "section_uno_madridMobil__N4qEg",
	"botones": "section_uno_botones__jcfXI",
	"botonPopUp": "section_uno_botonPopUp__eSfVA"
};


/***/ }),

/***/ 254:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCuatro": "sectionCuatro_contenedorSectionCuatro__Af03G",
	"contenedorSectionCuatroMargen": "sectionCuatro_contenedorSectionCuatroMargen__RP3hm",
	"bloqueDerMobil": "sectionCuatro_bloqueDerMobil__XmqQc",
	"bloqueDerPc": "sectionCuatro_bloqueDerPc__Bp1yb",
	"botonPopUp": "sectionCuatro_botonPopUp__8Hj2n",
	"bloqueDerLista": "sectionCuatro_bloqueDerLista__lZebD",
	"adornoMobil": "sectionCuatro_adornoMobil__oKmAj",
	"bloqueSuperiorTexto": "sectionCuatro_bloqueSuperiorTexto__F7ywv",
	"botonLlamar": "sectionCuatro_botonLlamar__tBgRh"
};


/***/ }),

/***/ 6406:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionDos": "sectionDos_contenedorSectionDos__nuv6Y",
	"bloqueInferior": "sectionDos_bloqueInferior__NMRW9",
	"bloqueSuperior": "sectionDos_bloqueSuperior__FyHSX",
	"imagenventaja1": "sectionDos_imagenventaja1__ohV6F",
	"contenedorVentajas": "sectionDos_contenedorVentajas__Vvn4B",
	"linea": "sectionDos_linea__zWBzi"
};


/***/ }),

/***/ 2661:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionTres": "sectionTres_contenedorSectionTres__2bXJ3",
	"linea": "sectionTres_linea__1mM_w",
	"bloqueDer": "sectionTres_bloqueDer__gzG1q",
	"bloqueIzq": "sectionTres_bloqueIzq__P0wT0",
	"contenedorInfoTres": "sectionTres_contenedorInfoTres__XwCWd",
	"cards": "sectionTres_cards__MbJMe",
	"subTitulo": "sectionTres_subTitulo__Rkgnd",
	"subParrafo": "sectionTres_subParrafo__kFZmh",
	"bloqueTextoMobil": "sectionTres_bloqueTextoMobil__Tfndd"
};


/***/ }),

/***/ 5982:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCinco": "sectionCinco_contenedorSectionCinco__t98dc",
	"bloqueInferior": "sectionCinco_bloqueInferior__LtVj4",
	"bloqueSuperior": "sectionCinco_bloqueSuperior__jGF_A",
	"contenedorVentajas1": "sectionCinco_contenedorVentajas1__kEc0y",
	"contenedorVentajas2": "sectionCinco_contenedorVentajas2__JBReJ",
	"contenedorVentajas3": "sectionCinco_contenedorVentajas3__e2Uaq",
	"contenedorVentajas4": "sectionCinco_contenedorVentajas4__Hx02F",
	"contenedorVentajas5": "sectionCinco_contenedorVentajas5__gBZ3B",
	"contenedorVentajas6": "sectionCinco_contenedorVentajas6__VlYEu",
	"linea": "sectionCinco_linea__JvN09"
};


/***/ }),

/***/ 8253:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCincoMobil": "sectionCincoMobil_contenedorSectionCincoMobil__Xrp4k",
	"bloqueInferior": "sectionCincoMobil_bloqueInferior__Utf14",
	"bloqueSuperior": "sectionCincoMobil_bloqueSuperior__mxzqG",
	"imagenventaja1": "sectionCincoMobil_imagenventaja1__gne9x",
	"contenedorVentajas": "sectionCincoMobil_contenedorVentajas__R6Rx4",
	"linea": "sectionCincoMobil_linea___ShOQ",
	"botones": "sectionCincoMobil_botones__keUKq",
	"botonPopUp": "sectionCincoMobil_botonPopUp__OVaRq",
	"texto": "sectionCincoMobil_texto__ub4zk"
};


/***/ }),

/***/ 3578:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionSeis": "sectionSeis_contenedorSectionSeis__x5bDc",
	"contenedorSectionSeisMargen": "sectionSeis_contenedorSectionSeisMargen__mUgod",
	"BannerSelectorCiudad": "sectionSeis_BannerSelectorCiudad__nLaIS",
	"tituloMobil": "sectionSeis_tituloMobil__yk9xI",
	"SelectCiudades": "sectionSeis_SelectCiudades__OaqkP",
	"contenedorTexto": "sectionSeis_contenedorTexto__z3Lsy",
	"contenedorTiposDivisas": "sectionSeis_contenedorTiposDivisas__P8cEj",
	"contenedorTiposDivisasCard1": "sectionSeis_contenedorTiposDivisasCard1__uFYFe"
};


/***/ }),

/***/ 1068:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_uno_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2116);
/* harmony import */ var _section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utilities_useScreenSize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(771);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_4__);






const Section_uno = ({ ciudad  })=>{
    const { width  } = (0,_utilities_useScreenSize__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().contenedorSectionUno),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().bloqueIzq),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        children: "Cambiar divisas al instante y sin comisiones"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Cambiar moneda extranjera en quickgold es muy f\xe1cil y r\xe1pido. Tenemos m\xe1s de 30 divisas disponibles para que puedas realizar tu cambio al mejor precio y de forma inmediata, sin esperas."
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().botones),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_scroll__WEBPACK_IMPORTED_MODULE_4__.Link, {
                                to: "calculadora",
                                smooth: true,
                                offset: -110,
                                spy: true,
                                duration: 500,
                                title: "texto",
                                passive: "true",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().botonPopUp),
                                    title: "texto",
                                    children: "CONOCE EL PRECIO DE LA DIVISA"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().botonLlamar),
                                href: `tel:${ciudad?.acf?.telefono}`,
                                title: "Tel\xe9fono",
                                children: "llama gratis"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().bloqueDer),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: "/assets/img/imagenCambiarDivisa.png",
                    alt: "Cambio Divisas",
                    className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_5___default().madridMobil),
                    width: 480,
                    height: 364,
                    priority: true
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_uno);


/***/ }),

/***/ 7509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Section_dos)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/Cambio-divisas/Section_2/sectionCuatro.module.css
var sectionCuatro_module = __webpack_require__(254);
var sectionCuatro_module_default = /*#__PURE__*/__webpack_require__.n(sectionCuatro_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/componentes/Cambio-divisas/ComponenteSelectCiudades/selecCiudad.module.css
var selecCiudad_module = __webpack_require__(4574);
var selecCiudad_module_default = /*#__PURE__*/__webpack_require__.n(selecCiudad_module);
;// CONCATENATED MODULE: ./src/componentes/Cambio-divisas/ComponenteSelectCiudades/SelectCiudad.js




const SelectCiudad = ({ listadoCiudades , urlSelect , setUrlSelect , ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "calculadora",
        className: (selecCiudad_module_default()).bloqueDer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (selecCiudad_module_default()).bloqueSuperiorTexto,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Cambio de divisa"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Descubre el valor de la moneda que te interesa."
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (selecCiudad_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto1,
                        children: "\xbfTe gustar\xeda comprar o vender divisa?"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto2,
                        children: [
                            "Realiza en ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "quickgold"
                            }),
                            " tu cambio de moneda extranjera sin comisiones para siempre. M\xe1s de 25 divisas disponibles al instante para que puedas fijar tu precio de cambio. Consulta la cotizaci\xf3n de la moneda que quieras con nuestro conversor online."
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto3,
                        children: [
                            "Selecciona tu ciudad y haz clic en",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "cambio y compra de divisa "
                            }),
                            "para saberlo."
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (selecCiudad_module_default()).ContenedorSelect,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                onChange: (e)=>{
                                    setUrlSelect(e.target.value);
                                },
                                className: (selecCiudad_module_default()).select,
                                children: listadoCiudades.map((ciudad, i)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: ciudad.nombreMinusculas,
                                        children: ciudad.nombre
                                    }, i))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                className: (selecCiudad_module_default()).botonIrCiudad,
                                href: `/tiendas/compro-oro-${urlSelect}`,
                                children: "CONOCE EL PRECIO DE LA DIVISA"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto4,
                        children: "Si lo prefieres, tambi\xe9n puedes llamarnos e informarte. \xa1Estaremos encantados de resolver todas tus dudas!"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: `tel:${ciudad?.acf?.telefono}`,
                        className: (selecCiudad_module_default()).botonLlamar,
                        children: "LLAMA GRATIS"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ComponenteSelectCiudades_SelectCiudad = (SelectCiudad);

;// CONCATENATED MODULE: ./src/componentes/Cambio-divisas/Section_2/Section_dos.js






const Section_cuatro = ({ ciudad , listadoUrlCiudad  })=>{
    const [urlSelect, setUrlSelect] = (0,external_react_.useState)("");
    const listadoCiudades = listadoUrlCiudad?.arrayMarker;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionCuatro_module_default()).contenedorSectionCuatro,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ComponenteSelectCiudades_SelectCiudad, {
                listadoCiudades: listadoCiudades,
                urlSelect: urlSelect,
                setUrlSelect: setUrlSelect,
                ciudad: ciudad
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCuatro_module_default()).bloqueDerPc,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Consigue el mejor cambio a euros hoy. Precios siempre actualizados."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/img/adornoCalculadoraDivisa.png",
                        width: 227,
                        height: 218,
                        alt: "cambio divisas"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCuatro_module_default()).bloqueDerMobil,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "\xbfQu\xe9 divisa compramos?"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: (sectionCuatro_module_default()).bloqueDerLista,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "Compramos divisa extranjera en circulaci\xf3n."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "No compramos monedas, solo billetes."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    "Consulta en el desplegable de la calculadora las diferentes divisas que aceptamos.",
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "No cobramos ninguna comisi\xf3n."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (sectionCuatro_module_default()).botonLlamar,
                        href: `tel:${ciudad?.acf?.telefono}`,
                        title: "Tel\xe9fono",
                        children: "Llama gratis"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_dos = (Section_cuatro);


/***/ }),

/***/ 5379:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6406);
/* harmony import */ var _sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Section_dos = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionDos),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueSuperior),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        children: "\xbfNecesitas cambiar divisa?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "*Para realizar cambios de divisa es necesario ser mayor de edad y aportar documento de identidad en vigor."
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueInferior),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagensectiondos1.png",
                                    alt: "Mejor servicio y precio",
                                    width: 40,
                                    height: 42
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Cambiar moneda extranjera en quickgold es muy f\xe1cil, r\xe1pido, barato y c\xf3modo."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagensectiondos2.png",
                                    alt: "Mejor servicio y precio",
                                    width: 39,
                                    height: 36
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Realizamos la transacci\xf3n al momento, sin esperas y comisiones."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionDos_module_css__WEBPACK_IMPORTED_MODULE_3___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagensectiondos3.png",
                                    alt: "Mejor servicio y precio",
                                    width: 36,
                                    height: 36
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Recibes tu cambio al instante y sin coste adicional."
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_dos);


/***/ }),

/***/ 7063:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2661);
/* harmony import */ var _sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2__);



const SectionTres = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorSectionTres),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                children: [
                    "Cambiar divisa en ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().linea),
                        children: "quickgold"
                    }),
                    " es muy f\xe1cil"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().bloqueTextoMobil),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: "Cambiar divisa en cualquiera de nuestras tiendas tan solo te llevar\xe1 unos minutos."
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorInfoTres),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().cards),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Ind\xedcanos la divisa que quieres cambiar"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().cards),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Acordamos precio. \xa1Hacemos mejoras por cantidad!"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().cards),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Recibe el dinero en efectivo al instante"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().subTitulo),
                children: "Consigue el mejor cambio a euros hoy. Precios siempre actualizados."
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: (_sectionTres_module_css__WEBPACK_IMPORTED_MODULE_2___default().subParrafo),
                children: [
                    "Selecciona la ciudad donde vas a realizar el cambio y obt\xe9n al momento el precio actualizado por tu operaci\xf3n. ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                    "No cobramos ninguna comisi\xf3n por lo que ver\xe1s el precio final que podr\xe1s fijar llam\xe1ndonos gratuitamente al",
                    " ",
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: `tel:${ciudad?.acf?.telefono}`,
                                children: ciudad?.acf?.telefono
                            }),
                            "."
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionTres);


/***/ }),

/***/ 874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5982);
/* harmony import */ var _sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Section_cinco = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionCinco),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueSuperior),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                    children: [
                        "\xbfPor qu\xe9 cambiar divisa en",
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().linea),
                            children: "quickgold"
                        }),
                        "?"
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueInferior),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas1),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Mejor servicio y precio garantizado"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas2),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "El mejor precio de tu ciudad"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas3),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Mejora de precio seg\xfan cantidad"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas4),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Premiamos tu fidelidad al traer un amigo"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas5),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Mejoramos el precio si vienes en grupo"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sectionCinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorVentajas6),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Reserva gratuita de m\xe1s de 30 divisas"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_cinco);


/***/ }),

/***/ 179:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8253);
/* harmony import */ var _sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_3__);





const Section_cinco_mobil = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorSectionCincoMobil),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueSuperior),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                    children: [
                        "Por qu\xe9 cambiar divisa en",
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().linea),
                            children: "quickgold"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueInferior),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagenSeccionCincoMobil1.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Cambio de divisas sin comisiones y al instante."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagenSeccionCincoMobil2.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "El mejor precio de tu ciudad."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagenSeccionCincoMobil3.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Mejora de precio seg\xfan cantidad."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagenSeccionCincoMobil4.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Premiamos tu fidelidad al traer a un amigo."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagenSeccionCincoMobil5.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Mejoramos el precio si vienes en grupo."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorVentajas),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().imagenventaja1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/imagenSeccionCincoMobil6.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Reserva gratuita de m\xe1s de 30 divisas."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().botones),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_scroll__WEBPACK_IMPORTED_MODULE_3__.Link, {
                    to: "calculadoraDivisa",
                    smooth: true,
                    offset: -110,
                    spy: true,
                    duration: 500,
                    title: "texto",
                    passive: "true",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().botonPopUp),
                        title: "texto",
                        children: "CONOCE EL PRECIO DE LA DIVISA"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_sectionCincoMobil_module_css__WEBPACK_IMPORTED_MODULE_4___default().texto),
                children: "Informaci\xf3n de inter\xe9s"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_cinco_mobil);


/***/ }),

/***/ 2639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sectionSeis_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3578);
/* harmony import */ var _sectionSeis_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_sectionSeis_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _componentes_SelectorCiudadesServicio_SelectorCiudadesServicio__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5709);




const Section_seis = ({ ciudad , divisas_list , listadoCiudadesServicios  })=>{
    const divisas = divisas_list?.result.Tarifas?.Divisas_Compra;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_sectionSeis_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionSeis),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_sectionSeis_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionSeisMargen),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_sectionSeis_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorTexto),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Cambio de divisa en quickgold"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_sectionSeis_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorTiposDivisas),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sectionSeis_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorTiposDivisasCard1),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            children: divisas?.filter((currency)=>currency.Name !== "HRK" && currency.Name !== "DKK" && currency.Name !== "RUB" && currency.Name !== "NOK" && currency.Name !== "ILS" && currency.Name !== "SEK").map((divisa, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: divisa?.Productos[0]?.Nombre
                                }, index))
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_seis);


/***/ }),

/***/ 2493:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CambioDivisas),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _componentes_BreadcrumbsRaiz_Breadcrumbs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9206);
/* harmony import */ var _mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(547);
/* harmony import */ var _mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8874);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _componentes_Layout_Layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7699);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4009);
/* harmony import */ var _bradgarropy_next_seo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4579);
/* harmony import */ var _bradgarropy_next_seo__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_bradgarropy_next_seo__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _componentes_Cambio_divisas_Section_1_Section_uno__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1068);
/* harmony import */ var _componentes_Cambio_divisas_Section_2_Section_dos__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7509);
/* harmony import */ var _componentes_Cambio_divisas_Section_3_Section_tres__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5379);
/* harmony import */ var _componentes_Cambio_divisas_Section_4_SectionCuatro__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7063);
/* harmony import */ var _componentes_Cambio_divisas_Section_5_Section_cinco__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(874);
/* harmony import */ var _componentes_Cambio_divisas_Section_5_mobil_Section_cinco_mobil__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(179);
/* harmony import */ var _componentes_Cambio_divisas_Section_6_Section_seis__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2639);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_intersection_observer__WEBPACK_IMPORTED_MODULE_6__]);
react_intersection_observer__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


//import Image from "next/image";














function CambioDivisas({ menu_list , ciudad , divisas_list , listadoUrlCiudad , listadoCiudadesServicios  }) {
    const { ref: myRef , inView , entry  } = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_6__.useInView)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_bradgarropy_next_seo__WEBPACK_IMPORTED_MODULE_7___default()), {
                title: ciudad?.acf?.titulo_del_meta,
                description: ciudad?.acf?.descripcion_del_meta,
                icon: "/favicon.png",
                facebook: {
                    image: "/facebook.png",
                    url: "https://www.facebook.com/quickgold.es/",
                    type: "article"
                },
                twitter: {
                    image: "/twitter.png",
                    site: "@quickgoldQG",
                    card: "summary_large_image"
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "stylesheet preload prefetch",
                        href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css",
                        as: "style"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("noscript", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "stylesheet",
                            href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_componentes_Layout_Layout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                menu_list: menu_list,
                ciudad: ciudad,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_15___default().main),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_BreadcrumbsRaiz_Breadcrumbs_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                raiz: "Quickgold",
                                iconoRaiz: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                                urlUbicacionActual: "/cambio-divisas/",
                                iconoUbiccionActual: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                                ubicacionActual: "Cambio Divisa"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_Cambio_divisas_Section_1_Section_uno__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                ciudad: ciudad
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_Cambio_divisas_Section_2_Section_dos__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                ciudad: ciudad,
                                listadoUrlCiudad: listadoUrlCiudad
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_Cambio_divisas_Section_3_Section_tres__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                ciudad: ciudad
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_Cambio_divisas_Section_4_SectionCuatro__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                ciudad: ciudad
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_Cambio_divisas_Section_5_Section_cinco__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_Cambio_divisas_Section_5_mobil_Section_cinco_mobil__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_Cambio_divisas_Section_6_Section_seis__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        ciudad: ciudad,
                        divisas_list: divisas_list,
                        listadoCiudadesServicios: listadoCiudadesServicios
                    })
                ]
            })
        ]
    });
}
const idTienda = "cambiardivisas";
const idPaginaWp = "404";
const apiGeneral = "13848";
//const idWp = "13848";
async function getStaticProps() {
    //datos de los campos personalizados de la ciudad
    const ciudad1 = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${idPaginaWp}`);
    const ciudad = await ciudad1.json();
    //fin datos de los campos personalizados de la ciudad
    const res = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${apiGeneral}`);
    const general = await res.json();
    /*const response = await fetch(
    `https://quickgold.es/wp-json/wp/v2/pages/${idWp}`
  );
  const dataIdWp = await response.json();*/ const menu = await fetch(`https://panel.quickgold.es/wp-json/menus/v1/menus/2219`);
    const menu_list = await menu.json();
    const divisas = await fetch(`https://panel.quickgold.es/archivos-cache/Fixingmadrid.txt`);
    const divisas_list = await divisas.json();
    const Listado = await fetch(`https://panel.quickgold.es/ListadoDeUrlDeCiudad/listadoUrlCiudad.json`);
    const listadoUrlCiudad = await Listado.json();
    const listadoServicio = await fetch(`https://panel.quickgold.es/ListadoCiudadesServicio/listadoCiudadesServicioDivisa.json`);
    const listadoCiudadesServicios = await listadoServicio.json();
    return {
        props: {
            menu_list,
            ciudad,
            divisas_list,
            listadoUrlCiudad,
            listadoCiudadesServicios
        },
        revalidate: 1
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

if (false) { var height1, width1; }
const useScreenSize = ()=>{
    const [width, setWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(width1);
    const [height, setHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(height1);
    if (false) {}
    return {
        width,
        height
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScreenSize);


/***/ }),

/***/ 4579:
/***/ ((module) => {

"use strict";
module.exports = require("@bradgarropy/next-seo");

/***/ }),

/***/ 6741:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CheckCircle");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 7666:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 547:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowRight");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 2906:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 5631:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4180:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/SwipeableDrawer");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 5337:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll-to-top");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4009:
/***/ ((module) => {

"use strict";
module.exports = import("react-intersection-observer");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,5675,3573,676,1664,5152,7699,5799,5709], () => (__webpack_exec__(2493)));
module.exports = __webpack_exports__;

})();