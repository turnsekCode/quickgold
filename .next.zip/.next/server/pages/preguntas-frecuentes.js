(() => {
var exports = {};
exports.id = 8510;
exports.ids = [8510];
exports.modules = {

/***/ 4135:
/***/ ((module) => {

// Exports
module.exports = {
	"tituloAccordion": "accordionCambioDivisa_tituloAccordion__gEdOl",
	"contenedorTituloAccordion": "accordionCambioDivisa_contenedorTituloAccordion__0darW",
	"contenedorAccordion": "accordionCambioDivisa_contenedorAccordion__r8v2a",
	"contenerdorContenidoAccordion": "accordionCambioDivisa_contenerdorContenidoAccordion__ci5X7",
	"contenidoAccordion": "accordionCambioDivisa_contenidoAccordion__vCtUv"
};


/***/ }),

/***/ 5327:
/***/ ((module) => {

// Exports
module.exports = {
	"tituloAccordion": "accordionEmpenos_tituloAccordion__CbvdB",
	"contenedorTituloAccordion": "accordionEmpenos_contenedorTituloAccordion__6mIgm",
	"contenedorAccordion": "accordionEmpenos_contenedorAccordion__wUXX0",
	"contenerdorContenidoAccordion": "accordionEmpenos_contenerdorContenidoAccordion__U8zc9",
	"contenidoAccordion": "accordionEmpenos_contenidoAccordion__JPWE1"
};


/***/ }),

/***/ 6559:
/***/ ((module) => {

// Exports
module.exports = {
	"tituloAccordion": "accordionFranquicia_tituloAccordion__VPN7m",
	"contenedorTituloAccordion": "accordionFranquicia_contenedorTituloAccordion__IqMLw",
	"contenedorAccordion": "accordionFranquicia_contenedorAccordion__lHgos",
	"contenerdorContenidoAccordion": "accordionFranquicia_contenerdorContenidoAccordion__98khr",
	"contenidoAccordion": "accordionFranquicia_contenidoAccordion__gDRYK"
};


/***/ }),

/***/ 7075:
/***/ ((module) => {

// Exports
module.exports = {
	"tituloAccordion": "accordionInvertirOro_tituloAccordion__4mG2G",
	"contenedorTituloAccordion": "accordionInvertirOro_contenedorTituloAccordion__tj80y",
	"contenedorAccordion": "accordionInvertirOro_contenedorAccordion__cO39n",
	"contenerdorContenidoAccordion": "accordionInvertirOro_contenerdorContenidoAccordion__gsh_4",
	"contenidoAccordion": "accordionInvertirOro_contenidoAccordion__6AHUG"
};


/***/ }),

/***/ 8329:
/***/ ((module) => {

// Exports
module.exports = {
	"tituloAccordion": "accordionVenderDiamantes_tituloAccordion__85P2S",
	"contenedorTituloAccordion": "accordionVenderDiamantes_contenedorTituloAccordion__LOmQB",
	"contenedorAccordion": "accordionVenderDiamantes_contenedorAccordion__9scp8",
	"contenerdorContenidoAccordion": "accordionVenderDiamantes_contenerdorContenidoAccordion__egzZ0",
	"contenidoAccordion": "accordionVenderDiamantes_contenidoAccordion__N1IVF"
};


/***/ }),

/***/ 3662:
/***/ ((module) => {

// Exports
module.exports = {
	"tituloAccordion": "accordionVenderMetales_tituloAccordion__AQtI3",
	"contenedorTituloAccordion": "accordionVenderMetales_contenedorTituloAccordion__ruPjD",
	"contenedorAccordion": "accordionVenderMetales_contenedorAccordion___lnTC",
	"contenerdorContenidoAccordion": "accordionVenderMetales_contenerdorContenidoAccordion__SruG0",
	"contenidoAccordion": "accordionVenderMetales_contenidoAccordion__RsoId"
};


/***/ }),

/***/ 5943:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorBloqueSuperior": "sectionUno_contenedorBloqueSuperior__WA54e",
	"bloqueIzq": "sectionUno_bloqueIzq__rk0k8",
	"bloqueDer": "sectionUno_bloqueDer__xcZDo"
};


/***/ }),

/***/ 2352:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueIzq": "sectionDos_bloqueIzq__itf2m",
	"botonTabs": "sectionDos_botonTabs__51nSm",
	"bloqueIzqTexto": "sectionDos_bloqueIzqTexto__bqz_F",
	"contenidoTabs": "sectionDos_contenidoTabs__sL9kF",
	"box": "sectionDos_box__aFjMH"
};


/***/ }),

/***/ 271:
/***/ ((module) => {

// Exports
module.exports = {
	"tituloPreguntas": "section_dos_mobil_tituloPreguntas__OxN2d",
	"contenedorSectionDosMobiContenidoUltimo": "section_dos_mobil_contenedorSectionDosMobiContenidoUltimo__gmjVS",
	"contenedorSectionDosMobil": "section_dos_mobil_contenedorSectionDosMobil__q_Dzg"
};


/***/ }),

/***/ 3582:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorImagenFondo": "sectionTres_contenedorImagenFondo__DKGxG",
	"contenedorTexto": "sectionTres_contenedorTexto__E9jrh"
};


/***/ }),

/***/ 8659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ PreguntasFrecuentes),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/componentes/BreadcrumbsRaiz/Breadcrumbs.js
var Breadcrumbs = __webpack_require__(9206);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowRight"
var KeyboardArrowRight_ = __webpack_require__(547);
var KeyboardArrowRight_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowRight_);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(8874);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: ./src/componentes/Layout/Layout.js + 6 modules
var Layout = __webpack_require__(7699);
// EXTERNAL MODULE: external "@bradgarropy/next-seo"
var next_seo_ = __webpack_require__(4579);
var next_seo_default = /*#__PURE__*/__webpack_require__.n(next_seo_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/Section_1/sectionUno.module.css
var sectionUno_module = __webpack_require__(5943);
var sectionUno_module_default = /*#__PURE__*/__webpack_require__.n(sectionUno_module);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/Section_1/Section_uno.js



const Section_uno = ({ ciudad  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (sectionUno_module_default()).contenedorSectionUno,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (sectionUno_module_default()).contenedorBloqueSuperior,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (sectionUno_module_default()).bloqueIzq
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionUno_module_default()).bloqueDer,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            children: "Preguntas frecuentes"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            children: [
                                "\xbfNo encuentras la respuesta que estabas buscando? Llama gratis al",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "tel:900373629",
                                    children: "900 373 629"
                                }),
                                " o env\xedanos un correo a",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "mailto:central@quickgold.es",
                                    children: "central@quickgold.es"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Section_1_Section_uno = (Section_uno);

;// CONCATENATED MODULE: external "prop-types"
const external_prop_types_namespaceObject = require("prop-types");
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Tabs"
const Tabs_namespaceObject = require("@mui/material/Tabs");
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Tab"
const Tab_namespaceObject = require("@mui/material/Tab");
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Typography"
const Typography_namespaceObject = require("@mui/material/Typography");
;// CONCATENATED MODULE: external "@mui/material/Box"
const Box_namespaceObject = require("@mui/material/Box");
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_namespaceObject);
// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/Section_2/sectionDos.module.css
var sectionDos_module = __webpack_require__(2352);
var sectionDos_module_default = /*#__PURE__*/__webpack_require__.n(sectionDos_module);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: external "@mui/material/Accordion"
var Accordion_ = __webpack_require__(9409);
var Accordion_default = /*#__PURE__*/__webpack_require__.n(Accordion_);
// EXTERNAL MODULE: external "@mui/material/AccordionSummary"
var AccordionSummary_ = __webpack_require__(4604);
var AccordionSummary_default = /*#__PURE__*/__webpack_require__.n(AccordionSummary_);
// EXTERNAL MODULE: external "@mui/material/AccordionDetails"
var AccordionDetails_ = __webpack_require__(8279);
var AccordionDetails_default = /*#__PURE__*/__webpack_require__.n(AccordionDetails_);
// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/AccordionFranquicia/accordionFranquicia.module.css
var accordionFranquicia_module = __webpack_require__(6559);
var accordionFranquicia_module_default = /*#__PURE__*/__webpack_require__.n(accordionFranquicia_module);
;// CONCATENATED MODULE: external "@mui/icons-material/AddRounded"
const AddRounded_namespaceObject = require("@mui/icons-material/AddRounded");
var AddRounded_default = /*#__PURE__*/__webpack_require__.n(AddRounded_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/HorizontalRuleRounded"
const HorizontalRuleRounded_namespaceObject = require("@mui/icons-material/HorizontalRuleRounded");
var HorizontalRuleRounded_default = /*#__PURE__*/__webpack_require__.n(HorizontalRuleRounded_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/AccordionFranquicia/AccordiosFranquicia.js









const Accordion = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()), {
        disableGutters: true,
        elevation: 0,
        square: true,
        ...props
    }))(({ theme  })=>({
        border: `1px solid ${theme.palette.divider}`,
        "&:not(:last-child)": {
            borderBottom: 0
        },
        "&:before": {
            display: "none"
        }
    }));
const AccordionSummary = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((AccordionSummary_default()), {
        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {
            sx: {
                display: "none"
            }
        }),
        ...props
    }))(({ theme  })=>({
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, .05)" : "rgba(0, 0, 0, .03)",
        flexDirection: "row-reverse",
        "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
            transform: "rotate(90deg)"
        },
        "& .MuiAccordionSummary-content": {
            marginLeft: theme.spacing(1)
        }
    }));
const AccordionDetails = (0,styles_.styled)((AccordionDetails_default()))(({ theme  })=>({
        padding: theme.spacing(2),
        borderTop: "1px solid rgba(0, 0, 0, .125)"
    }));
function AccordiosnFranquicia() {
    const [expanded, setExpanded] = external_react_.useState(false);
    const handleChange = (panel)=>(event, newExpanded)=>{
            setExpanded(newExpanded ? panel : false);
        };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel1",
                onChange: handleChange("panel1"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel1d-content",
                        id: "panel1d-header",
                        children: [
                            expanded == "panel1" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfEn qu\xe9 se diferencia la franquicia quickgold de otras franquicias compro oro?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Adem\xe1s de la dilatada experiencia y grandes resultados en el sector, la diferencia principal radica en una central formada por excelentes profesionales en cada uno de sus departamentos, formaci\xf3n, administraci\xf3n, marketing, social media, etc. Trabajando para que tu negocio funcione de manera correcta. Esto se suma al hecho de tener establecimientos propios que nos hacen estar al corriente de forma diaria de todo lo que acontece en el sector."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel2",
                onChange: handleChange("panel2"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel2d-content",
                        id: "panel2d-header",
                        children: [
                            " ",
                            expanded == "panel2" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfQu\xe9 perfil de trabajador se necesita?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Desde la central de quickgold, os asesoramos y ayudamos en el proceso de contrataci\xf3n del personal, tambi\xe9n os indicamos cual es el perfil id\xf3neo para trabajar en nuestras tiendas."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel3",
                onChange: handleChange("panel3"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel3d-content",
                        id: "panel3d-header",
                        children: [
                            " ",
                            expanded == "panel3" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfC\xf3mo aprender\xe9 a tasar las piezas de oro y plata?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Tanto el franquiciado como los empleados que vayan a trabajar en el establecimiento, recibir\xe1n una formaci\xf3n completa sobre todos los procesos de comprobaci\xf3n y tasaci\xf3n de piezas, el curso incluye pr\xe1cticas en nuestros establecimientos propios."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel4",
                onChange: handleChange("panel4"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel4d-content",
                        id: "panel4d-header",
                        children: [
                            " ",
                            expanded == "panel4" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfQu\xe9 licencias o permisos necesito para abrir un establecimiento quickgold?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Durante todo proceso de apertura del establecimiento te acompa\xf1amos, asesoramos e informamos de todas las licencias y permisos necesarios."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel5",
                onChange: handleChange("panel5"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel5d-content",
                        id: "panel5d-header",
                        children: [
                            " ",
                            expanded == "panel5" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfCu\xe1nto tiempo se tarda en abrir un quickgold?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Una vez tengamos firmado el local, el proceso de apertura depende de la ciudad elegida y los permisos que sean necesarios, como media el proceso completo dura de 45 a 60 d\xedas aproximadamente."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel6",
                onChange: handleChange("panel6"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel6d-content",
                        id: "panel6d-header",
                        children: [
                            " ",
                            expanded == "panel6" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfMe ayudan con la reforma del local?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Con la firma del contrato de franquicia, te haremos entrega de un manual constructivo para que tengas toda la informaci\xf3n necesaria para instalar un establecimiento quickgold, adem\xe1s, te asesoramos y facilitamos proveedores, si los necesitas, para la reforma del local."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel7",
                onChange: handleChange("panel7"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel7d-content",
                        id: "panel7d-header",
                        children: [
                            " ",
                            expanded == "panel7" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfTendr\xe1 mi tienda zona de exclusividad?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Todos los establecimientos de quickgold disponen de una zona de exclusividad, esta zona se delimita con la firma del acuerdo previo y se consolida de forma definitiva, con la firma del local y el contrato de franquicia."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel8",
                onChange: handleChange("panel8"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel8d-content",
                        id: "panel8d-header",
                        children: [
                            " ",
                            expanded == "panel8" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfCu\xe1ntos metros tiene que tener el local?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Los metros \xf3ptimos para un establecimiento quickgold son de 30 a 40 m2, no obstante, a partir de 20 m2 podemos valorar la instalaci\xf3n del mismo."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel9",
                onChange: handleChange("panel9"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel9d-content",
                        id: "panel9d-header",
                        children: [
                            " ",
                            expanded == "panel9" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfMe ayudan con la b\xfasqueda del local?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Una vez elegida la zona donde se ubicar\xe1 el establecimiento quickgold, te ayudaremos y asesoraremos en la b\xfasqueda del local. Un integrante del departamento de Expansi\xf3n se desplazar\xe1 a la ubicaci\xf3n elegida para comprobar \xabin situ\xbb que tanto la zona, como el local elegido est\xe1n dentro de los par\xe1metros adecuados para abrir un establecimiento quickgold."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion, {
                className: (accordionFranquicia_module_default()).contenedorAccordion,
                expanded: expanded === "panel10",
                onChange: handleChange("panel10"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordionSummary, {
                        className: (accordionFranquicia_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel10d-content",
                        id: "panel10d-header",
                        children: [
                            " ",
                            expanded == "panel10" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionFranquicia_module_default()).tituloAccordion,
                                children: "\xbfPuedo abrir un establecimiento quickgold en la ciudad que quiera?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordionDetails, {
                        className: (accordionFranquicia_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionFranquicia_module_default()).contenidoAccordion,
                            children: "Las poblaciones id\xf3neas son aquellas que tienen 90.000 habitantes o m\xe1s, dentro de esas ciudades y en funci\xf3n de su demograf\xeda, hacemos una previsi\xf3n de las aperturas de establecimientos que podemos tener."
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/AccordionVenderMetales/accordionVenderMetales.module.css
var accordionVenderMetales_module = __webpack_require__(3662);
var accordionVenderMetales_module_default = /*#__PURE__*/__webpack_require__.n(accordionVenderMetales_module);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/AccordionVenderMetales/AccordiosVenderMetales.js









const AccordiosVenderMetales_Accordion = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()), {
        disableGutters: true,
        elevation: 0,
        square: true,
        ...props
    }))(({ theme  })=>({
        border: `1px solid ${theme.palette.divider}`,
        "&:not(:last-child)": {
            borderBottom: 0
        },
        "&:before": {
            display: "none"
        }
    }));
const AccordiosVenderMetales_AccordionSummary = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((AccordionSummary_default()), {
        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {
            sx: {
                display: "none"
            }
        }),
        ...props
    }))(({ theme  })=>({
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, .05)" : "rgba(0, 0, 0, .03)",
        flexDirection: "row-reverse",
        "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
            transform: "rotate(90deg)"
        },
        "& .MuiAccordionSummary-content": {
            marginLeft: theme.spacing(1)
        }
    }));
const AccordiosVenderMetales_AccordionDetails = (0,styles_.styled)((AccordionDetails_default()))(({ theme  })=>({
        padding: theme.spacing(2),
        borderTop: "1px solid rgba(0, 0, 0, .125)"
    }));
function AccordiosnVenderMetales() {
    const [expanded, setExpanded] = external_react_.useState(false);
    const handleChange = (panel)=>(event, newExpanded)=>{
            setExpanded(newExpanded ? panel : false);
        };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_Accordion, {
                className: (accordionVenderMetales_module_default()).contenedorAccordion,
                expanded: expanded === "panel1",
                onChange: handleChange("panel1"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_AccordionSummary, {
                        className: (accordionVenderMetales_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel1d-content",
                        id: "panel1d-header",
                        children: [
                            expanded == "panel1" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderMetales_module_default()).tituloAccordion,
                                children: "\xbfCompramos monedas antiguas?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderMetales_AccordionDetails, {
                        className: (accordionVenderMetales_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionVenderMetales_module_default()).contenidoAccordion,
                            children: "Las monedas que compramos son aquellas que son de oro o plata. Las tasamos por su peso en el metal no por su valor hist\xf3rico."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_Accordion, {
                className: (accordionVenderMetales_module_default()).contenedorAccordion,
                expanded: expanded === "panel2",
                onChange: handleChange("panel2"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_AccordionSummary, {
                        className: (accordionVenderMetales_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel2d-content",
                        id: "panel2d-header",
                        children: [
                            " ",
                            expanded == "panel2" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderMetales_module_default()).tituloAccordion,
                                children: "\xbfQu\xe9 metales preciosos puedo vender?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderMetales_AccordionDetails, {
                        className: (accordionVenderMetales_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionVenderMetales_module_default()).contenidoAccordion,
                            children: [
                                "En ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "quickgold compramos oro y plata"
                                }),
                                ". De momento no compramos otros metales como el platino o el acero. Si no sabes de qu\xe9 metales est\xe1n hechas tus joyas, nos las puedes traer a la tienda en cualquier momento. Estaremos encantados de atenderte."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_Accordion, {
                className: (accordionVenderMetales_module_default()).contenedorAccordion,
                expanded: expanded === "panel3",
                onChange: handleChange("panel3"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_AccordionSummary, {
                        className: (accordionVenderMetales_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel3d-content",
                        id: "panel3d-header",
                        children: [
                            " ",
                            expanded == "panel3" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderMetales_module_default()).tituloAccordion,
                                children: "\xbfEs necesario pedir cita previa para vender metales?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderMetales_AccordionDetails, {
                        className: (accordionVenderMetales_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionVenderMetales_module_default()).contenidoAccordion,
                            children: "Para vender oro o plata no es necesario que pidas cita previa. Puedes acudir directamente a la tienda m\xe1s cercana y vender al momento tus joyas. Si necesitas vender o empe\xf1ar brillantes, s\xed necesitamos que nos confirmes tu asistencia para que nuestro gem\xf3logo te pueda tasar los diamantes. Puedes crear tu cita llamando a tienda o a nuestro tel\xe9fono gratuito 900 373 629."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_Accordion, {
                className: (accordionVenderMetales_module_default()).contenedorAccordion,
                expanded: expanded === "panel4",
                onChange: handleChange("panel4"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_AccordionSummary, {
                        className: (accordionVenderMetales_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel4d-content",
                        id: "panel4d-header",
                        children: [
                            " ",
                            expanded == "panel4" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderMetales_module_default()).tituloAccordion,
                                children: "\xbfC\xf3mo se valoran las piezas de plata?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderMetales_AccordionDetails, {
                        className: (accordionVenderMetales_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionVenderMetales_module_default()).contenidoAccordion,
                            children: "La tasaci\xf3n, como con cualquier otro metal, se realizar\xe1 a la vista mediante diferentes comprobaciones para determinar la pureza de los objetos de plata que quieras vender. Se fijar\xe1 el precio atendiendo a la cotizaci\xf3n en bolsa del metal en el momento y se proceder\xe1 a pagar al cliente el valor de su venta."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_Accordion, {
                className: (accordionVenderMetales_module_default()).contenedorAccordion,
                expanded: expanded === "panel5",
                onChange: handleChange("panel5"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_AccordionSummary, {
                        className: (accordionVenderMetales_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel5d-content",
                        id: "panel5d-header",
                        children: [
                            " ",
                            expanded == "panel5" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderMetales_module_default()).tituloAccordion,
                                children: "\xbfC\xf3mo vendo oro en quickgold?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderMetales_AccordionDetails, {
                        className: (accordionVenderMetales_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionVenderMetales_module_default()).contenidoAccordion,
                            children: "Para vender oro s\xf3lo necesitas acudir a tu tienda quickgold m\xe1s cercana con tus joyas, ser mayor de edad y facilitarnos tu identificaci\xf3n personal en vigor. Nuestras compa\xf1eras tasar\xe1n a la vista, mediante diferentes comprobaciones, el metal. Seg\xfan la cotizaci\xf3n actual del oro valorar\xe1n tus piezas y si est\xe1s de acuerdo con el precio fijado se proceder\xe1 a formalizar un acuerdo de compraventa. Obtendr\xe1s al momento tu dinero en efectivo o por transferencia seg\xfan prefieras. Aprovecha y trae todas las piezas que quieras vender, cuantos m\xe1s gramos, mejor precio obtendr\xe1s."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_Accordion, {
                className: (accordionVenderMetales_module_default()).contenedorAccordion,
                expanded: expanded === "panel6",
                onChange: handleChange("panel6"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_AccordionSummary, {
                        className: (accordionVenderMetales_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel6d-content",
                        id: "panel6d-header",
                        children: [
                            " ",
                            expanded == "panel6" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderMetales_module_default()).tituloAccordion,
                                children: "\xbfQu\xe9 tipo de oro puedo vender en quickgold?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderMetales_AccordionDetails, {
                        className: (accordionVenderMetales_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionVenderMetales_module_default()).contenidoAccordion,
                            children: "En quickgold puedes vender oro amarillo o blanco desde 14K hasta 24K. Puedes consultarnos en cualquier momento el precio de tus joyas visit\xe1ndonos en tienda o llam\xe1ndonos al 900 373 629. Mediante la tasaci\xf3n de las mismas junto con el precio del oro del momento, valoraremos tus piezas."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_Accordion, {
                className: (accordionVenderMetales_module_default()).contenedorAccordion,
                expanded: expanded === "panel7",
                onChange: handleChange("panel7"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderMetales_AccordionSummary, {
                        className: (accordionVenderMetales_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel7d-content",
                        id: "panel7d-header",
                        children: [
                            " ",
                            expanded == "panel7" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderMetales_module_default()).tituloAccordion,
                                children: "\xbfPuedo vender joyas ba\xf1adas en oro?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderMetales_AccordionDetails, {
                        className: (accordionVenderMetales_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionVenderMetales_module_default()).contenidoAccordion,
                            children: "En quickgold compramos piezas de oro con una pureza m\xednima de 14K, por lo que no aceptamos joyas ba\xf1adas en oro, ya que su relleno no lo compone este metal."
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/AccordionCambioDivisa/accordionCambioDivisa.module.css
var accordionCambioDivisa_module = __webpack_require__(4135);
var accordionCambioDivisa_module_default = /*#__PURE__*/__webpack_require__.n(accordionCambioDivisa_module);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/AccordionCambioDivisa/AccordiosCambioDivisa.js









const AccordiosCambioDivisa_Accordion = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()), {
        disableGutters: true,
        elevation: 0,
        square: true,
        ...props
    }))(({ theme  })=>({
        border: `1px solid ${theme.palette.divider}`,
        "&:not(:last-child)": {
            borderBottom: 0
        },
        "&:before": {
            display: "none"
        }
    }));
const AccordiosCambioDivisa_AccordionSummary = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((AccordionSummary_default()), {
        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {
            sx: {
                display: "none"
            }
        }),
        ...props
    }))(({ theme  })=>({
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, .05)" : "rgba(0, 0, 0, .03)",
        flexDirection: "row-reverse",
        "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
            transform: "rotate(90deg)"
        },
        "& .MuiAccordionSummary-content": {
            marginLeft: theme.spacing(1)
        }
    }));
const AccordiosCambioDivisa_AccordionDetails = (0,styles_.styled)((AccordionDetails_default()))(({ theme  })=>({
        padding: theme.spacing(2),
        borderTop: "1px solid rgba(0, 0, 0, .125)"
    }));
function AccordiosnCambioDivisa() {
    const [expanded, setExpanded] = external_react_.useState(false);
    const handleChange = (panel)=>(event, newExpanded)=>{
            setExpanded(newExpanded ? panel : false);
        };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_Accordion, {
                className: (accordionCambioDivisa_module_default()).contenedorAccordion,
                expanded: expanded === "panel1",
                onChange: handleChange("panel1"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_AccordionSummary, {
                        className: (accordionCambioDivisa_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel1d-content",
                        id: "panel1d-header",
                        children: [
                            expanded == "panel1" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionCambioDivisa_module_default()).tituloAccordion,
                                children: "\xbfHay l\xedmite para cambiar divisa?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosCambioDivisa_AccordionDetails, {
                        className: (accordionCambioDivisa_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionCambioDivisa_module_default()).contenidoAccordion,
                            children: [
                                "En quickgold puedes cambiar cualquier cantidad de dinero, no tenemos una cantidad m\xednima. Si necesitas cambiar grandes cantidades, avisa a tu tienda para que prepare el efectivo y lo tenga todo listo para cuando nos visites. Necesitaremos documentaci\xf3n adicional para cantidades grandes de divisa. Puedes consultar toda la informaci\xf3n relacionada en nuestro apartado del servicio:",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://quickgold.es/cambio-divisas",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "cambio de divisa"
                                    })
                                }),
                                "."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_Accordion, {
                className: (accordionCambioDivisa_module_default()).contenedorAccordion,
                expanded: expanded === "panel2",
                onChange: handleChange("panel2"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_AccordionSummary, {
                        className: (accordionCambioDivisa_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel2d-content",
                        id: "panel2d-header",
                        children: [
                            " ",
                            expanded == "panel2" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionCambioDivisa_module_default()).tituloAccordion,
                                children: "\xbfCompramos monedas?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosCambioDivisa_AccordionDetails, {
                        className: (accordionCambioDivisa_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionCambioDivisa_module_default()).contenidoAccordion,
                            children: "No, de momento solo aceptamos billetes de divisa extranjera. S\xed entregamos monedas en euros."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_Accordion, {
                className: (accordionCambioDivisa_module_default()).contenedorAccordion,
                expanded: expanded === "panel3",
                onChange: handleChange("panel3"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_AccordionSummary, {
                        className: (accordionCambioDivisa_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel3d-content",
                        id: "panel3d-header",
                        children: [
                            " ",
                            expanded == "panel3" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionCambioDivisa_module_default()).tituloAccordion,
                                children: "\xbfEs necesario reservar la divisa?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosCambioDivisa_AccordionDetails, {
                        className: (accordionCambioDivisa_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionCambioDivisa_module_default()).contenidoAccordion,
                            children: "Si lo que necesitas es cambiar moneda extranjera a euros lo puedes hacer al momento sin necesidad de que realices una reserva. Si, por el contrario, quieres comprar moneda extranjera con euros, necesitaremos que te pongas en contacto con la tienda que puede realizar esta operaci\xf3n, y solicites tu cambio. Comprobaremos stock y te fijaremos el precio para que obtengas al mejor precio y cu\xe1nto antes tu divisa. En cualquiera de los casos, si se trata de cantidades grandes para cambiar, necesitamos que nos llames y nos informes de la operaci\xf3n que quieras realizar. Te informaremos y resolveremos todas tus dudas en el 900 373 629 o en el tel\xe9fono de tu tienda quickgold."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_Accordion, {
                className: (accordionCambioDivisa_module_default()).contenedorAccordion,
                expanded: expanded === "panel4",
                onChange: handleChange("panel4"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_AccordionSummary, {
                        className: (accordionCambioDivisa_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel4d-content",
                        id: "panel4d-header",
                        children: [
                            " ",
                            expanded == "panel4" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionCambioDivisa_module_default()).tituloAccordion,
                                children: "\xbfNecesito alg\xfan documento para cambiar divisa?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosCambioDivisa_AccordionDetails, {
                        className: (accordionCambioDivisa_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionCambioDivisa_module_default()).contenidoAccordion,
                            children: [
                                "Para cambiar divisa es necesario que seas",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "mayor de edad"
                                }),
                                " y que aportes tu documentaci\xf3n personal (",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "DNI, NIE o Pasaporte"
                                }),
                                ") en vigor. Adem\xe1s, para cantidades grandes necesitamos un documento que acredite la procedencia de fondos y tu cargo profesional. Si fuera necesario por falta de efectivo, necesitaremos tambi\xe9n un n\xfamero de cuenta para abonarte el importe de tu cambio. Si tienes cualquier duda puedes visitar",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://quickgold.es/cambio-divisas",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "nuestra p\xe1gina de servicio de cambio de divisa"
                                    })
                                }),
                                "o bien",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                    children: [
                                        "llamarnos gratuitamente al",
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "tel.900 373 629",
                                            children: "900 373 629"
                                        })
                                    ]
                                }),
                                ", estaremos encantados de ayudarte."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_Accordion, {
                className: (accordionCambioDivisa_module_default()).contenedorAccordion,
                expanded: expanded === "panel5",
                onChange: handleChange("panel5"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_AccordionSummary, {
                        className: (accordionCambioDivisa_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel5d-content",
                        id: "panel5d-header",
                        children: [
                            " ",
                            expanded == "panel5" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionCambioDivisa_module_default()).tituloAccordion,
                                children: "\xbfPuedo comprar moneda extranjera?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosCambioDivisa_AccordionDetails, {
                        className: (accordionCambioDivisa_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionCambioDivisa_module_default()).contenidoAccordion,
                            children: [
                                "De momento puedes comprar moneda extranjera en algunas de",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "nuestras oficinas"
                                }),
                                ". Tienes disponibles m\xe1s de 30 divisas diferentes. Estas son las tiendas en las que puedes realizar tu cambio de euros a divisa extranjera."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_Accordion, {
                className: (accordionCambioDivisa_module_default()).contenedorAccordion,
                expanded: expanded === "panel6",
                onChange: handleChange("panel6"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_AccordionSummary, {
                        className: (accordionCambioDivisa_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel6d-content",
                        id: "panel6d-header",
                        children: [
                            " ",
                            expanded == "panel6" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionCambioDivisa_module_default()).tituloAccordion,
                                children: "\xbfQu\xe9 comisi\xf3n se paga en quickgold por el cambio de divisa?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosCambioDivisa_AccordionDetails, {
                        className: (accordionCambioDivisa_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionCambioDivisa_module_default()).contenidoAccordion,
                            children: [
                                "En quickgold cualquier cambio de divisa tiene",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "0% comisiones"
                                }),
                                ", para siempre."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_Accordion, {
                className: (accordionCambioDivisa_module_default()).contenedorAccordion,
                expanded: expanded === "panel7",
                onChange: handleChange("panel7"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosCambioDivisa_AccordionSummary, {
                        className: (accordionCambioDivisa_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel7d-content",
                        id: "panel7d-header",
                        children: [
                            " ",
                            expanded == "panel7" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionCambioDivisa_module_default()).tituloAccordion,
                                children: "\xbfPor qu\xe9 el precio de la divisa es diferente a la calculadora de Google?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosCambioDivisa_AccordionDetails, {
                        className: (accordionCambioDivisa_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionCambioDivisa_module_default()).contenidoAccordion,
                            children: [
                                "Google nos ofrece la posibilidad de conocer el",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "precio de cotizaci\xf3n"
                                }),
                                "de la moneda que te interese, es decir, vemos el",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "precio de bolsa"
                                }),
                                " de la divisa en el momento que realizas la b\xfasqueda. Sobre ese precio las oficinas de cambio trabajamos unos m\xe1rgenes. Cu\xe1nto m\xe1s se acerque nuestro precio al que marca el de cotizaci\xf3n en bolsa, mejor cambio recibir\xe1s. En",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: " quickgold"
                                }),
                                " te aseguramos",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "la mejor tasa de cambio para tu moneda"
                                }),
                                "."
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/AccordionEmpenos/accordionEmpenos.module.css
var accordionEmpenos_module = __webpack_require__(5327);
var accordionEmpenos_module_default = /*#__PURE__*/__webpack_require__.n(accordionEmpenos_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/AccordionEmpenos/AccordiosEmpenos.js










const AccordiosEmpenos_Accordion = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()), {
        disableGutters: true,
        elevation: 0,
        square: true,
        ...props
    }))(({ theme  })=>({
        border: `1px solid ${theme.palette.divider}`,
        "&:not(:last-child)": {
            borderBottom: 0
        },
        "&:before": {
            display: "none"
        }
    }));
const AccordiosEmpenos_AccordionSummary = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((AccordionSummary_default()), {
        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {
            sx: {
                display: "none"
            }
        }),
        ...props
    }))(({ theme  })=>({
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, .05)" : "rgba(0, 0, 0, .03)",
        flexDirection: "row-reverse",
        "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
            transform: "rotate(90deg)"
        },
        "& .MuiAccordionSummary-content": {
            marginLeft: theme.spacing(1)
        }
    }));
const AccordiosEmpenos_AccordionDetails = (0,styles_.styled)((AccordionDetails_default()))(({ theme  })=>({
        padding: theme.spacing(2),
        borderTop: "1px solid rgba(0, 0, 0, .125)"
    }));
function AccordiosnEmpenos() {
    const [expanded, setExpanded] = external_react_.useState(false);
    const handleChange = (panel)=>(event, newExpanded)=>{
            setExpanded(newExpanded ? panel : false);
        };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_Accordion, {
                className: (accordionEmpenos_module_default()).contenedorAccordion,
                expanded: expanded === "panel1",
                onChange: handleChange("panel1"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_AccordionSummary, {
                        className: (accordionEmpenos_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel1d-content",
                        id: "panel1d-header",
                        children: [
                            expanded == "panel1" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionEmpenos_module_default()).tituloAccordion,
                                children: "\xbfCu\xe1ntas veces puedo renovar mi empe\xf1o?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosEmpenos_AccordionDetails, {
                        className: (accordionEmpenos_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionEmpenos_module_default()).contenidoAccordion,
                            children: "Puedes renovar el contrato las veces que necesites hasta que puedas recuperar las piezas. Es necesario que te pongas en contacto directamente con la tienda con la que tienes formalizado el contrato."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_Accordion, {
                className: (accordionEmpenos_module_default()).contenedorAccordion,
                expanded: expanded === "panel2",
                onChange: handleChange("panel2"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_AccordionSummary, {
                        className: (accordionEmpenos_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel2d-content",
                        id: "panel2d-header",
                        children: [
                            " ",
                            expanded == "panel2" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionEmpenos_module_default()).tituloAccordion,
                                children: "\xbfQu\xe9 intereses tiene mi empe\xf1o en quickgold?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosEmpenos_AccordionDetails, {
                        className: (accordionEmpenos_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (accordionEmpenos_module_default()).contenidoAccordion,
                            children: "Disfruta, con quickgold, de 0% de inter\xe9s durante el primer mes de empe\xf1os de joyas. Conoce el resto de condiciones de los mismos en tu tienda m\xe1s cercana."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_Accordion, {
                className: (accordionEmpenos_module_default()).contenedorAccordion,
                expanded: expanded === "panel3",
                onChange: handleChange("panel3"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_AccordionSummary, {
                        className: (accordionEmpenos_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel3d-content",
                        id: "panel3d-header",
                        children: [
                            " ",
                            expanded == "panel3" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionEmpenos_module_default()).tituloAccordion,
                                children: "\xbfQu\xe9 puedo empe\xf1ar?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosEmpenos_AccordionDetails, {
                        className: (accordionEmpenos_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionEmpenos_module_default()).contenidoAccordion,
                            children: [
                                "Puedes empe\xf1ar ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "joyas de oro o plata"
                                }),
                                " como: pendientes, pulseras, relojes, etc. Si tienes alguna duda, puedes llamar a tu tienda m\xe1s cercana para que te expliquen, personalmente, c\xf3mo funcionan nuestros ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "empe\xf1os de joyas"
                                }),
                                "."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_Accordion, {
                className: (accordionEmpenos_module_default()).contenedorAccordion,
                expanded: expanded === "panel4",
                onChange: handleChange("panel4"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_AccordionSummary, {
                        className: (accordionEmpenos_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel4d-content",
                        id: "panel4d-header",
                        children: [
                            " ",
                            expanded == "panel4" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionEmpenos_module_default()).tituloAccordion,
                                children: "\xbfCu\xe1l es el proceso de tasaci\xf3n?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosEmpenos_AccordionDetails, {
                        className: (accordionEmpenos_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionEmpenos_module_default()).contenidoAccordion,
                            children: [
                                "La ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "tasaci\xf3n de las joyas"
                                }),
                                " de empe\xf1os se realiza igual que con la compra de \xe9stas. Se tasar\xe1, a la",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "vista del cliente"
                                }),
                                ", los",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "metales preciosos"
                                }),
                                ", facilitando toda la informaci\xf3n requerida por \xe9ste. Una vez tasadas se fijar\xe1 el precio seg\xfan la cotizaci\xf3n del metal en el momento y se realizar\xe1 un contrato de empe\xf1os. Una vez firmado por ambas partes se entregar\xe1 el dinero acordado y obtendr\xe1s toda la informaci\xf3n necesaria para conocer c\xf3mo y cu\xe1ndo se renueva el contrato y c\xf3mo lo podr\xe1s cancelar de la manera m\xe1s sencilla y c\xf3moda para ti.",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/empeno-de-joyas/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Consulta toda la informaci\xf3n sobre los empe\xf1os de quickgold"
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_Accordion, {
                className: (accordionEmpenos_module_default()).contenedorAccordion,
                expanded: expanded === "panel5",
                onChange: handleChange("panel5"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosEmpenos_AccordionSummary, {
                        className: (accordionEmpenos_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel5d-content",
                        id: "panel5d-header",
                        children: [
                            " ",
                            expanded == "panel5" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionEmpenos_module_default()).tituloAccordion,
                                children: "\xbfEn cu\xe1ntos meses puedo empe\xf1ar mis joyas?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosEmpenos_AccordionDetails, {
                        className: (accordionEmpenos_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionEmpenos_module_default()).contenidoAccordion,
                            children: [
                                "En ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "quickgold"
                                }),
                                " te ofrecemos todas las facilidades necesarias para que puedas",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "empe\xf1ar tus joyas en 1, 2 o 3 meses"
                                }),
                                ". Aprovecha nuestra promoci\xf3n en empe\xf1os, con la que puedes dejarnos tus joyas de oro o plata",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "sin pagar intereses durante el primer mes"
                                }),
                                "."
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/AccordionInvertirOro/accordionInvertirOro.module.css
var accordionInvertirOro_module = __webpack_require__(7075);
var accordionInvertirOro_module_default = /*#__PURE__*/__webpack_require__.n(accordionInvertirOro_module);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/AccordionInvertirOro/AccordiosInvertirOro.js










const AccordiosInvertirOro_Accordion = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()), {
        disableGutters: true,
        elevation: 0,
        square: true,
        ...props
    }))(({ theme  })=>({
        border: `1px solid ${theme.palette.divider}`,
        "&:not(:last-child)": {
            borderBottom: 0
        },
        "&:before": {
            display: "none"
        }
    }));
const AccordiosInvertirOro_AccordionSummary = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((AccordionSummary_default()), {
        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {
            sx: {
                display: "none"
            }
        }),
        ...props
    }))(({ theme  })=>({
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, .05)" : "rgba(0, 0, 0, .03)",
        flexDirection: "row-reverse",
        "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
            transform: "rotate(90deg)"
        },
        "& .MuiAccordionSummary-content": {
            marginLeft: theme.spacing(1)
        }
    }));
const AccordiosInvertirOro_AccordionDetails = (0,styles_.styled)((AccordionDetails_default()))(({ theme  })=>({
        padding: theme.spacing(2),
        borderTop: "1px solid rgba(0, 0, 0, .125)"
    }));
function AccordiosnInvertirOro() {
    const [expanded, setExpanded] = external_react_.useState(false);
    const handleChange = (panel)=>(event, newExpanded)=>{
            setExpanded(newExpanded ? panel : false);
        };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosInvertirOro_Accordion, {
                className: (accordionInvertirOro_module_default()).contenedorAccordion,
                expanded: expanded === "panel1",
                onChange: handleChange("panel1"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosInvertirOro_AccordionSummary, {
                        className: (accordionInvertirOro_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel1d-content",
                        id: "panel1d-header",
                        children: [
                            expanded == "panel1" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionInvertirOro_module_default()).tituloAccordion,
                                children: "\xbfTengo que reservar mi lingote?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosInvertirOro_AccordionDetails, {
                        className: (accordionInvertirOro_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionInvertirOro_module_default()).contenidoAccordion,
                            children: [
                                "S\xed, necesitamos confirmar tu reserva ya que trabajamos con una fundidora que nos prepara los",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "lingotes seg\xfan demanda"
                                }),
                                ". Cada uno de ellos cuenta con certificado de garant\xeda que acredita la pureza del mismo. Como nos encanta contar con tu satisfacci\xf3n nos esforzamos por entregarte el lingote en menos de 72h. Ac\xe9rcate a nuestras oficinas o",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "tel:900 373 629",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "ll\xe1manos al 900 373 629 para m\xe1s informaci\xf3n."
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosInvertirOro_Accordion, {
                className: (accordionInvertirOro_module_default()).contenedorAccordion,
                expanded: expanded === "panel2",
                onChange: handleChange("panel2"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosInvertirOro_AccordionSummary, {
                        className: (accordionInvertirOro_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel2d-content",
                        id: "panel2d-header",
                        children: [
                            " ",
                            expanded == "panel2" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionInvertirOro_module_default()).tituloAccordion,
                                children: "\xbfTengo que pagar IVA por comprar lingotes de oro?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosInvertirOro_AccordionDetails, {
                        className: (accordionInvertirOro_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionInvertirOro_module_default()).contenidoAccordion,
                            children: [
                                "No, el oro est\xe1 exento del cargo del IVA. Consulta",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/inverti-en-oro/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "nuestro cat\xe1logo de lingotes de oro aqu\xed"
                                    })
                                }),
                                "."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosInvertirOro_Accordion, {
                className: (accordionInvertirOro_module_default()).contenedorAccordion,
                expanded: expanded === "panel3",
                onChange: handleChange("panel3"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosInvertirOro_AccordionSummary, {
                        className: (accordionInvertirOro_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel3d-content",
                        id: "panel3d-header",
                        children: [
                            " ",
                            expanded == "panel3" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionInvertirOro_module_default()).tituloAccordion,
                                children: "\xbfPor qu\xe9 invertir en oro?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosInvertirOro_AccordionDetails, {
                        className: (accordionInvertirOro_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionInvertirOro_module_default()).contenidoAccordion,
                            children: [
                                "El ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "precio del oro"
                                }),
                                " est\xe1 siempre en constante crecimiento por lo que si realizas una inversi\xf3n en este metal precioso a posteriori la recuperar\xe1s y obtendr\xe1s, adem\xe1s, beneficio por ella. Si tienes cualquier duda, cont\xe1ctanos."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosInvertirOro_Accordion, {
                className: (accordionInvertirOro_module_default()).contenedorAccordion,
                expanded: expanded === "panel4",
                onChange: handleChange("panel4"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosInvertirOro_AccordionSummary, {
                        className: (accordionInvertirOro_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel4d-content",
                        id: "panel4d-header",
                        children: [
                            " ",
                            expanded == "panel4" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionInvertirOro_module_default()).tituloAccordion,
                                children: "\xbfC\xf3mo comprar lingotes de oro en quickgold?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosInvertirOro_AccordionDetails, {
                        className: (accordionInvertirOro_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionInvertirOro_module_default()).contenidoAccordion,
                            children: [
                                "Para comprar tu ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "lingote de oro"
                                }),
                                " en",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "quickgold"
                                }),
                                ", necesitamos que realices tu reserva y conocer algunos datos. Para ello nos puedes llamar al 900 373 629 o al tel\xe9fono de tu tienda favorita que encontrar\xe1s en este",
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/contacto/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: " directorio"
                                    })
                                }),
                                "."
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/AccordionVenderDiamantes/accordionVenderDiamantes.module.css
var accordionVenderDiamantes_module = __webpack_require__(8329);
var accordionVenderDiamantes_module_default = /*#__PURE__*/__webpack_require__.n(accordionVenderDiamantes_module);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/AccordionVenderDiamantes/AccordiosVenderDiamantes.js










const AccordiosVenderDiamantes_Accordion = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()), {
        disableGutters: true,
        elevation: 0,
        square: true,
        ...props
    }))(({ theme  })=>({
        border: `1px solid ${theme.palette.divider}`,
        "&:not(:last-child)": {
            borderBottom: 0
        },
        "&:before": {
            display: "none"
        }
    }));
const AccordiosVenderDiamantes_AccordionSummary = (0,styles_.styled)((props)=>/*#__PURE__*/ jsx_runtime_.jsx((AccordionSummary_default()), {
        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {
            sx: {
                display: "none"
            }
        }),
        ...props
    }))(({ theme  })=>({
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, .05)" : "rgba(0, 0, 0, .03)",
        flexDirection: "row-reverse",
        "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
            transform: "rotate(90deg)"
        },
        "& .MuiAccordionSummary-content": {
            marginLeft: theme.spacing(1)
        }
    }));
const AccordiosVenderDiamantes_AccordionDetails = (0,styles_.styled)((AccordionDetails_default()))(({ theme  })=>({
        padding: theme.spacing(2),
        borderTop: "1px solid rgba(0, 0, 0, .125)"
    }));
function AccordiosnVenderDiamantes() {
    const [expanded, setExpanded] = external_react_.useState(false);
    const handleChange = (panel)=>(event, newExpanded)=>{
            setExpanded(newExpanded ? panel : false);
        };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderDiamantes_Accordion, {
                className: (accordionVenderDiamantes_module_default()).contenedorAccordion,
                expanded: expanded === "panel1",
                onChange: handleChange("panel1"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderDiamantes_AccordionSummary, {
                        className: (accordionVenderDiamantes_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel1d-content",
                        id: "panel1d-header",
                        children: [
                            expanded == "panel1" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderDiamantes_module_default()).tituloAccordion,
                                children: "\xbfQu\xe9 diamantes aceptamos?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderDiamantes_AccordionDetails, {
                        className: (accordionVenderDiamantes_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionVenderDiamantes_module_default()).contenidoAccordion,
                            children: [
                                "Compramos brillantes de talla moderna, catalogados con color en escala H \xf3 I, con una pureza superior a SI3 y quilataje superior a 0,10ct. Para saber m\xe1s detalles sobre el proceso de tasaci\xf3n y caracter\xedsticas de los diferentes diamantes, visita nuestra secci\xf3n del servicio de",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/vender-diamantes/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "compra de diamantes"
                                    })
                                }),
                                "."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderDiamantes_Accordion, {
                className: (accordionVenderDiamantes_module_default()).contenedorAccordion,
                expanded: expanded === "panel2",
                onChange: handleChange("panel2"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AccordiosVenderDiamantes_AccordionSummary, {
                        className: (accordionVenderDiamantes_module_default()).contenedorTituloAccordion,
                        "aria-controls": "panel2d-content",
                        id: "panel2d-header",
                        children: [
                            " ",
                            expanded == "panel2" ? /*#__PURE__*/ jsx_runtime_.jsx((HorizontalRuleRounded_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((AddRounded_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (accordionVenderDiamantes_module_default()).tituloAccordion,
                                children: "\xbfC\xf3mo vender diamantes en quickgold?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosVenderDiamantes_AccordionDetails, {
                        className: (accordionVenderDiamantes_module_default()).contenerdorContenidoAccordion,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (accordionVenderDiamantes_module_default()).contenidoAccordion,
                            children: [
                                "Para que podamos tasar tu brillante necesitamos que concretes una",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "cita previa con tu tienda m\xe1s cercana"
                                }),
                                ". Nuestro experto gem\xf3logo realizar\xe1 unas comprobaciones detalladas y a la vista que ayudar\xe1n a conocer las caracter\xedsticas del diamante y saber el ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "precio de compra"
                                }),
                                " del mismo."
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/Section_2/Section_dos.js














function TabPanel(props) {
    const { children , value , index , ...other } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        role: "tabpanel",
        hidden: value !== index,
        id: `vertical-tabpanel-${index}`,
        "aria-labelledby": `vertical-tab-${index}`,
        ...other,
        children: value === index ? /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
            sx: {
                p: 3
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx("article", {
                children: children
            })
        }) : null
    });
}
TabPanel.propTypes = {
    children: (external_prop_types_default()).node,
    index: (external_prop_types_default()).number.isRequired,
    value: (external_prop_types_default()).number.isRequired
};
function a11yProps(index) {
    return {
        id: `vertical-tab-${index}`,
        "aria-controls": `vertical-tabpanel-${index}`
    };
}
function Section_dos({ ciudad  }) {
    const [value, setValue] = external_react_default().useState(1);
    const handleChange = (event, newValue)=>{
        setValue(newValue);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (sectionDos_module_default()).box,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
            sx: {
                //flexGrow: 1,
                //bgcolor: "background.paper",
                display: "flex",
                height: "auto"
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Tabs_default()), {
                    className: (sectionDos_module_default()).bloqueIzq,
                    orientation: "vertical",
                    //variant="scrollable"
                    value: value,
                    onChange: handleChange,
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (sectionDos_module_default()).bloqueIzqTexto,
                            children: "Tabla de contenidos"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                            className: (sectionDos_module_default()).botonTabs,
                            label: "Franquicia",
                            ...a11yProps(1)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                            className: (sectionDos_module_default()).botonTabs,
                            label: "Vender metales preciosos",
                            ...a11yProps(2)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                            className: (sectionDos_module_default()).botonTabs,
                            label: "Cambio de divisa",
                            ...a11yProps(3)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                            className: (sectionDos_module_default()).botonTabs,
                            label: "Empe\xf1os",
                            ...a11yProps(4)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                            className: (sectionDos_module_default()).botonTabs,
                            label: "Invertir en oro",
                            ...a11yProps(5)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                            className: (sectionDos_module_default()).botonTabs,
                            label: "Vender Diamantes",
                            ...a11yProps(6)
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(TabPanel, {
                    className: (sectionDos_module_default()).contenidoTabs,
                    value: value,
                    index: 1,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnFranquicia, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(TabPanel, {
                    className: (sectionDos_module_default()).contenidoTabs,
                    value: value,
                    index: 2,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnVenderMetales, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(TabPanel, {
                    className: (sectionDos_module_default()).contenidoTabs,
                    value: value,
                    index: 3,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnCambioDivisa, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(TabPanel, {
                    className: (sectionDos_module_default()).contenidoTabs,
                    value: value,
                    index: 4,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnEmpenos, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(TabPanel, {
                    className: (sectionDos_module_default()).contenidoTabs,
                    value: value,
                    index: 5,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnInvertirOro, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(TabPanel, {
                    className: (sectionDos_module_default()).contenidoTabs,
                    value: value,
                    index: 6,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnVenderDiamantes, {})
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/Section_2_mobil/section_dos_mobil.module.css
var section_dos_mobil_module = __webpack_require__(271);
var section_dos_mobil_module_default = /*#__PURE__*/__webpack_require__.n(section_dos_mobil_module);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/Section_2_mobil/Section_dos_mobile.js









const Section_dos_mobile = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_dos_mobil_module_default()).contenedorSectionDosMobil,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_dos_mobil_module_default()).contenedorSectionDosMobiContenido,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (section_dos_mobil_module_default()).tituloPreguntas,
                        children: "Franquicia"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnFranquicia, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_dos_mobil_module_default()).contenedorSectionDosMobiContenido,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (section_dos_mobil_module_default()).tituloPreguntas,
                        children: "Vender metales preciosos"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnVenderMetales, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_dos_mobil_module_default()).contenedorSectionDosMobiContenido,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (section_dos_mobil_module_default()).tituloPreguntas,
                        children: "Cambio de divisas"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnCambioDivisa, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_dos_mobil_module_default()).contenedorSectionDosMobiContenido,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (section_dos_mobil_module_default()).tituloPreguntas,
                        children: "Empe\xf1os"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnEmpenos, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_dos_mobil_module_default()).contenedorSectionDosMobiContenido,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (section_dos_mobil_module_default()).tituloPreguntas,
                        children: "Invertir en oro"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnInvertirOro, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_dos_mobil_module_default()).contenedorSectionDosMobiContenidoUltimo,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (section_dos_mobil_module_default()).tituloPreguntas,
                        children: "Vender Diamantes"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AccordiosnVenderDiamantes, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_2_mobil_Section_dos_mobile = (Section_dos_mobile);

// EXTERNAL MODULE: ./src/componentes/Preguntas-frecuentes/Section_3/sectionTres.module.css
var sectionTres_module = __webpack_require__(3582);
var sectionTres_module_default = /*#__PURE__*/__webpack_require__.n(sectionTres_module);
;// CONCATENATED MODULE: ./src/componentes/Preguntas-frecuentes/Section_3/Section_3.js



const Section_3 = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (sectionTres_module_default()).contenedorImagenFondo,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (sectionTres_module_default()).contenedorTexto,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "\xbfSigues necesitando ayuda? \xa1D\xe9janos un mensaje!"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    children: [
                        "Para cualquier otra pregunta, por favor escr\xedbenos a",
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "mailto:central@quickgold.es",
                            children: "central@quickgold.es"
                        }),
                        " o ll\xe1manos al ",
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "tel:900373629",
                            children: "900 373 629"
                        }),
                        "."
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "Estaremos encantados de ayudarte."
                })
            ]
        })
    });
};
/* harmony default export */ const Section_3_Section_3 = (Section_3);

;// CONCATENATED MODULE: ./src/pages/preguntas-frecuentes/index.js











function PreguntasFrecuentes({ menu_list , ciudad  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((next_seo_default()), {
                title: ciudad?.acf?.titulo_del_meta,
                description: ciudad?.acf?.descripcion_del_meta,
                icon: "/favicon.png",
                facebook: {
                    image: "/facebook.png",
                    url: "https://www.facebook.com/quickgold.es/",
                    type: "article"
                },
                twitter: {
                    image: "/twitter.png",
                    site: "@quickgoldQG",
                    card: "summary_large_image"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet preload prefetch",
                        href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css",
                        as: "style"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("noscript", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("link", {
                            rel: "stylesheet",
                            href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
                menu_list: menu_list,
                ciudad: ciudad,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Home_module_default()).main,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs/* default */.Z, {
                                raiz: "Quickgold",
                                iconoRaiz: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {}),
                                urlUbicacionActual: "/preguntas-frecuentes/",
                                iconoUbiccionActual: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {}),
                                ubicacionActual: "Preguntas frecuentes"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_1_Section_uno, {
                                ciudad: ciudad
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_dos, {
                                ciudad: ciudad
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_2_mobil_Section_dos_mobile, {
                                ciudad: ciudad
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_3_Section_3, {})
                ]
            })
        ]
    });
}
const idTienda = "preguntasfrecuentes";
const idPaginaWp = "2702";
const apiGeneral = "13848";
//const idWp = "13848";
async function getStaticProps() {
    //datos de los campos personalizados de la ciudad
    const ciudad1 = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${idPaginaWp}`);
    const ciudad = await ciudad1.json();
    //fin datos de los campos personalizados de la ciudad
    const res = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${apiGeneral}`);
    const general = await res.json();
    /*const response = await fetch(
    `https://quickgold.es/wp-json/wp/v2/pages/${idWp}`
  );
  const dataIdWp = await response.json();*/ const menu = await fetch(`https://panel.quickgold.es/wp-json/menus/v1/menus/2219`);
    const menu_list = await menu.json();
    return {
        props: {
            menu_list,
            ciudad
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 4579:
/***/ ((module) => {

"use strict";
module.exports = require("@bradgarropy/next-seo");

/***/ }),

/***/ 6741:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CheckCircle");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 7666:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 547:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowRight");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 2906:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 5631:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 9409:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Accordion");

/***/ }),

/***/ 8279:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/AccordionDetails");

/***/ }),

/***/ 4604:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/AccordionSummary");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4180:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/SwipeableDrawer");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 5337:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll-to-top");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,5675,3573,676,1664,7699,5799], () => (__webpack_exec__(8659)));
module.exports = __webpack_exports__;

})();