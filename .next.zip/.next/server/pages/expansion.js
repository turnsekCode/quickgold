(() => {
var exports = {};
exports.id = 716;
exports.ids = [716];
exports.modules = {

/***/ 4703:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorMain": "formularioExpansion_contenedorMain__oDx8J",
	"cabecera": "formularioExpansion_cabecera__Dew8G",
	"footer": "formularioExpansion_footer__IbaAU",
	"fondoCeleste": "formularioExpansion_fondoCeleste__neFlU",
	"imagenCombinado": "formularioExpansion_imagenCombinado__yjlfc",
	"contenedor": "formularioExpansion_contenedor__I2uTw",
	"contenedorFormulario": "formularioExpansion_contenedorFormulario__P31ma",
	"contenedorTexto": "formularioExpansion_contenedorTexto__NRT9A",
	"imagenGlobo": "formularioExpansion_imagenGlobo__2ea8D",
	"contenedorPistas": "formularioExpansion_contenedorPistas__0etpC",
	"contenedorFormPistas": "formularioExpansion_contenedorFormPistas__JaqJ7",
	"imagenPersona": "formularioExpansion_imagenPersona__fPZdH",
	"contenedorInputPistas": "formularioExpansion_contenedorInputPistas__EeLsY",
	"linea": "formularioExpansion_linea__2_qVW",
	"linkPoliticas": "formularioExpansion_linkPoliticas__0O8mz",
	"contenedorBoton": "formularioExpansion_contenedorBoton__H9EvI",
	"basesLegales": "formularioExpansion_basesLegales__D13JB",
	"textoLabel": "formularioExpansion_textoLabel__ufsyk",
	"botonEnviar": "formularioExpansion_botonEnviar__bDwNd",
	"botonEnviarHabilitado": "formularioExpansion_botonEnviarHabilitado__8AhSW",
	"contenedorTitulo": "formularioExpansion_contenedorTitulo__2xFrz",
	"contenedorTituloTextoUno": "formularioExpansion_contenedorTituloTextoUno__UX_Bp",
	"contenedorTituloTextoDos": "formularioExpansion_contenedorTituloTextoDos__ZoaNR"
};


/***/ }),

/***/ 274:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUnoMargen": "section_uno_contenedorSectionUnoMargen___QKxr",
	"contenedorSectionUno": "section_uno_contenedorSectionUno__jN9K2",
	"linea": "section_uno_linea__3ruj2",
	"polygonoExpansion": "section_uno_polygonoExpansion___ydtu"
};


/***/ }),

/***/ 8029:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionDos": "section_dos_contenedorSectionDos__4o32s",
	"contenedorSectionDosMargen": "section_dos_contenedorSectionDosMargen__Fcof6",
	"linea": "section_dos_linea__H6Ku_",
	"evolucionExpansion": "section_dos_evolucionExpansion__TRlJu",
	"evolucionExpansionMobil": "section_dos_evolucionExpansionMobil__Z8Scm"
};


/***/ }),

/***/ 6917:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionTres": "section_tres_contenedorSectionTres__E151s",
	"contenedorSectionTresMargen": "section_tres_contenedorSectionTresMargen__PBTCA",
	"mapaExpansion": "section_tres_mapaExpansion__ns5_a"
};


/***/ }),

/***/ 3967:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCuatro": "section_cuatro_contenedorSectionCuatro__py5zS",
	"contenedorSectionCuatroMargen": "section_cuatro_contenedorSectionCuatroMargen__HSjLT",
	"bloqueIzq": "section_cuatro_bloqueIzq__e8VN5",
	"bloqueDer": "section_cuatro_bloqueDer__lC01S",
	"logosOtsu": "section_cuatro_logosOtsu__AeRY0",
	"logosOtsuMobil": "section_cuatro_logosOtsuMobil__rv_xq"
};


/***/ }),

/***/ 5830:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCinco": "section_cinco_contenedorSectionCinco__edjFw",
	"contenedorSectionCincoMargen": "section_cinco_contenedorSectionCincoMargen__wr1Nb",
	"textoSubtitulo": "section_cinco_textoSubtitulo__a1EuW",
	"textoIconos": "section_cinco_textoIconos__NGZrc",
	"contenedorBloqueInferior": "section_cinco_contenedorBloqueInferior__CGJj_",
	"contenedorBloque": "section_cinco_contenedorBloque__ngvdD",
	"flechas": "section_cinco_flechas__6w6yh",
	"bloqueImage": "section_cinco_bloqueImage__tjVF3",
	"iconos": "section_cinco_iconos__xsI1e"
};


/***/ }),

/***/ 2515:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionSeis": "section_seis_contenedorSectionSeis__q6mq8",
	"contenedorBloques": "section_seis_contenedorBloques__NdGac",
	"bloqueIzq": "section_seis_bloqueIzq___fS8H",
	"bloqueDer": "section_seis_bloqueDer__1ZpjE",
	"bloqueIzqTitulo": "section_seis_bloqueIzqTitulo__vf3hO",
	"bloqueIzqTexto": "section_seis_bloqueIzqTexto__Ld8IF",
	"contenedorBotonDossier": "section_seis_contenedorBotonDossier__HFUst"
};


/***/ }),

/***/ 9557:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionSiete": "section_siete_contenedorSectionSiete__mklqk",
	"contenedorBloques": "section_siete_contenedorBloques__2SZYn",
	"bloqueIzq": "section_siete_bloqueIzq__c8g_P",
	"bloqueDer": "section_siete_bloqueDer__rjL7H",
	"bloqueIzqInferior": "section_siete_bloqueIzqInferior__Lx0Y_",
	"bloqueIzqTexto": "section_siete_bloqueIzqTexto__1i_6G",
	"bloqueHorario": "section_siete_bloqueHorario__9ahHX",
	"bloqueHorariosDos": "section_siete_bloqueHorariosDos__AZULn",
	"nuestroHorario": "section_siete_nuestroHorario__HOWfA",
	"horarioDias": "section_siete_horarioDias__ELYcP",
	"horarioHoras": "section_siete_horarioHoras__4kMng",
	"horariosDiasDos": "section_siete_horariosDiasDos__4JFcX",
	"horariosHorasDos": "section_siete_horariosHorasDos__G7sDM",
	"horariosDiasTres": "section_siete_horariosDiasTres__0usYJ",
	"horariosHorasTres": "section_siete_horariosHorasTres__jK7wI"
};


/***/ }),

/***/ 7207:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionOcho": "section_ocho_contenedorSectionOcho__WlLE8",
	"contenedorBloques": "section_ocho_contenedorBloques__FmvH8",
	"bloqueIzq": "section_ocho_bloqueIzq__albms",
	"bloqueDer": "section_ocho_bloqueDer__RK8N5",
	"bloqueDerImagenes": "section_ocho_bloqueDerImagenes__ePJeT",
	"imagenRedes": "section_ocho_imagenRedes__UF0kr"
};


/***/ }),

/***/ 8874:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Home_main__EtNt2",
	"contenedorMapaVisible": "Home_contenedorMapaVisible__piXgh",
	"contenedorSeccionUnoDos": "Home_contenedorSeccionUnoDos__pegsP",
	"contenedorMapaVisibleCasaCambio": "Home_contenedorMapaVisibleCasaCambio__A5Ti8"
};


/***/ }),

/***/ 6377:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4703);
/* harmony import */ var _formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lib_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3059);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1883);
/* harmony import */ var _mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_EmailRounded__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7140);
/* harmony import */ var _mui_icons_material_EmailRounded__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_EmailRounded__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_LocalPhoneRounded__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3983);
/* harmony import */ var _mui_icons_material_LocalPhoneRounded__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocalPhoneRounded__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__]);
_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










//import { sendContactBd } from "../lib/bdConect";

const initValues = {
    name: "",
    email: "",
    subject: "",
    message: ""
};
const initState = {
    values: initValues
};
const FormularioExpansion = ()=>{
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.useToast)();
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(initState);
    const [touched, setTouched] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({});
    const { values , isLoading , error  } = state;
    //const router = useRouter();
    const [checkedItems, setCheckedItems] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const onBlur = ({ target  })=>setTouched((prev)=>({
                ...prev,
                [target.name]: true
            }));
    const handleChange = ({ target  })=>setState((prev)=>({
                ...prev,
                values: {
                    ...prev.values,
                    [target.name]: target.value
                }
            }));
    const onSubmit = async ()=>{
        setState((prev)=>({
                ...prev,
                isLoading: true
            }));
        try {
            await (0,_lib_api__WEBPACK_IMPORTED_MODULE_8__/* .sendContactForm */ .m)(values);
            //await sendContactBd(values);
            setTouched({});
            setState(initState);
            //router.push("/gracias");
            toast({
                title: "Mensaje enviado",
                status: "success",
                duration: 2000,
                position: "top"
            });
        } catch (error) {
            setState((prev)=>({
                    ...prev,
                    isLoading: false,
                    error: error.message
                }));
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.ChakraProvider, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default().contenedorTitulo),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default().contenedorTituloTextoUno),
                        children: "TE LLAMAMOS"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default().contenedorTituloTextoDos),
                        children: "Rellena el siguiente formulario y te llamaremos para ofrecerte toda la informaci\xf3n que necesitas."
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default().contenedorFormulario),
                children: [
                    error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "red.300",
                        my: 4,
                        fontSize: "xl",
                        children: error
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
                        isRequired: true,
                        position: "relative",
                        isInvalid: touched.name && !values.name,
                        mb: "4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                type: "text",
                                placeholder: "Nombre y Apellidos *",
                                name: "name",
                                errorBorderColor: "red.300",
                                value: values.name,
                                onChange: handleChange,
                                onBlur: onBlur
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormErrorMessage, {
                                children: "Se Requiere"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
                        isRequired: true,
                        isInvalid: touched.subject && !values.subject,
                        "box-shadow": "0px 4px 4px rgba(0, 0, 0, 0.25)",
                        mb: "4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                placeholder: "Ciudad d\xf3nde abrir la tienda",
                                //className={styles.inputPista}
                                type: "text",
                                name: "subject",
                                value: values.subject,
                                onChange: handleChange,
                                onBlur: onBlur
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormErrorMessage, {
                                children: "Se Requiere"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
                        isRequired: true,
                        isInvalid: touched.message && !values.message,
                        mb: "4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                placeholder: "Tel\xe9fono *",
                                type: "number",
                                inputMode: "numeric",
                                name: "message",
                                rows: 4,
                                value: values.message,
                                onChange: handleChange,
                                onBlur: onBlur
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormErrorMessage, {
                                children: "Se Requiere"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
                        isRequired: true,
                        isInvalid: touched.email && !values.email,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                placeholder: "Correo electr\xf3nico *",
                                type: "email",
                                name: "email",
                                value: values.email,
                                onChange: handleChange,
                                onBlur: onBlur
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormErrorMessage, {
                                children: "Se Requiere"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Checkbox, {
                        type: "checkbox",
                        required: true,
                        color: "#fff",
                        isChecked: checkedItems,
                        name: "checkbox",
                        onChange: (e)=>setCheckedItems(e.target.checked),
                        children: [
                            "He le\xeddo y acepto la",
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: (_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default().linkPoliticas),
                                href: "/politica-de-privacidad/",
                                children: "pol\xedtica de privacidad"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.FormErrorMessage, {
                        children: "Required"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: !values.name || !values.email || !values.subject || !values.message || checkedItems === false ? `${(_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default().botonEnviar)}` : `${(_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default().botonEnviar)} ${(_formularioExpansion_module_css__WEBPACK_IMPORTED_MODULE_9___default().botonEnviarHabilitado)}`,
                        //background=" #E83C82"
                        //variant="outline"
                        //borderRadius="13px"
                        //width="262px"
                        //color="#fff"
                        //isLoading={isLoading}
                        disabled: !values.name || !values.email || !values.subject || !values.message || checkedItems === false,
                        onClick: onSubmit,
                        children: "ENVIAR"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormularioExpansion);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_uno_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(274);
/* harmony import */ var _section_uno_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_section_uno_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Section_uno = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionUno),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionUnoMargen),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        children: [
                            "Franquicias ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_3___default().linea),
                                children: "quickgold"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        children: [
                            "En ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                children: "quickgold"
                            }),
                            " queremos seguir creciendo contigo, y para ello contamos con las mejores condiciones para que puedas emprender. Si siempre has querido tener tu propio negocio y compartes nuestros mismos valores recibe, a continuaci\xf3n, toda la informaci\xf3n."
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                src: "/assets/img/PolygonExpansion.png",
                alt: "Expansion",
                className: (_section_uno_module_css__WEBPACK_IMPORTED_MODULE_3___default().polygonoExpansion),
                width: 300,
                height: 300,
                priority: true
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_uno);


/***/ }),

/***/ 6609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_dos_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8029);
/* harmony import */ var _section_dos_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_section_dos_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Section_dos = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_section_dos_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionDos),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_section_dos_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionDosMargen),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                    children: [
                        "Evoluci\xf3n ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_section_dos_module_css__WEBPACK_IMPORTED_MODULE_3___default().linea),
                            children: "quickgold"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: "/assets/img/evolucionExpansion.png",
                    alt: "Compro oro",
                    className: (_section_dos_module_css__WEBPACK_IMPORTED_MODULE_3___default().evolucionExpansion),
                    width: 1072,
                    height: 379
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: "/assets/img/evolucionExpansionMobil.png",
                    alt: "Compro oro",
                    className: (_section_dos_module_css__WEBPACK_IMPORTED_MODULE_3___default().evolucionExpansionMobil),
                    width: 357,
                    height: 524
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_dos);


/***/ }),

/***/ 5273:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_tres_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6917);
/* harmony import */ var _section_tres_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_section_tres_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Section_tres = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_section_tres_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionTres),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_section_tres_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionTresMargen),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                src: "/assets/img/Mapa-Espana.jpg",
                alt: "Mapa tiendas",
                className: (_section_tres_module_css__WEBPACK_IMPORTED_MODULE_3___default().mapaExpansion),
                width: 1060,
                height: 783
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_tres);


/***/ }),

/***/ 7979:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3967);
/* harmony import */ var _section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Section_cuatro = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionCuatro),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionCuatroMargen),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueIzq),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            children: "FORMAMOS PARTE DE GRUPO OTSU"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Grupo Otsu es una “compa\xf1\xeda de compa\xf1\xedas”. Un grupo especializado en la creaci\xf3n y desarrollo de proyectos empresariales a trav\xe9s de la identificaci\xf3n de un sector de oportunidad con lo que se identifican en su g\xe9nesis, visi\xf3n y valores y captaci\xf3n de un l\xedder de proyecto, con el m\xe1ximo talento, capacitado y apasionado del mismo sector."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: "/assets/img/logosOtsu.png",
                            alt: "Compro oro",
                            className: (_section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().logosOtsu),
                            width: 257,
                            height: 132
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: "/assets/img/logosOtsuMobil.png",
                            alt: "Compro oro",
                            className: (_section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().logosOtsuMobil),
                            width: 258,
                            height: 132
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_section_cuatro_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueDer)
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_cuatro);


/***/ }),

/***/ 9095:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5830);
/* harmony import */ var _section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Section_cinco = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionCinco),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionCincoMargen),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: "/assets/img/flechaIzq.png",
                            alt: "divisas",
                            className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().flechas),
                            width: 24,
                            height: 19
                        }),
                        " ",
                        "M\xcdNIMO RIESGO, M\xc1XIMA RENTABILIDAD",
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: "/assets/img/flechaDer.png",
                            alt: "divisas",
                            className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().flechas),
                            width: 24,
                            height: 19
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().textoSubtitulo),
                    children: "UN MISMO ESPACIO DIFERENTES NEGOCIOS"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorBloqueInferior),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorBloque),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/DIVISAS.png",
                                    alt: "divisas",
                                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().iconos),
                                    width: 60,
                                    height: 59
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().textoIconos),
                                    children: "CAMBIO DE DIVISA"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorBloque),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/JOYAS.png",
                                    alt: "joyas",
                                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().iconos),
                                    width: 60,
                                    height: 59
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().textoIconos),
                                    children: "EMPE\xd1O DE JOYAS"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorBloque),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/assets/img/ORO.png",
                                    alt: "oro",
                                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().iconos),
                                    width: 60,
                                    height: 44
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().textoIconos),
                                    children: "COMPRA Y VENTA DE ORO"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: "/assets/img/qg-valencia-ayuntamiento.png",
                    alt: "oro",
                    className: (_section_cinco_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueImage),
                    width: 1060,
                    height: 300
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_cinco);


/***/ }),

/***/ 8501:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ section_6_Section_seis)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/ComponentesExpansion/section_6/section_seis.module.css
var section_seis_module = __webpack_require__(2515);
var section_seis_module_default = /*#__PURE__*/__webpack_require__.n(section_seis_module);
;// CONCATENATED MODULE: external "@mui/icons-material/DownloadForOffline"
const DownloadForOffline_namespaceObject = require("@mui/icons-material/DownloadForOffline");
var DownloadForOffline_default = /*#__PURE__*/__webpack_require__.n(DownloadForOffline_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/ComponentesExpansion/section_6/Section_seis.js




const Section_seis = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_seis_module_default()).contenedorSectionSeis,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                children: "QUIERO ABRIR UNA TIENDA QUICKGOLD"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_seis_module_default()).contenedorBloques,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_seis_module_default()).bloqueIzq,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (section_seis_module_default()).bloqueIzqTitulo,
                                children: "MAXIMIZAR FACTURACI\xd3N"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (section_seis_module_default()).bloqueIzqTexto,
                                children: "Amplio abanico de l\xedneas de negocio. \xd3ptima gesti\xf3n del negocio. Correcta gesti\xf3n de datos comerciales. Excelente atenci\xf3n al cliente."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_seis_module_default()).bloqueDer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (section_seis_module_default()).bloqueIzqTitulo,
                                children: "MINIMIZAR GASTOS"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (section_seis_module_default()).bloqueIzqTexto,
                                children: "Control del gasto de publicidad y m\xe1ximo rendimiento del mismo. Las nuevas l\xedneas de negocio no originan gastos extra. Optimizaci\xf3n de medios y recursos."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_seis_module_default()).contenedorBotonDossier,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    target: "_blank",
                    href: "doc/Dossier2020-Quickgold.pdf",
                    children: [
                        "DESCARGAR DOSSIER ",
                        /*#__PURE__*/ jsx_runtime_.jsx((DownloadForOffline_default()), {})
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const section_6_Section_seis = (Section_seis);


/***/ }),

/***/ 5848:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_siete_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9557);
/* harmony import */ var _section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _formularioExpansion_FormularioExpansion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6377);
/* harmony import */ var _mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9233);
/* harmony import */ var _mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_formularioExpansion_FormularioExpansion__WEBPACK_IMPORTED_MODULE_2__]);
_formularioExpansion_FormularioExpansion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Section_siete = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorSectionSiete),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                children: "\xbfQUIERES M\xc1S INFORMACI\xd3N?"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().contenedorBloques),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueIzq),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                children: "LL\xc1MANOS"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueIzqTexto),
                                children: "Contacta con nosotros para poder darte toda la informaci\xf3n necesaria sobre nuestras tiendas."
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueIzqInferior),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueHorario),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().nuestroHorario),
                                                children: "NUESTRO HORARIO"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueHorarios),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().horarioDias),
                                                children: "LUNES - VIERNES"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().horarioHoras),
                                                children: "9:00 - 21:00"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueHorariosDos),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().horariosDiasDos),
                                                children: "S\xc1BADO"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().horariosHorasDos),
                                                children: "9:00 - 15:00"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().horariosDiasTres),
                                                children: "DOMINGO"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().horariosHorasTres),
                                                children: "CERRADO"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_3___default()), {})
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: "tel:900 373 629",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "LLAMA GRATIS"
                                    }),
                                    " AL 900 373 629"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_section_siete_module_css__WEBPACK_IMPORTED_MODULE_4___default().bloqueDer),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_formularioExpansion_FormularioExpansion__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_siete);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7207);
/* harmony import */ var _section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Section_ocho = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorSectionOcho),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedorBloques),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueIzq)
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueDer),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "No olvides visitar nuestras redes sociales"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3___default().bloqueDerImagenes),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    target: "_blank",
                                    href: "https://www.instagram.com/quickgold.es/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: "/assets/img/imagenInstagram.png",
                                        alt: "Instagram",
                                        className: (_section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3___default().imagenRedes),
                                        width: 94,
                                        height: 85
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    target: "_blank",
                                    href: "https://www.linkedin.com/company/quickgold",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: "/assets/img/imagenLinkedin.png",
                                        alt: "Linkedin",
                                        className: (_section_ocho_module_css__WEBPACK_IMPORTED_MODULE_3___default().imagenRedes),
                                        width: 75,
                                        height: 81
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section_ocho);


/***/ }),

/***/ 3059:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ sendContactForm)
/* harmony export */ });
const sendContactForm = async (data)=>fetch("https://quickgold.es/api/contact", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json,"
        }
    }).then((res)=>{
        if (!res.ok) throw new Error("Failed to send message");
        return res.json();
    });


/***/ }),

/***/ 1982:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Expansion),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8874);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _componentes_ComponentesExpansion_section_1_Section_uno_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3977);
/* harmony import */ var _bradgarropy_next_seo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4579);
/* harmony import */ var _bradgarropy_next_seo__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_bradgarropy_next_seo__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _componentes_Layout_Layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7699);
/* harmony import */ var _componentes_ComponentesExpansion_section_2_Section_dos__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6609);
/* harmony import */ var _componentes_ComponentesExpansion_section_3_Section_tres__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5273);
/* harmony import */ var _componentes_ComponentesExpansion_section_4_Section_cuatro__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7979);
/* harmony import */ var _componentes_ComponentesExpansion_section_5_Section_cinco__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9095);
/* harmony import */ var _componentes_ComponentesExpansion_section_6_Section_seis__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8501);
/* harmony import */ var _componentes_ComponentesExpansion_section_7_Section_siete__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5848);
/* harmony import */ var _componentes_ComponentesExpansion_section_8_Section_ocho__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3659);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_componentes_ComponentesExpansion_section_7_Section_siete__WEBPACK_IMPORTED_MODULE_10__]);
_componentes_ComponentesExpansion_section_7_Section_siete__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



//import Breadcrumbs from "@/componentes/BreadcrumbsRaiz/Breadcrumbs.js";

//import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";









function Expansion({ menu_list , ciudad , general  }) {
    const schema = {
        "@context": "http://www.schema.org",
        "@type": "Organization",
        name: "Quickgold",
        url: `https://quickgold.es/expansion`,
        sameAs: [
            "https://instagram.com/quickgold.es",
            "https://twitter.com/quickgoldqg",
            "https://www.facebook.com/quickgold.es"
        ],
        logo: "https://quickgold.es/assets/logo-peque\xf1o.jpg",
        image: "https://quickgold.es/assets/logo-peque\xf1o.jpg",
        description: ciudad?.acf?.description_del_meta,
        address: {
            "@type": "PostalAddress",
            addressLocality: ciudad?.acf?.ciudad,
            addressRegion: ciudad?.acf?.ciudad,
            addressCountry: "Espa\xf1a"
        },
        contactPoint: {
            "@type": "ContactPoint",
            telephone: `+34 ${ciudad?.acf?.telefono}`,
            contactType: "info@quickgold.es"
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_bradgarropy_next_seo__WEBPACK_IMPORTED_MODULE_3___default()), {
                title: ciudad?.acf?.titulo_del_meta,
                description: ciudad?.description_del_meta,
                facebook: {
                    image: "/facebook.png",
                    url: "https://www.facebook.com/quickgold.es/",
                    type: "article"
                },
                twitter: {
                    image: "/twitter.png",
                    site: "@quickgoldQG",
                    card: "summary_large_image"
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify(schema)
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "stylesheet preload prefetch",
                        href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css",
                        as: "style"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("noscript", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "stylesheet",
                            href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_componentes_Layout_Layout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                menu_list: menu_list,
                ciudad: ciudad,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12___default().main)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_ComponentesExpansion_section_1_Section_uno_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_ComponentesExpansion_section_2_Section_dos__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_ComponentesExpansion_section_3_Section_tres__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_ComponentesExpansion_section_4_Section_cuatro__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_ComponentesExpansion_section_5_Section_cinco__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_ComponentesExpansion_section_6_Section_seis__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_ComponentesExpansion_section_7_Section_siete__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentes_ComponentesExpansion_section_8_Section_ocho__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
}
const idPaginaWp = "2700";
const apiGeneral = "13848";
//const idWp = "13848";
async function getStaticProps() {
    //datos de los campos personalizados de la ciudad
    const ciudad1 = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${idPaginaWp}`);
    const ciudad = await ciudad1.json();
    //fin datos de los campos personalizados de la ciudad
    const res = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${apiGeneral}`);
    const general = await res.json();
    const menu = await fetch(`https://panel.quickgold.es/wp-json/menus/v1/menus/2219`);
    const menu_list = await menu.json();
    return {
        props: {
            //markers,
            menu_list,
            ciudad,
            general
        },
        revalidate: 1
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4579:
/***/ ((module) => {

"use strict";
module.exports = require("@bradgarropy/next-seo");

/***/ }),

/***/ 1883:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 6741:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CheckCircle");

/***/ }),

/***/ 9233:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Circle");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 7140:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/EmailRounded");

/***/ }),

/***/ 7666:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 3983:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LocalPhoneRounded");

/***/ }),

/***/ 2906:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 5631:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4180:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/SwipeableDrawer");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5337:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll-to-top");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = import("@chakra-ui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,5675,7699], () => (__webpack_exec__(1982)));
module.exports = __webpack_exports__;

})();