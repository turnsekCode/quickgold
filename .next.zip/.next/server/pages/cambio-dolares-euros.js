(() => {
var exports = {};
exports.id = 1689;
exports.ids = [1689];
exports.modules = {

/***/ 1770:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__MxdWw",
	"linea": "section_uno_linea__HNGb3",
	"bloqueIzq": "section_uno_bloqueIzq__y9b7S",
	"bloqueDer": "section_uno_bloqueDer__B2DRz",
	"madridMobil": "section_uno_madridMobil__SqVFE",
	"botones": "section_uno_botones__d5EZK"
};


/***/ }),

/***/ 1854:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionDos": "sectionDos_contenedorSectionDos__Tskcy",
	"bloqueInferior": "sectionDos_bloqueInferior__6TzqR",
	"bloqueSuperior": "sectionDos_bloqueSuperior__HU_pU",
	"imagenventaja1": "sectionDos_imagenventaja1__eHrIr",
	"contenedorVentajas": "sectionDos_contenedorVentajas__LPku7",
	"linea": "sectionDos_linea__ZMfbL"
};


/***/ }),

/***/ 3494:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueDivHabituales": "estilosConversor_bloqueDivHabituales__WOcAF",
	"bloqueTituloSuperior": "estilosConversor_bloqueTituloSuperior__D5Cg4",
	"tituloDivisaHabitual": "estilosConversor_tituloDivisaHabitual__HoPaP",
	"divisasHabituales": "estilosConversor_divisasHabituales__sWKKz",
	"bloqueDer": "estilosConversor_bloqueDer__b_QRr",
	"bloqueDerInput": "estilosConversor_bloqueDerInput__cB_SH",
	"contenedorInput": "estilosConversor_contenedorInput__aur6I",
	"dolar": "estilosConversor_dolar__HHuQc",
	"libra": "estilosConversor_libra__HEYFN",
	"imgMoneda": "estilosConversor_imgMoneda__FZCkW",
	"nombreMoneda": "estilosConversor_nombreMoneda__Qcioa",
	"contenedorInputSuperior": "estilosConversor_contenedorInputSuperior__JXSvK",
	"contenedorInputInferior": "estilosConversor_contenedorInputInferior__RuaOQ",
	"bloqueIzqInput": "estilosConversor_bloqueIzqInput__dMI3m",
	"select": "estilosConversor_select__WpJBe",
	"select_monedas": "estilosConversor_select_monedas__8f2Et",
	"contenedor_list": "estilosConversor_contenedor_list__j_pA7",
	"moneda": "estilosConversor_moneda__9W8_Y",
	"nombre": "estilosConversor_nombre__yVCzg",
	"select_activo": "estilosConversor_select_activo__yrBiH",
	"bandera": "estilosConversor_bandera__mDDsh",
	"botonSwith": "estilosConversor_botonSwith__fN6u0",
	"monedaInferior": "estilosConversor_monedaInferior__H4md7",
	"selectCiudad": "estilosConversor_selectCiudad__Z8h_W",
	"botonLlamarTienda": "estilosConversor_botonLlamarTienda__JkUES",
	"selectCiudad_mobil": "estilosConversor_selectCiudad_mobil__UBTZs",
	"select_ciudad_mobil": "estilosConversor_select_ciudad_mobil__uSnzf",
	"select_ciudadOptionUno": "estilosConversor_select_ciudadOptionUno__jJo3Y",
	"contenedorOptions": "estilosConversor_contenedorOptions__h4Edw",
	"contenedorOptionsActivo": "estilosConversor_contenedorOptionsActivo__sVrjU",
	"listaCiudad": "estilosConversor_listaCiudad__CXY4B",
	"textoEntreInputs": "estilosConversor_textoEntreInputs__tQmNO",
	"select_ciudad": "estilosConversor_select_ciudad__yhLfm",
	"inputInferior": "estilosConversor_inputInferior__sST1B"
};


/***/ }),

/***/ 1229:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCuatro": "sectionCuatro_contenedorSectionCuatro__tyV90",
	"contenedorSectionCuatroMargen": "sectionCuatro_contenedorSectionCuatroMargen__gVsCa",
	"bloqueIzq": "sectionCuatro_bloqueIzq__Odb3Y",
	"bloqueDer": "sectionCuatro_bloqueDer__qZcYs",
	"linea": "sectionCuatro_linea__ObKOe"
};


/***/ }),

/***/ 2703:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCinco": "sectionDos_contenedorSectionCinco__tGkc4",
	"sectionCincoContenido": "sectionDos_sectionCincoContenido__ZscYt",
	"contenedorSectionCincoMargen": "sectionDos_contenedorSectionCincoMargen__SBE_n",
	"linea": "sectionDos_linea__AzuHD",
	"contenidoCard": "sectionDos_contenidoCard__JzXT5",
	"parrafoVenderDiamantes": "sectionDos_parrafoVenderDiamantes__TOXF3"
};


/***/ }),

/***/ 6549:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionSeis": "sectionSeis_contenedorSectionSeis__BmoyL",
	"contenedorSectionSeisMargen": "sectionSeis_contenedorSectionSeisMargen__CXRjc",
	"BannerSelectorCiudad": "sectionSeis_BannerSelectorCiudad__e9g7S",
	"tituloMobil": "sectionSeis_tituloMobil__Dokup",
	"SelectCiudades": "sectionSeis_SelectCiudades__yLSEh",
	"contenedorTexto": "sectionSeis_contenedorTexto__4Lcd1",
	"contenedorTiposDivisas": "sectionSeis_contenedorTiposDivisas__yjqsB",
	"contenedorTiposDivisasCard1": "sectionSeis_contenedorTiposDivisasCard1__BBXig"
};


/***/ }),

/***/ 3780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DolarEuro),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(8874);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: ./src/componentes/BreadcrumbsRaiz/Breadcrumbs.js
var Breadcrumbs = __webpack_require__(9206);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/ComponentesDolarEuro/Section_1/section_uno.module.css
var section_uno_module = __webpack_require__(1770);
var section_uno_module_default = /*#__PURE__*/__webpack_require__.n(section_uno_module);
// EXTERNAL MODULE: external "@mui/icons-material/LocationOnOutlined"
var LocationOnOutlined_ = __webpack_require__(3804);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
// EXTERNAL MODULE: ./src/utilities/useScreenSize.js
var useScreenSize = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/componentes/ComponentesDolarEuro/Section_1/Section_uno.js


//import Image from "next/image";





const Section_uno = ()=>{
    const { width  } = (0,useScreenSize/* default */.Z)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_uno_module_default()).contenedorSectionUno,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_uno_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: "Cambio de d\xf3lares a euros"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Si necesitas cambiar d\xf3lares por euros en Espa\xf1a, Quickgold es tu mejor opci\xf3n: ofrecemos un servicio totalmente especializado en d\xf3lares, realizamos mejoras por cantidad y ofrecemos el mejor precio de tu ciudad."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "Consulta el precio del d\xf3lar actualizado."
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (section_uno_module_default()).botones,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "tel:900 373 629",
                            title: "Tel\xe9fono",
                            children: "llama gratis al 900 373 629"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_uno_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/assets/dolar-euro/imagenDolarEuro.png",
                    alt: "Cambio dolar - euro",
                    className: (section_uno_module_default()).madridMobil,
                    width: 290,
                    height: 220
                })
            })
        ]
    });
};
/* harmony default export */ const Section_1_Section_uno = (Section_uno);

// EXTERNAL MODULE: ./src/componentes/ComponentesDolarEuro/Section_3/sectionCuatro.module.css
var sectionCuatro_module = __webpack_require__(1229);
var sectionCuatro_module_default = /*#__PURE__*/__webpack_require__.n(sectionCuatro_module);
// EXTERNAL MODULE: ./src/componentes/ComponentesDolarEuro/Section_3/ConversorDivisa/estilosConversor.module.css
var estilosConversor_module = __webpack_require__(3494);
var estilosConversor_module_default = /*#__PURE__*/__webpack_require__.n(estilosConversor_module);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowDown"
var KeyboardArrowDown_ = __webpack_require__(4845);
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_);
// EXTERNAL MODULE: external "@mui/icons-material/PowerInput"
var PowerInput_ = __webpack_require__(8711);
var PowerInput_default = /*#__PURE__*/__webpack_require__.n(PowerInput_);
// EXTERNAL MODULE: external "@mui/icons-material/ImportExport"
var ImportExport_ = __webpack_require__(5579);
var ImportExport_default = /*#__PURE__*/__webpack_require__.n(ImportExport_);
;// CONCATENATED MODULE: ./src/componentes/ComponentesDolarEuro/Section_3/ConversorDivisa/Comprar.js






const Comprar = ({ ListadoCiudades  })=>{
    const [ciudad, setCiudad] = (0,external_react_.useState)("");
    const [ciudadOpen, setCiudadOpen] = (0,external_react_.useState)(null);
    const [selectDivisa, setSelectDivisa] = (0,external_react_.useState)(true);
    const datosCiudad = ListadoCiudades.arrayMarker;
    const [data, setData] = (0,external_react_.useState)([]);
    //const datos = data;
    //console.log(datos.splice(0, 1, "USD"));
    (0,external_react_.useEffect)(()=>{
        fetch(`https://quickgold.es/archivos-cache/Fixing${ciudad}.txt`, {
            cache: "no-cache"
        }).then((response)=>response.json()).then((response)=>{
            setData(response?.result?.Tarifas?.Divisas_Compra.reverse());
        });
    }, [
        ciudad
    ]);
    //const [InputDivisa, setInputDivisa] = useState(<PowerInputIcon />);
    const [valorMoneda, setValorMoneda] = (0,external_react_.useState)("");
    const [DataAcronimo, setAcronimo] = (0,external_react_.useState)("");
    const [DataNombre, setDataNombre] = (0,external_react_.useState)("");
    const [valorInput, setValorInput] = (0,external_react_.useState)("");
    const [switched, setSwitched] = (0,external_react_.useState)(null);
    const [opened, setOpened] = (0,external_react_.useState)(true);
    const [select, setSelect] = (0,external_react_.useState)(null);
    const precioDividido = valorMoneda / 1000;
    const precioDividido2 = 1 / precioDividido;
    const valorFinal = valorInput * precioDividido;
    const valorFinal2 = valorInput / precioDividido;
    const captureCodigo = (e)=>{
        setAcronimo(e.target.dataset.acronimo);
        setValorMoneda(e.target.dataset.precio);
    };
    const MonedaSeleccionada = ()=>{
        setSelectDivisa(false);
    };
    const captureHabitual = (e)=>{
        setCiudadOpen(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (estilosConversor_module_default()).bloqueDer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueTituloSuperior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "CAMBIO DE D\xd3LAR A EURO"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Ciudad donde quieres cambiar"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).selectCiudad,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (estilosConversor_module_default()).select_ciudad,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    onClick: (event)=>{
                                        setSelect(false);
                                        setCiudadOpen(!ciudadOpen);
                                    },
                                    className: (estilosConversor_module_default()).select_ciudadOptionUno,
                                    children: [
                                        " ",
                                        opened ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Seleccione ciudad"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                            ]
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                DataNombre,
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: ciudadOpen ? `${(estilosConversor_module_default()).contenedorOptions} ${(estilosConversor_module_default()).contenedorOptionsActivo}` : `${(estilosConversor_module_default()).contenedorOptions}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                        children: datosCiudad.map((ciudad, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: (estilosConversor_module_default()).listaCiudad,
                                                onClick: (e)=>{
                                                    captureHabitual(e);
                                                    //setAcronimo(e.target.dataset.acronimo);
                                                    //setValorMoneda(e.target.dataset.precio);
                                                    setCiudad(e.target.dataset.minusculas);
                                                    setDataNombre(e.target.dataset.nombre);
                                                    setSelectDivisa(true);
                                                    setOpened(false);
                                                },
                                                "data-minusculas": ciudad.nombreMinusculas,
                                                "data-nombre": ciudad.nombre,
                                                children: ciudad.nombre
                                            }, i))
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).selectCiudad_mobil,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                            className: (estilosConversor_module_default()).select_ciudad_mobil,
                            onChange: (e)=>{
                                setCiudad(e.target.value);
                                setSelectDivisa(true);
                                setOpened(false);
                            },
                            children: datosCiudad.map((ciudad, i)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: ciudad.nombreMinusculas,
                                    children: ciudad.nombre
                                }, i))
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (estilosConversor_module_default()).textoEntreInputs,
                        children: "Selecciona la divisa D\xd3LAR para saber su precio"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).contenedorInputSuperior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).bloqueIzqInput,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (estilosConversor_module_default()).select,
                            onClick: ()=>{
                                setSelect(!select);
                            },
                            children: [
                                selectDivisa ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        "Seleccione Divisa",
                                        /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                    ]
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        DataAcronimo,
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: select ? `${(estilosConversor_module_default()).select_monedas} ${(estilosConversor_module_default()).select_activo}` : `${(estilosConversor_module_default()).select_monedas}`,
                                    children: data?.filter((currency)=>currency.Name !== "HRK" && currency.Name !== "DKK" && currency.Name !== "RUB" && currency.Name !== "NOK" && currency.Name !== "SEK").map((data, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (estilosConversor_module_default()).contenedor_list,
                                            "data-acronimo": data?.Productos[0].Acronimo,
                                            "data-precio": data?.Productos[0].Precio,
                                            onClick: (e)=>{
                                                captureCodigo(e);
                                                MonedaSeleccionada();
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (estilosConversor_module_default()).bandera,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: `/assets/${data?.Productos[0].Acronimo}.png`,
                                                        "data-acronimo": data?.Productos[0].Acronimo,
                                                        "data-precio": data?.Productos[0].Precio,
                                                        alt: data?.Productos[0].Acronimo
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: (estilosConversor_module_default()).moneda,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            "data-acronimo": data?.Productos[0].Acronimo,
                                                            "data-precio": data?.Productos[0].Precio,
                                                            children: data?.Productos[0].Acronimo
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: (estilosConversor_module_default()).nombre,
                                                            "data-acronimo": data?.Productos[0].Acronimo,
                                                            "data-precio": data?.Productos[0].Precio,
                                                            children: data?.Productos[0].Nombre
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, i))
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueDerInput,
                        children: [
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInput,
                                children: [
                                    switched ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        style: {
                                            border: "none"
                                        },
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "0.00",
                                        inputMode: "numeric",
                                        readOnly: true,
                                        value: valorFinal2.toFixed(2)
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "0.00",
                                        inputMode: "numeric",
                                        className: (estilosConversor_module_default()).inputInferior,
                                        onChange: (event)=>setValorInput(event.target.value)
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: DataAcronimo
                                    })
                                ]
                            }),
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "1",
                                    DataAcronimo,
                                    " = ",
                                    precioDividido.toFixed(4),
                                    "EUR"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (estilosConversor_module_default()).botonSwith,
                children: /*#__PURE__*/ jsx_runtime_.jsx((ImportExport_default()), {
                    onClick: (e)=>{
                        setSwitched(!switched);
                    }
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).contenedorInputInferior,
                children: [
                    selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("span", {}) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).monedaInferior,
                        children: "EUR"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueDerInput,
                        children: [
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).contenedorInput,
                                children: [
                                    switched ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "Cantidad",
                                        inputMode: "numeric",
                                        className: (estilosConversor_module_default()).inputInferior,
                                        onChange: (event)=>setValorInput(event.target.value)
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        pattern: "[0-9]*",
                                        placeholder: "Cantidad",
                                        inputMode: "numeric",
                                        value: valorFinal.toFixed(2),
                                        readOnly: true,
                                        style: {
                                            border: "none"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "EUR"
                                    })
                                ]
                            }),
                            selectDivisa ? /*#__PURE__*/ jsx_runtime_.jsx("p", {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "1EUR = ",
                                    precioDividido2.toFixed(4),
                                    DataAcronimo
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                className: (estilosConversor_module_default()).botonLlamarTienda,
                href: "tel:900 373 629",
                children: "LLAMAR A TIENDA"
            })
        ]
    });
};
/* harmony default export */ const ConversorDivisa_Comprar = (Comprar);

;// CONCATENATED MODULE: ./src/componentes/ComponentesDolarEuro/Section_3/SectionTres.js


//import Image from "next/image";


const SectionCuatro = ({ ListadoCiudades , setCiudadOpen , ciudadOpen  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (sectionCuatro_module_default()).contenedorSectionCuatro,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (sectionCuatro_module_default()).contenedorSectionCuatroMargen,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionCuatro_module_default()).bloqueIzq,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Precio del d\xf3lar hoy"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            children: [
                                "El precio del d\xf3lar hoy en Espa\xf1a es un tema de inter\xe9s para muchas personas que est\xe1n planeando viajar a Estados Unidos o que tienen transacciones internacionales. El valor del d\xf3lar en relaci\xf3n al euro puede fluctuar diariamente debido a diversos factores econ\xf3micos y pol\xedticos. En nuestra web puedes consultar la tasa de cambio actualizada siempre.",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                " En Quickgold te ofrecemos m\xe1s de 50 oficinas de cambio de d\xf3lares a euros por toda Espa\xf1a. Nuestras tiendas se encuentran en las mejores ubicaciones de cada ciudad y te ofrecemos un horario amplio de lunes a s\xe1bado (en determinadas tiendas podr\xe1s encontrar horario de apertura tambi\xe9n los domingos).",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                " Si quieres cambiar d\xf3lares a euros en Espa\xf1a, el precio puede variar, pero acudir a Quickgold es una excelente opci\xf3n para cambiar d\xf3lares a euros. Comprueba nuestro listado de tiendas y elige la m\xe1s cercana a tu ubicaci\xf3n. En nuestras casas de cambio de d\xf3lares ofrecemos tasas de cambio competitivas, transparencia y un servicio personalizado. Confiar en expertos en cambio de divisas te proporcionar\xe1 una experiencia segura y satisfactoria."
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (sectionCuatro_module_default()).bloqueDer,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(ConversorDivisa_Comprar, {
                        ListadoCiudades: ListadoCiudades,
                        setCiudadOpen: setCiudadOpen,
                        ciudadOpen: ciudadOpen
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const SectionTres = (SectionCuatro);

// EXTERNAL MODULE: ./src/componentes/Layout/Layout.js + 6 modules
var Layout = __webpack_require__(7699);
// EXTERNAL MODULE: ./src/componentes/ComponentesDolarEuro/Section_2/sectionDos.module.css
var sectionDos_module = __webpack_require__(1854);
var sectionDos_module_default = /*#__PURE__*/__webpack_require__.n(sectionDos_module);
;// CONCATENATED MODULE: ./src/componentes/ComponentesDolarEuro/Section_2/Section_dos.js




const Section_dos = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionDos_module_default()).contenedorSectionDos,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (sectionDos_module_default()).bloqueSuperior,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    children: [
                        "Ventajas de cambiar d\xf3lares en",
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (sectionDos_module_default()).linea,
                            children: "quickgold"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionDos_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/dolar-euro/imagenVentaja1.png",
                                    alt: "Mejor servicio y precio",
                                    width: 40,
                                    height: 41
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Servicio 100% personalizado"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/dolar-euro/imagenVentaja2.png",
                                    alt: "Mejor servicio y precio",
                                    width: 39,
                                    height: 35
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Precio del d\xf3lar siempre actualizado"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/dolar-euro/imagenVentaja3.png",
                                    alt: "Mejor servicio y precio",
                                    width: 37,
                                    height: 36
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "M\xe1s de 50 casas de cambio"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/dolar-euro/imagenVentaja4.png",
                                    alt: "Mejor servicio y precio",
                                    width: 31,
                                    height: 31
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Mejor tipo de cambio de tu ciudad"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/dolar-euro/imagenVentaja5.png",
                                    alt: "Mejor servicio y precio",
                                    width: 39,
                                    height: 41
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Euros en efectivo al instante"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/dolar-euro/imagenVentaja6.png",
                                    alt: "Mejor servicio y precio",
                                    width: 38,
                                    height: 38
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Sin comisiones"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_2_Section_dos = (Section_dos);

// EXTERNAL MODULE: ./src/componentes/ComponentesDolarEuro/Section_5/sectionDos.module.css
var Section_5_sectionDos_module = __webpack_require__(2703);
var Section_5_sectionDos_module_default = /*#__PURE__*/__webpack_require__.n(Section_5_sectionDos_module);
;// CONCATENATED MODULE: ./src/componentes/ComponentesDolarEuro/Section_5/Section_cinco.js



const Section_cinco = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (Section_5_sectionDos_module_default()).contenedorSectionCinco,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Section_5_sectionDos_module_default()).contenedorSectionCincoMargen,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    children: [
                        "C\xf3mo vender d\xf3lares en ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (Section_5_sectionDos_module_default()).linea,
                            children: "quickgold"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Section_5_sectionDos_module_default()).sectionCincoContenido,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Section_5_sectionDos_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Visita en tienda"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Acude a nuestra casa de cambio de d\xf3lares m\xe1s cercana e ind\xedcanos la cantidad de d\xf3lares que quieres cambiar a euros. Recuerda que realizamos mejoras en el tipo de cambio seg\xfan la cantidad a cambiar as\xed que siempre te vamos a ofrecer nuestro mejor precio y la mejor tasa de cambio de tu ciudad."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Section_5_sectionDos_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Acuerdo en precio"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Seg\xfan el tipo de cambio del d\xf3lar en ese momento, fijaremos el mejor precio del d\xf3lar hoy y comprobaremos tus d\xf3lares antes de realiza la transacci\xf3n."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Section_5_sectionDos_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Firma comprobante"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Te haremos firmar un comprobante en el que se indica la cantidad de d\xf3lares que nos has tra\xeddo y la cantidad de euros que recibes, un documento sencillo y r\xe1pido de gestionar."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Section_5_sectionDos_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Pago inmediato"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Una vez tenemos los d\xf3lares y el comprobante de la operaci\xf3n, nuestro equipo te dar\xe1 un sobre con los euros en efectivo que se acordaron para el pago."
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_5_Section_cinco = (Section_cinco);

// EXTERNAL MODULE: ./src/componentes/ComponentesDolarEuro/Section_6/sectionSeis.module.css
var sectionSeis_module = __webpack_require__(6549);
var sectionSeis_module_default = /*#__PURE__*/__webpack_require__.n(sectionSeis_module);
// EXTERNAL MODULE: ./src/componentes/SelectorCiudadesServicio/SelectorCiudadesServicio.js
var SelectorCiudadesServicio = __webpack_require__(5709);
;// CONCATENATED MODULE: ./src/componentes/ComponentesDolarEuro/Section_6/Section_seis.js




const Section_seis = ({ listadoCiudadesServicios  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (sectionSeis_module_default()).contenedorSectionSeis,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (sectionSeis_module_default()).contenedorSectionSeisMargen,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                    className: (sectionSeis_module_default()).tituloMobil,
                    children: "Nuestras tiendas compro oro"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionSeis_module_default()).BannerSelectorCiudad,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            children: "Nuestras casas de cambio"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (sectionSeis_module_default()).SelectCiudades,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(SelectorCiudadesServicio/* default */.Z, {
                                listadoCiudadesServicios: listadoCiudadesServicios
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Section_6_Section_seis = (Section_seis);

// EXTERNAL MODULE: external "@bradgarropy/next-seo"
var next_seo_ = __webpack_require__(4579);
var next_seo_default = /*#__PURE__*/__webpack_require__.n(next_seo_);
;// CONCATENATED MODULE: ./src/pages/cambio-dolares-euros/index.js











const schema = {
    "@context": "http://www.schema.org",
    "@type": "Organization",
    name: "Quickgold",
    url: "https://quickgold.es/cambio-dolares-euros/",
    sameAs: [
        "https://instagram.com/quickgold.es",
        "https://twitter.com/quickgoldqg",
        "https://www.facebook.com/quickgold.es"
    ],
    logo: "/assets/img/logo.jpg",
    image: "/assets/img/logo.jpg",
    description: "Cambia d\xf3lares por euros en nuestras oficinas de cambio de divisas Quickgold. Precio del d\xf3lar siempre actualizado y el mejor tipo de cambio de tu ciudad.",
    address: {
        "@type": "PostalAddress",
        addressCountry: "Espa\xf1a"
    },
    contactPoint: {
        "@type": "ContactPoint",
        telephone: "+34 900 373 629",
        contactType: "info@quickgold.es"
    }
};
function DolarEuro({ menu_list , ListadoCiudades , listadoCiudadesServicios , ciudad  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((next_seo_default()), {
                title: ciudad?.acf?.titulo_del_meta,
                description: ciudad?.acf?.descripcion_del_meta,
                icon: "/favicon.png",
                facebook: {
                    image: "/facebook.png",
                    url: "https://www.facebook.com/quickgold.es/",
                    type: "article"
                },
                twitter: {
                    image: "/twitter.png",
                    site: "@quickgoldQG",
                    card: "summary_large_image"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify(schema)
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "TTBUdVkwdzVOOVRpSWV3Nk03anRNMj10",
                        value: "934244db009f8690634f7f94258d34e2"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
                menu_list: menu_list,
                ciudad: ciudad,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Home_module_default()).main,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs/* default */.Z, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_1_Section_uno, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionTres, {
                        ListadoCiudades: ListadoCiudades
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_2_Section_dos, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_5_Section_cinco, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_6_Section_seis, {
                        listadoCiudadesServicios: listadoCiudadesServicios
                    })
                ]
            })
        ]
    });
}
const idPaginaWp = "16708";
async function getStaticProps() {
    const ciudad1 = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${idPaginaWp}`);
    const ciudad = await ciudad1.json();
    const Listado = await fetch(`https://panel.quickgold.es/ListadoCiudadesSelectorCalculadora/listadoCiudades.json`);
    const ListadoCiudades = await Listado.json();
    const listadoServicio = await fetch(`https://panel.quickgold.es/ListadoCiudadesServicio/listadoCiudadesServicioDivisa.json`);
    const listadoCiudadesServicios = await listadoServicio.json();
    const menu = await fetch(`https://panel.quickgold.es/wp-json/menus/v1/menus/2219`);
    const menu_list = await menu.json();
    // Pass data to the page via props
    return {
        props: {
            menu_list,
            ListadoCiudades,
            listadoCiudadesServicios,
            ciudad
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

if (false) { var height1, width1; }
const useScreenSize = ()=>{
    const [width, setWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(width1);
    const [height, setHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(height1);
    if (false) {}
    return {
        width,
        height
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScreenSize);


/***/ }),

/***/ 4579:
/***/ ((module) => {

"use strict";
module.exports = require("@bradgarropy/next-seo");

/***/ }),

/***/ 6741:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CheckCircle");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 7666:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 5579:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ImportExport");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 3804:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LocationOnOutlined");

/***/ }),

/***/ 2906:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 8711:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/PowerInput");

/***/ }),

/***/ 5631:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4180:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/SwipeableDrawer");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 5337:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll-to-top");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,5675,7699,5799,5709], () => (__webpack_exec__(3780)));
module.exports = __webpack_exports__;

})();