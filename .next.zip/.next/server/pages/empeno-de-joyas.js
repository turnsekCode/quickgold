(() => {
var exports = {};
exports.id = 7157;
exports.ids = [7157];
exports.modules = {

/***/ 3477:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueDer": "selecCiudad_bloqueDer__mfEzT",
	"contenidoBloqueDer": "selecCiudad_contenidoBloqueDer__5qxYw",
	"linea": "selecCiudad_linea__bZbv9",
	"bloqueSuperiorTexto": "selecCiudad_bloqueSuperiorTexto__ebr3h",
	"bloqueIzqInferior": "selecCiudad_bloqueIzqInferior__Vm_zN",
	"bloqueInferior": "selecCiudad_bloqueInferior__lj5Fr",
	"bloqueInferiorTexto1": "selecCiudad_bloqueInferiorTexto1__mQkid",
	"bloqueInferiorTexto2": "selecCiudad_bloqueInferiorTexto2__y6QLn",
	"bloqueInferiorTexto3": "selecCiudad_bloqueInferiorTexto3__ONu_n",
	"ContenedorSelect": "selecCiudad_ContenedorSelect__Hc5Jy",
	"select": "selecCiudad_select__FDyQh",
	"botonIrCiudad": "selecCiudad_botonIrCiudad__tfUpN",
	"bloqueInferiorTexto4": "selecCiudad_bloqueInferiorTexto4__oeI_i",
	"botonLlamar": "selecCiudad_botonLlamar__6lcRh",
	"contenedorInfo": "selecCiudad_contenedorInfo__BK2GP",
	"segundoParrafo": "selecCiudad_segundoParrafo__UBad2",
	"ejemplo": "selecCiudad_ejemplo__SnQG2",
	"primerParrafo": "selecCiudad_primerParrafo__W2vIT",
	"tercerParrafo": "selecCiudad_tercerParrafo__bkZLi",
	"cuartoParrafo": "selecCiudad_cuartoParrafo__M3amC"
};


/***/ }),

/***/ 3066:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__RpGkQ",
	"linea": "section_uno_linea__e1t7u",
	"bloqueIzq": "section_uno_bloqueIzq__F0HzW",
	"bloqueDer": "section_uno_bloqueDer___rRie",
	"botones": "section_uno_botones__rqXZR",
	"botonPopUp": "section_uno_botonPopUp__VNNJy",
	"imagenJoyas": "section_uno_imagenJoyas__2HS1h"
};


/***/ }),

/***/ 6989:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionTresMargen": "sectionTres_contenedorSectionTresMargen__ibq7x",
	"bloqueIzq": "sectionTres_bloqueIzq__DdoNB",
	"linea": "sectionTres_linea___0iyN",
	"contenidoTextos": "sectionTres_contenidoTextos__1h3QO",
	"textoUno": "sectionTres_textoUno__Drjeq",
	"textoDos": "sectionTres_textoDos__Us84h",
	"textoTres": "sectionTres_textoTres__VtF4w"
};


/***/ }),

/***/ 1612:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCinco": "sectionCuatro_contenedorSectionCinco__YcrYb",
	"sectionCincoContenido": "sectionCuatro_sectionCincoContenido__8hJtM",
	"contenedorSectionCincoMargen": "sectionCuatro_contenedorSectionCincoMargen__DiLxU",
	"linea": "sectionCuatro_linea___r_SN",
	"contenidoCard": "sectionCuatro_contenidoCard__3h0vO"
};


/***/ }),

/***/ 3426:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCuatro": "sectionCuatro_contenedorSectionCuatro__DOO53",
	"contenedorSectionCuatroMargen": "sectionCuatro_contenedorSectionCuatroMargen__D0w58",
	"bloqueIzq": "sectionCuatro_bloqueIzq__jm_2_",
	"bloqueDer": "sectionCuatro_bloqueDer__YopjF",
	"bloqueDerPc": "sectionCuatro_bloqueDerPc__57p30",
	"bloqueDerPcTitulo": "sectionCuatro_bloqueDerPcTitulo__gK694",
	"bloqueDerPcTextoUno": "sectionCuatro_bloqueDerPcTextoUno__xJbor",
	"bloqueDerPcCuadro": "sectionCuatro_bloqueDerPcCuadro__6ohLd",
	"bloqueDerPcTextoDos": "sectionCuatro_bloqueDerPcTextoDos___JI9e",
	"bloqueDerPcTextoTres": "sectionCuatro_bloqueDerPcTextoTres__R0J_o",
	"bloqueIzqTexto": "sectionCuatro_bloqueIzqTexto___cFju",
	"select": "sectionCuatro_select__LMkhK",
	"botonLlamar": "sectionCuatro_botonLlamar__cVrTh",
	"botonPopUp": "sectionCuatro_botonPopUp__wQDMo",
	"bloqueDerLista": "sectionCuatro_bloqueDerLista__CenzK",
	"adornoMobil": "sectionCuatro_adornoMobil__nwieK",
	"bloqueSuperiorTexto": "sectionCuatro_bloqueSuperiorTexto__7La9f",
	"linea": "sectionCuatro_linea__3GxJ9"
};


/***/ }),

/***/ 575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ EmpenoJoyas),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/componentes/BreadcrumbsRaiz/Breadcrumbs.js
var Breadcrumbs = __webpack_require__(9206);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowRight"
var KeyboardArrowRight_ = __webpack_require__(547);
var KeyboardArrowRight_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowRight_);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(8874);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: ./src/componentes/Layout/Layout.js + 6 modules
var Layout = __webpack_require__(7699);
// EXTERNAL MODULE: external "@bradgarropy/next-seo"
var next_seo_ = __webpack_require__(4579);
var next_seo_default = /*#__PURE__*/__webpack_require__.n(next_seo_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/Empeno-de-joyas/Section_1/section_uno.module.css
var section_uno_module = __webpack_require__(3066);
var section_uno_module_default = /*#__PURE__*/__webpack_require__.n(section_uno_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
;// CONCATENATED MODULE: ./src/componentes/Empeno-de-joyas/Section_1/Section_uno.js





const Section_uno = ({ ciudad , listadoUrlCiudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_uno_module_default()).contenedorSectionUno,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_uno_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: "Empe\xf1o de joyas con las mejores condiciones"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "El empe\xf1o de joyas es una excelente opci\xf3n si necesitas disponer de liquidez inmediata pero no quieres vender tus joyas. En quickgold ofrecemos las mejores condiciones para que puedas empe\xf1ar tus joyas sin preocuparte por nada."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_uno_module_default()).botones,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                to: "calculadoraOro",
                                smooth: true,
                                offset: -110,
                                spy: true,
                                duration: 500,
                                title: "Conocer precio del oro",
                                passive: "true",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (section_uno_module_default()).botonPopUp,
                                    title: "Conocer precio del oro",
                                    children: "CONOCE EL PRECIO DEL ORO"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (section_uno_module_default()).botonLlamar,
                                href: `tel:${ciudad?.acf?.telefono}`,
                                title: "Tel\xe9fono",
                                children: "llama gratis"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_uno_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/assets/img/imagenEmpenojoyas.png",
                    alt: "Empe\xf1ar joyas",
                    className: (section_uno_module_default()).imagenJoyas,
                    width: 432,
                    height: 382,
                    priority: true
                })
            })
        ]
    });
};
/* harmony default export */ const Section_1_Section_uno = (Section_uno);

// EXTERNAL MODULE: ./src/componentes/Empeno-de-joyas/Section_3/sectionTres.module.css
var sectionTres_module = __webpack_require__(6989);
var sectionTres_module_default = /*#__PURE__*/__webpack_require__.n(sectionTres_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/componentes/Empeno-de-joyas/Section_3/Section_tres.js





const Section_tres = ({ ciudad  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (sectionTres_module_default()).contenedorSectionTres,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (sectionTres_module_default()).contenedorSectionTresMargen,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionTres_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: "El mejor sitio donde empe\xf1ar joyas en tu ciudad"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (sectionTres_module_default()).textoUno,
                        children: "*Para realizar cambios de divisa es necesario ser mayor de edad y aportar DNI en vigor."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (sectionTres_module_default()).textoDos,
                        children: "En quickgold llevamos casi dos d\xe9cadas al frente del servicio de empe\xf1os. Somos los favoritos de nuestros clientes por nuestra atenci\xf3n personalizada, en la que nos adaptamos a tus necesidades. Adem\xe1s, contamos con un perfil profesional experto en el tratamiento de metales preciosos por lo que tu tasaci\xf3n siempre se hace de manera 100% segura y transparente."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (sectionTres_module_default()).textoTres,
                        children: [
                            "En quickgold puedes empe\xf1ar joyas o piezas de oro, plata, diamantes, etc. V\xedsitanos y descubre todas las facilidades en pr\xe9stamos por joyas. Localiza tu tienda con nuestro",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/tiendas",
                                    children: "buscador."
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Section_3_Section_tres = (Section_tres);

// EXTERNAL MODULE: ./src/componentes/Empeno-de-joyas/Section_4/sectionCuatro.module.css
var sectionCuatro_module = __webpack_require__(1612);
var sectionCuatro_module_default = /*#__PURE__*/__webpack_require__.n(sectionCuatro_module);
;// CONCATENATED MODULE: ./src/componentes/Empeno-de-joyas/Section_4/Section_cuatro.js



const Section_cuatro = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionCuatro_module_default()).contenedorSectionCinco,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCuatro_module_default()).contenedorSectionCincoMargen,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "Nuestros empe\xf1os est\xe1n pensados para tu comodidad"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "Si necesitas ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "obtener dinero extra"
                            }),
                            " por tus joyas pero no quieres desprenderte de ellas, te ayudamos. Trae tus joyas a quickgold y descubre nuestro servicio de empe\xf1os. Nuestro procedimiento es el siguiente:"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCuatro_module_default()).sectionCincoContenido,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCuatro_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Comprobaci\xf3n de las joyas a empe\xf1ar"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Realizamos una tasaci\xf3n para conocer las caracter\xedsticas de las piezas y determinar as\xed, el valor del pr\xe9stamo. Todo este proceso se realiza a la vista e informando de cada paso."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCuatro_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Explicaci\xf3n de las condiciones de empe\xf1os"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Informamos con claridad de todas las partes del acuerdo para que de forma sencilla y clara est\xe9s al d\xeda de las condiciones del pr\xe9stamo como son: importes, plazos, inter\xe9s aplicado, etc. Recuerda que durante el primer mes de empe\xf1o no pagas intereses, por lo que si te decides a recuperar tus joyas pasado este tiempo solo abonar\xe1s el valor del empe\xf1o."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCuatro_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Valoraci\xf3n de las piezas de oro"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Tras estipular la cantidad, firmamos el contrato."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCuatro_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Pago inmediato del valor fijado y acordado"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Una vez firmado el acuerdo te entregamos el dinero en el momento, sin esperas ni gestiones de solvencia. Obt\xe9n tu dinero en efectivo o por transferencia, como prefieras. As\xed de f\xe1cil."
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_4_Section_cuatro = (Section_cuatro);

// EXTERNAL MODULE: ./src/componentes/Empeno-de-joyas/Section_6/sectionCuatro.module.css
var Section_6_sectionCuatro_module = __webpack_require__(3426);
var Section_6_sectionCuatro_module_default = /*#__PURE__*/__webpack_require__.n(Section_6_sectionCuatro_module);
// EXTERNAL MODULE: ./src/componentes/Empeno-de-joyas/ComponenteSelectCiudades/selecCiudad.module.css
var selecCiudad_module = __webpack_require__(3477);
var selecCiudad_module_default = /*#__PURE__*/__webpack_require__.n(selecCiudad_module);
;// CONCATENATED MODULE: ./src/componentes/Empeno-de-joyas/ComponenteSelectCiudades/SelectCiudad.js




const SelectCiudad = ({ listadoUrlCiudad , ciudad  })=>{
    const [urlSelect, setUrlSelect] = (0,external_react_.useState)("");
    const listadoCiudades = listadoUrlCiudad?.arrayMarker;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "calculadoraOro",
        className: (selecCiudad_module_default()).bloqueDer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (selecCiudad_module_default()).bloqueSuperiorTexto,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Empe\xf1o de joyas"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "\xbfCu\xe1nto cuesta ahora el oro?"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (selecCiudad_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto3,
                        children: [
                            "Selecciona tu ciudad y haz clic en",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "conoce el precio del oro para saberlo."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (selecCiudad_module_default()).ContenedorSelect,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                onChange: (e)=>{
                                    setUrlSelect(e.target.value);
                                },
                                className: (selecCiudad_module_default()).select,
                                children: listadoCiudades.map((ciudad, i)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: ciudad.nombreMinusculas,
                                        children: ciudad.nombre
                                    }, i))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                className: (selecCiudad_module_default()).botonIrCiudad,
                                href: `/tiendas/compro-oro-${urlSelect}`,
                                children: "CONOCE EL PRECIO DEL ORO"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (selecCiudad_module_default()).contenidoEjemplo,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (selecCiudad_module_default()).contenedorInfo,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                    children: "PONGAMOS UN EJEMPLO"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: (selecCiudad_module_default()).segundoParrafo,
                                    children: [
                                        "Para un empe\xf1o con inter\xe9s al",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "3% mensual y 0% de inter\xe9s primer mes:"
                                        }),
                                        " "
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (selecCiudad_module_default()).ejemplo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (selecCiudad_module_default()).primerParrafo,
                                            children: "Con un valor de tus joyas de 100€, recibes 97€."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (selecCiudad_module_default()).tercerParrafo,
                                            children: "Conlleva un peque\xf1o gasto de gesti\xf3n del 3%"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (selecCiudad_module_default()).cuartoParrafo,
                                    children: "Para recuperar las piezas empe\xf1adas pasado el primer mes y finalizar el contrato deber\xedas abonar 100€."
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: `tel:${ciudad?.acf?.telefono}`,
                        className: (selecCiudad_module_default()).botonLlamar,
                        children: "LLAMA GRATIS"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ComponenteSelectCiudades_SelectCiudad = (SelectCiudad);

;// CONCATENATED MODULE: ./src/componentes/Empeno-de-joyas/Section_6/Section_seis.js





const Section_seis_Section_cuatro = ({ ciudad , listadoUrlCiudad  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (Section_6_sectionCuatro_module_default()).contenedorSectionCuatro,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (Section_6_sectionCuatro_module_default()).contenedorSectionCuatroMargen,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(ComponenteSelectCiudades_SelectCiudad, {
                    listadoUrlCiudad: listadoUrlCiudad,
                    ciudad: ciudad
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Section_6_sectionCuatro_module_default()).bloqueDerPc,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: (Section_6_sectionCuatro_module_default()).bloqueDerPcTitulo,
                            children: [
                                "Empe\xf1ar joyas en ",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (Section_6_sectionCuatro_module_default()).linea,
                                    children: "quickgold"
                                }),
                                " es f\xe1cil"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (Section_6_sectionCuatro_module_default()).bloqueDerPcTextoUno,
                            children: "Puedes empe\xf1ar piezas de oro, plata y brillantes de forma c\xf3moda y segura. Nuestro equipo de profesionales se encargar\xe1 de realizar todo el proceso siempre a la vista y detallando toda la informaci\xf3n en cada paso que van realizando."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (Section_6_sectionCuatro_module_default()).bloqueDerPcTextoDos,
                            children: "Adem\xe1s, contamos con todos los instrumentos necesarios para que se realice con total precisi\xf3n. En quickgold nos encanta cuidar de nuestros clientes por lo que de forma exclusiva siempre nos adaptamos a tus necesidades."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (Section_6_sectionCuatro_module_default()).bloqueDerPcTextoTres,
                            children: "0% de inter\xe9s el primer mes."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/assets/img/adornoCalculadoraEmpeno.png",
                            width: 200,
                            height: 192,
                            alt: "cambio divisas"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Section_seis = (Section_seis_Section_cuatro);

;// CONCATENATED MODULE: ./src/pages/empeno-de-joyas/index.js











function EmpenoJoyas({ menu_list , ciudad , listadoUrlCiudad  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((next_seo_default()), {
                title: ciudad?.acf?.titulo_del_meta,
                description: ciudad?.acf?.descripcion_del_meta,
                icon: "/favicon.png",
                facebook: {
                    image: "/facebook.png",
                    url: "https://www.facebook.com/quickgold.es/",
                    type: "article"
                },
                twitter: {
                    image: "/twitter.png",
                    site: "@quickgoldQG",
                    card: "summary_large_image"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet preload prefetch",
                        href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css",
                        as: "style"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("noscript", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("link", {
                            rel: "stylesheet",
                            href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
                menu_list: menu_list,
                ciudad: ciudad,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Home_module_default()).main,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs/* default */.Z, {
                                raiz: "Quickgold",
                                iconoRaiz: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {}),
                                urlUbicacionActual: "/empeno-de-joyas/",
                                iconoUbiccionActual: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {}),
                                ubicacionActual: "Empe\xf1o de joyas"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_1_Section_uno, {
                                ciudad: ciudad,
                                listadoUrlCiudad: listadoUrlCiudad
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_seis, {
                                ciudad: ciudad,
                                listadoUrlCiudad: listadoUrlCiudad
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_3_Section_tres, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_4_Section_cuatro, {
                        ciudad: ciudad
                    })
                ]
            })
        ]
    });
}
const idTienda = "empenojoyas";
const idPaginaWp = "7692";
const apiGeneral = "13848";
//const idWp = "13848";
async function getStaticProps() {
    //datos de los campos personalizados de la ciudad
    const ciudad1 = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${idPaginaWp}`);
    const ciudad = await ciudad1.json();
    //fin datos de los campos personalizados de la ciudad
    const res = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${apiGeneral}`);
    const general = await res.json();
    /*const response = await fetch(
    `https://quickgold.es/wp-json/wp/v2/pages/${idWp}`
  );
  const dataIdWp = await response.json();*/ const Listado = await fetch(`https://panel.quickgold.es/ListadoDeUrlDeCiudad/listadoUrlCiudad.json`);
    const listadoUrlCiudad = await Listado.json();
    const menu = await fetch(`https://panel.quickgold.es/wp-json/menus/v1/menus/2219`);
    const menu_list = await menu.json();
    return {
        props: {
            menu_list,
            ciudad,
            listadoUrlCiudad
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 4579:
/***/ ((module) => {

"use strict";
module.exports = require("@bradgarropy/next-seo");

/***/ }),

/***/ 6741:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CheckCircle");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 7666:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 547:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowRight");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 2906:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 5631:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4180:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/SwipeableDrawer");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 5337:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll-to-top");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,5675,3573,676,1664,7699,5799], () => (__webpack_exec__(575)));
module.exports = __webpack_exports__;

})();