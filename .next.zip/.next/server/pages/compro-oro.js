(() => {
var exports = {};
exports.id = 8469;
exports.ids = [8469];
exports.modules = {

/***/ 4772:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueDer": "selecCiudad_bloqueDer__zWPkZ",
	"contenidoBloqueDer": "selecCiudad_contenidoBloqueDer__OyVeG",
	"linea": "selecCiudad_linea__LvLPb",
	"bloqueSuperiorTexto": "selecCiudad_bloqueSuperiorTexto__JC9AQ",
	"bloqueIzqInferior": "selecCiudad_bloqueIzqInferior__lWP01",
	"bloqueInferior": "selecCiudad_bloqueInferior__1Tq1o",
	"bloqueInferiorTexto1": "selecCiudad_bloqueInferiorTexto1__01XRY",
	"bloqueInferiorTexto2": "selecCiudad_bloqueInferiorTexto2__2Cw_v",
	"bloqueInferiorTexto3": "selecCiudad_bloqueInferiorTexto3__lf92R",
	"ContenedorSelect": "selecCiudad_ContenedorSelect__7M2Rc",
	"select": "selecCiudad_select__YoFFS",
	"botonIrCiudad": "selecCiudad_botonIrCiudad__PhpUn",
	"bloqueInferiorTexto4": "selecCiudad_bloqueInferiorTexto4__iITHd",
	"botonLlamar": "selecCiudad_botonLlamar__H1OUx"
};


/***/ }),

/***/ 3588:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__Nb_Si",
	"linea": "section_uno_linea__QAeTJ",
	"bloqueIzq": "section_uno_bloqueIzq__qGolw",
	"bloqueDer": "section_uno_bloqueDer__OmvwL",
	"madridMobil": "section_uno_madridMobil__UfBhE",
	"botones": "section_uno_botones__rsL_M",
	"botonPopUp": "section_uno_botonPopUp__3rQJ8"
};


/***/ }),

/***/ 6634:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionTresMargen": "sectionTres_contenedorSectionTresMargen__GX4Do",
	"bloqueIzq": "sectionTres_bloqueIzq__C9OUu"
};


/***/ }),

/***/ 8089:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionDos": "sectionDos_contenedorSectionDos__mAM_U",
	"bloqueInferior": "sectionDos_bloqueInferior__DhSxU",
	"bloqueSuperior": "sectionDos_bloqueSuperior__kUzVr",
	"imagenventaja1": "sectionDos_imagenventaja1__yaX6k",
	"contenedorVentajas": "sectionDos_contenedorVentajas__2KO1J",
	"linea": "sectionDos_linea__xFDEP"
};


/***/ }),

/***/ 1470:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCinco": "sectionCinco_contenedorSectionCinco__Jmvg_",
	"sectionCincoContenido": "sectionCinco_sectionCincoContenido__CnR5z",
	"contenedorSectionCincoMargen": "sectionCinco_contenedorSectionCincoMargen__M5kbc",
	"linea": "sectionCinco_linea__523j6",
	"contenidoCard": "sectionCinco_contenidoCard__ln_hL"
};


/***/ }),

/***/ 4988:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionSeis": "sectionSeis_contenedorSectionSeis__nlh7S",
	"contenedorSectionSeisMargen": "sectionSeis_contenedorSectionSeisMargen__v2lGi",
	"tituloMobil": "sectionSeis_tituloMobil__nHXDL",
	"SelectCiudades": "sectionSeis_SelectCiudades__P8NR_",
	"contenedorTexto": "sectionSeis_contenedorTexto__K_BS0",
	"contenedorTiposOro": "sectionSeis_contenedorTiposOro__WdpmL",
	"contenedorTiposOroCard1": "sectionSeis_contenedorTiposOroCard1__DlThX",
	"contenedorTiposOroCard2": "sectionSeis_contenedorTiposOroCard2__NBwiU"
};


/***/ }),

/***/ 145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ComproOro),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(8874);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: ./src/componentes/BreadcrumbsRaiz/Breadcrumbs.js
var Breadcrumbs = __webpack_require__(9206);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowRight"
var KeyboardArrowRight_ = __webpack_require__(547);
var KeyboardArrowRight_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowRight_);
// EXTERNAL MODULE: ./src/componentes/Layout/Layout.js + 6 modules
var Layout = __webpack_require__(7699);
// EXTERNAL MODULE: external "@bradgarropy/next-seo"
var next_seo_ = __webpack_require__(4579);
var next_seo_default = /*#__PURE__*/__webpack_require__.n(next_seo_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/Compro-oro/Section_1/section_uno.module.css
var section_uno_module = __webpack_require__(3588);
var section_uno_module_default = /*#__PURE__*/__webpack_require__.n(section_uno_module);
// EXTERNAL MODULE: ./src/utilities/useScreenSize.js
var useScreenSize = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
;// CONCATENATED MODULE: ./src/componentes/Compro-oro/Section_1/Section_uno.js






//import PopUpCiudades from "@/componentes/PopUpCiudades/PopUpCiudades";
const Section_uno = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_uno_module_default()).contenedorSectionUno,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_uno_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        children: [
                            "Tiendas compro oro ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (section_uno_module_default()).linea,
                                children: "quickgold"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Si tienes joyas de oro que ya no desees tener y quieres obtener dinero extra por ellas, elige vender tus piezas de oro en quickgold y te garantizamos el servicio que estabas buscando, con una valoraci\xf3n a la vista, detallada y a un precio justo. Somos tu Compro Oro de confianza."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_uno_module_default()).botones,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                to: "calculadoraOro",
                                smooth: true,
                                offset: -110,
                                spy: true,
                                duration: 500,
                                title: "Conocer precio del oro",
                                passive: "true",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (section_uno_module_default()).botonPopUp,
                                    title: "Conocer precio del oro",
                                    children: "CONOCE EL PRECIO DEL ORO"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (section_uno_module_default()).botonLlamar,
                                href: `tel:${ciudad?.acf?.telefono}`,
                                title: "Tel\xe9fono",
                                children: "llama gratis"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_uno_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/assets/img/imagenComproOro.png",
                    alt: "Compro oro",
                    className: (section_uno_module_default()).madridMobil,
                    width: 480,
                    height: 364,
                    priority: true
                })
            })
        ]
    });
};
/* harmony default export */ const Section_1_Section_uno = (Section_uno);

// EXTERNAL MODULE: ./src/componentes/Compro-oro/Section_3/sectionDos.module.css
var sectionDos_module = __webpack_require__(8089);
var sectionDos_module_default = /*#__PURE__*/__webpack_require__.n(sectionDos_module);
;// CONCATENATED MODULE: ./src/componentes/Compro-oro/Section_3/Section_tres.js




const Section_dos = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionDos_module_default()).contenedorSectionDos,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionDos_module_default()).bloqueSuperior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        children: [
                            "Disfruta de ventajas exclusivas en",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (sectionDos_module_default()).linea,
                                children: "quickgold"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "*Para realizar una venta de oro es necesario ser mayor de edad y aportar DNI en vigor."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionDos_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenVentaja1.png",
                                    alt: "a c\xf3mo est\xe1 el oro",
                                    width: 39,
                                    height: 41
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Mejor servicio y precio garantizado."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenVentaja2.png",
                                    alt: "precio oro",
                                    width: 38,
                                    height: 35
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Precio del oro siempre actualizado."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenVentaja3.png",
                                    alt: "tiendas compro oro",
                                    width: 36,
                                    height: 36
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "M\xe1s de 50 tiendas para realizar tu venta de oro."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenVentaja4.png",
                                    alt: "vender oro",
                                    width: 41,
                                    height: 35
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Atenci\xf3n personalizada."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenVentaja5.png",
                                    alt: "vender joyas",
                                    width: 38,
                                    height: 38
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Dinero en efectivo al instante."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenVentaja6.png",
                                    alt: "tasaci\xf3n oro",
                                    width: 38,
                                    height: 38
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Tasaci\xf3n profesional, justa y segura."
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_tres = (Section_dos);

// EXTERNAL MODULE: ./src/componentes/Compro-oro/Section_2/sectionTres.module.css
var sectionTres_module = __webpack_require__(6634);
var sectionTres_module_default = /*#__PURE__*/__webpack_require__.n(sectionTres_module);
// EXTERNAL MODULE: ./src/componentes/Compro-oro/ComponenteSelectCiudades/selecCiudad.module.css
var selecCiudad_module = __webpack_require__(4772);
var selecCiudad_module_default = /*#__PURE__*/__webpack_require__.n(selecCiudad_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/componentes/Compro-oro/ComponenteSelectCiudades/SelectCiudad.js




const SelectCiudad = ({ listadoCiudades , urlSelect , setUrlSelect , ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "calculadoraOro",
        className: (selecCiudad_module_default()).bloqueDer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (selecCiudad_module_default()).bloqueSuperiorTexto,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Precio del oro"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "\xbfCu\xe1nto cuesta ahora el oro?"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (selecCiudad_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto1,
                        children: "\xbfTe gustar\xeda conocer el precio del oro?"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto2,
                        children: [
                            "En ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "quickgold"
                            }),
                            " encontrar\xe1s nuestro principal servicio de Compro Oro, con el que tasamos todas las piezas a la vista para garantizarte una operaci\xf3n segura y un precio justo para todo el oro que quieras vender. No importa si est\xe1n desemparejadas o rotas."
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto3,
                        children: [
                            "Selecciona tu ciudad y haz clic en",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "conoce el precio del oro para saberlo."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (selecCiudad_module_default()).ContenedorSelect,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                onChange: (e)=>{
                                    setUrlSelect(e.target.value);
                                },
                                className: (selecCiudad_module_default()).select,
                                children: listadoCiudades.map((ciudad, i)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: ciudad.nombreMinusculas,
                                        children: ciudad.nombre
                                    }, i))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                className: (selecCiudad_module_default()).botonIrCiudad,
                                href: `/tiendas/compro-oro-${urlSelect}`,
                                children: "CONOCE EL PRECIO DEL ORO"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto4,
                        children: "Si lo prefieres, tambi\xe9n puedes llamarnos e informarte. \xa1Estaremos encantados de resolver todas tus dudas!"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: `tel:${ciudad?.acf?.telefono}`,
                        className: (selecCiudad_module_default()).botonLlamar,
                        children: "LLAMA GRATIS"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ComponenteSelectCiudades_SelectCiudad = (SelectCiudad);

;// CONCATENATED MODULE: ./src/componentes/Compro-oro/Section_2/Section_dos.js




const Section_dos_Section_tres = ({ ciudad , listadoUrlCiudad  })=>{
    const [urlSelect, setUrlSelect] = (0,external_react_.useState)("");
    const listadoCiudades = listadoUrlCiudad?.arrayMarker;
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (sectionTres_module_default()).contenedorSectionTres,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (sectionTres_module_default()).contenedorSectionTresMargen,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionTres_module_default()).bloqueIzq,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                            children: [
                                "Vender oro en ",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (sectionTres_module_default()).linea,
                                    children: "quickgold"
                                }),
                                " es f\xe1cil"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            children: [
                                "El proceso de venta es muy sencillo y c\xf3modo. Primeramente, realizamos la tasaci\xf3n por parte de nuestro equipo de profesionales que te informar\xe1n en todo momento de los pasos que van efectuando. Adem\xe1s, \xe9sta se realiza siempre a la vista para que puedas comprobar por ti mismo los datos aportados por nuestras compa\xf1eras.",
                                " "
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Puedes traernos cualquier pieza de oro, no importa si est\xe1 deteriorada o desparejada. Una vez que hayamos comprobado la pureza de la misma calculamos su valor basado en la cotizaci\xf3n del momento, y te abonamos el importe en efectivo o por transferencia."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "En quickgold llevamos al frente m\xe1s de 15 a\xf1os ofreciendo nuestro servicio de compro oro, por lo que cuentas con especialistas con una larga trayectoria que te ayudar\xe1n en todo lo que necesites. Como nos encanta recibir tu satisfacci\xf3n y confianza nos adaptamos a tus circunstancias ofreci\xe9ndote siempre el mejor servicio posible."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (sectionTres_module_default()).bloqueIzqInferior,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Ven a cualquier tienda quickgold sin necesidad de cita previa, estaremos encantados de atenderte y ayudarte en la venta de tus joyas de oro."
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ComponenteSelectCiudades_SelectCiudad, {
                    listadoCiudades: listadoCiudades,
                    urlSelect: urlSelect,
                    setUrlSelect: setUrlSelect,
                    ciudad: ciudad
                })
            ]
        })
    });
};
/* harmony default export */ const Section_2_Section_dos = (Section_dos_Section_tres);

// EXTERNAL MODULE: ./src/componentes/Compro-oro/Section_5/sectionCinco.module.css
var sectionCinco_module = __webpack_require__(1470);
var sectionCinco_module_default = /*#__PURE__*/__webpack_require__.n(sectionCinco_module);
;// CONCATENATED MODULE: ./src/componentes/Compro-oro/Section_5/Section_cinco.js



const Section_cinco = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionCinco_module_default()).contenedorSectionCinco,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (sectionCinco_module_default()).contenedorSectionCincoMargen,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                    children: [
                        "C\xf3mo vender oro en ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (sectionCinco_module_default()).linea,
                            children: "quickgold"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCinco_module_default()).sectionCincoContenido,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCinco_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Comprobaci\xf3n inicial"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "La comprobaci\xf3n del oro sigue un procedimiento riguroso y claro, independientemente de que se trate de nuestro servicio de compraventa o empe\xf1o. Nuestras compa\xf1eras, por seguridad, realizar\xe1n una comprobaci\xf3n previa para ver el estado y procedencia de \xe9stas. No importa si est\xe1n rotas o desparejadas, utilizaremos un im\xe1n y una comprobaci\xf3n visual con lupa de los contrastes de la pieza para determinar si es oro."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCinco_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Tasaci\xf3n profesional a la vista"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Una vez realizada la comprobaci\xf3n previa. Comenzamos con el proceso de tasaci\xf3n utilizando herramientas homologadas. Todos los pasos que nuestras compa\xf1eras van efectuando se detallan al cliente, adem\xe1s, cada uno de ellos se realiza a la vista para que resulte un proceso totalmente transparente. Utilizaremos dens\xedmetros para determinar el quilataje de la pieza y \xe1cidos que por norma general no ser\xe1 inferior a 14K."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCinco_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Valoraci\xf3n de las piezas de oro"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Una vez tasadas las joyas de oro se ofrece un importe basado en la cotizaci\xf3n actual del mercado. Si est\xe1s de acuerdo con \xe9ste tan s\xf3lo necesitamos tu DNI u otra identificaci\xf3n en vigor para realizar la compra de las joyas. Recuerda que debes ser mayor de edad y presentar DNI en vigor."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCinco_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Pago inmediato del valor fijado y acordado"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Te entregaremos el importe acordado en el momento para que dispongas de forma inmediata el efectivo de la transacci\xf3n. Te garantizamos, durante todo el proceso de venta, el mejor servicio y atenci\xf3n para tu satisfacci\xf3n. Siempre con la sonrisa que nos provoca realizar el trabajo que nos encanta poder ofrecerte."
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_5_Section_cinco = (Section_cinco);

// EXTERNAL MODULE: ./src/componentes/Compro-oro/Section_6/sectionSeis.module.css
var sectionSeis_module = __webpack_require__(4988);
var sectionSeis_module_default = /*#__PURE__*/__webpack_require__.n(sectionSeis_module);
// EXTERNAL MODULE: ./src/componentes/SelectorCiudadesServicio/SelectorCiudadesServicio.js
var SelectorCiudadesServicio = __webpack_require__(5709);
;// CONCATENATED MODULE: ./src/componentes/Compro-oro/Section_6/Section_seis.js




const Section_seis = ({ listadoCiudadesServicios  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (sectionSeis_module_default()).contenedorSectionSeis,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (sectionSeis_module_default()).contenedorSectionSeisMargen,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionSeis_module_default()).contenedorTexto,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            children: "\xbfQu\xe9 tipo de oro hay en el mercado?"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Existe diferentes tipo de oro seg\xfan sus quilates, caracter\xedsticas, calidad, etc."
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionSeis_module_default()).contenedorTiposOro,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro 24K "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Es m\xe1s conocido por ser el llamado \xaboro de inversi\xf3n\xbb. Tiene un grado de pureza de 99,9% por lo que se le considera oro puro. Lo encontrar\xe1s en lingotes de oro."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro 18K "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "El oro alto tiene una pureza del 75%. Es el m\xe1s usado en joyer\xeda y orfebrer\xeda."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro 14K "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Es conocido como oro bajo ya que tiene una pureza del 60% y est\xe1 compuesto por 14 partes de oro y 10 de otros metales."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro amarillo "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Se trata de oro noble cuyo color no suele cambiar y suele ser de 24K o 18K."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro blanco "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Com\xfanmente es de 18K y contiene un 75% de oro fino y una aleaci\xf3n de paladio o de Liga Italiana (material proveniente de Italia de alta calidad que permite realizar una mejor fundici\xf3n)."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro rosado "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Es una mezcla de oro fijo, cobre y plata."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro rojo "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro mezclado con cobre."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro gris "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Mezcla de oro y n\xedquel que se presenta en bajas denominaciones de quilates."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSeis_module_default()).contenedorTiposOroCard1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro verde "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Oro mezclado con plata."
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Section_6_Section_seis = (Section_seis);

;// CONCATENATED MODULE: ./src/pages/compro-oro/index.js












const schema = {
    "@context": "http://www.schema.org",
    "@type": "Organization",
    name: "Quickgold",
    url: "https://quickgold.es/compro-oro/",
    sameAs: [
        "https://instagram.com/quickgold.es",
        "https://twitter.com/quickgoldqg",
        "https://www.facebook.com/quickgold.es"
    ],
    logo: "/assets/img/logo.jpg",
    image: "/assets/img/logo.jpg",
    description: "Quickgold es tu tienda compro oro de confianza. Obt\xe9n dinero extra por las joyas de oro que ya no quieras. Tasaci\xf3n transparente y segura.",
    address: {
        "@type": "PostalAddress",
        addressCountry: "Espa\xf1a"
    },
    contactPoint: {
        "@type": "ContactPoint",
        telephone: "+34 900 373 629",
        contactType: "info@quickgold.es"
    }
};
function ComproOro({ menu_list , listadoUrlCiudad , listadoCiudadesServicios , ciudad  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((next_seo_default()), {
                title: ciudad?.acf?.titulo_del_meta,
                description: ciudad?.acf?.descripcion_del_meta,
                icon: "/favicon.png",
                facebook: {
                    image: "/facebook.png",
                    url: "https://www.facebook.com/quickgold.es/",
                    type: "article"
                },
                twitter: {
                    image: "/twitter.png",
                    site: "@quickgoldQG",
                    card: "summary_large_image"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify(schema)
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
                menu_list: menu_list,
                ciudad: ciudad,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Home_module_default()).main,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs/* default */.Z, {
                            raiz: "Quickgold",
                            iconoRaiz: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {}),
                            urlUbicacionActual: "https://quickgold.es/compro-oro/",
                            iconoUbiccionActual: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {}),
                            ubicacionActual: "Compro Oro"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_1_Section_uno, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_2_Section_dos, {
                        ciudad: ciudad,
                        listadoUrlCiudad: listadoUrlCiudad
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_tres, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_5_Section_cinco, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_6_Section_seis, {
                        listadoCiudadesServicios: listadoCiudadesServicios,
                        ciudad: ciudad
                    })
                ]
            })
        ]
    });
}
const idPaginaWp = "326";
async function getStaticProps() {
    /*const response = await fetch(
    `https://quickgold.es/wp-json/wp/v2/pages/${idWp}`
  );
  const dataIdWp = await response.json();*/ const Listado = await fetch(`https://panel.quickgold.es/ListadoDeUrlDeCiudad/listadoUrlCiudad.json`);
    const listadoUrlCiudad = await Listado.json();
    const listadoServicio = await fetch(`https://panel.quickgold.es/ListadoCiudadesServicio/listadoCiudadesServicioOro.json`);
    const listadoCiudadesServicios = await listadoServicio.json();
    const menu = await fetch(`https://panel.quickgold.es/wp-json/menus/v1/menus/2219`);
    const menu_list = await menu.json();
    const ciudad1 = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${idPaginaWp}`);
    const ciudad = await ciudad1.json();
    // Pass data to the page via props
    return {
        props: {
            menu_list,
            listadoUrlCiudad,
            listadoCiudadesServicios,
            ciudad
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

if (false) { var height1, width1; }
const useScreenSize = ()=>{
    const [width, setWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(width1);
    const [height, setHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(height1);
    if (false) {}
    return {
        width,
        height
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScreenSize);


/***/ }),

/***/ 4579:
/***/ ((module) => {

"use strict";
module.exports = require("@bradgarropy/next-seo");

/***/ }),

/***/ 6741:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CheckCircle");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 7666:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 547:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowRight");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 2906:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 5631:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4180:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/SwipeableDrawer");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 5337:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll-to-top");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,5675,3573,676,1664,7699,5799,5709], () => (__webpack_exec__(145)));
module.exports = __webpack_exports__;

})();