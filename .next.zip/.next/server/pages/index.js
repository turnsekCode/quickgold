(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 349:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorBreadcrumbs": "breadcrumbs_contenedorBreadcrumbs__SE9H6",
	"sectionBreadcrumbs": "breadcrumbs_sectionBreadcrumbs__Dem_8"
};


/***/ }),

/***/ 212:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorMapa": "mapa_contenedorMapa__dLdL6",
	"bloqueDer": "mapa_bloqueDer__GHHSM",
	"bloqueIzq": "mapa_bloqueIzq__Jf7Mg",
	"linea": "mapa_linea__GsdUv"
};


/***/ }),

/***/ 501:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__TYdi_",
	"bloqueIzq": "section_uno_bloqueIzq__PPsV_",
	"linea": "section_uno_linea__sE_iP",
	"botones": "section_uno_botones__62UCW"
};


/***/ }),

/***/ 586:
/***/ ((module) => {

// Exports
module.exports = {
	"contendorSectionDos": "section_2_contendorSectionDos__bgAdu"
};


/***/ }),

/***/ 945:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorContenidoUno": "sectionTres_contenedorContenidoUno__RIl07",
	"contenedorSectionTres": "sectionTres_contenedorSectionTres__LrKPH",
	"bloqueIzq": "sectionTres_bloqueIzq__qlNuI",
	"linea": "sectionTres_linea__x2snh",
	"bloqueDer": "sectionTres_bloqueDer__L7ztu",
	"contenedorInfoTres": "sectionTres_contenedorInfoTres__KEi43",
	"cards": "sectionTres_cards__HdeRf"
};


/***/ }),

/***/ 406:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCuatro": "sectionCuatro_contenedorSectionCuatro__p3g_S",
	"bloqueIzq": "sectionCuatro_bloqueIzq__dY_2o",
	"linea": "sectionCuatro_linea__3PQG0"
};


/***/ }),

/***/ 874:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Home_main__EtNt2"
};


/***/ }),

/***/ 697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(874);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./src/componentes/Breadcrumbs/breadcrumbs.module.css
var breadcrumbs_module = __webpack_require__(349);
var breadcrumbs_module_default = /*#__PURE__*/__webpack_require__.n(breadcrumbs_module);
;// CONCATENATED MODULE: external "@mui/icons-material/KeyboardArrowRight"
const KeyboardArrowRight_namespaceObject = require("@mui/icons-material/KeyboardArrowRight");
var KeyboardArrowRight_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowRight_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/Breadcrumbs/Breadcrumbs.js




const Breadcrumbs = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (breadcrumbs_module_default()).sectionBreadcrumbs,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (breadcrumbs_module_default()).contenedorBreadcrumbs,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "/",
                        title: "Ir a Quickgold",
                        children: "Home"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "/",
                title: "Ir a casa cambio madrid",
                children: "Casa Cambio Madrid"
            })
        ]
    });
};
/* harmony default export */ const Breadcrumbs_Breadcrumbs = (Breadcrumbs);

// EXTERNAL MODULE: ./src/componentes/Section_1/section_uno.module.css
var section_uno_module = __webpack_require__(501);
var section_uno_module_default = /*#__PURE__*/__webpack_require__.n(section_uno_module);
;// CONCATENATED MODULE: external "@mui/icons-material/LocationOnOutlined"
const LocationOnOutlined_namespaceObject = require("@mui/icons-material/LocationOnOutlined");
var LocationOnOutlined_default = /*#__PURE__*/__webpack_require__.n(LocationOnOutlined_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/Section_1/Section_uno.js


//import Image from "next/image";


const Section_uno = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_uno_module_default()).contenedorSectionUno,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_uno_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        children: [
                            "Casas de cambio en ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (section_uno_module_default()).linea,
                                children: "Madrid"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "En nuestra casas de cambio en Barcelona puedes cambiar m\xe1s de 30 monedas extranjeras al momento y sin comisiones. \xbfNecesitas cambiar d\xf3lares por euros o cualquier otra moneda extranjera? Ven a Quickgold."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_uno_module_default()).botones,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((LocationOnOutlined_default()), {}),
                                    "encuentra tu tienda"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "tel:900 373 629",
                                children: "llamar a 900 373 629"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_uno_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/madrid.png",
                    alt: "Quickgold Madrid",
                    className: (section_uno_module_default()).vector,
                    width: 480,
                    height: 364,
                    priority: true
                })
            })
        ]
    });
};
/* harmony default export */ const Section_1_Section_uno = (Section_uno);

// EXTERNAL MODULE: ./src/componentes/Section_2/section_2.module.css
var section_2_module = __webpack_require__(586);
var section_2_module_default = /*#__PURE__*/__webpack_require__.n(section_2_module);
;// CONCATENATED MODULE: ./src/componentes/Section_2/SectionDos.js



const SectionDos = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_2_module_default()).contendorSectionDos,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_2_module_default()).bloqueIzq,
                children: "bloque izq"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_2_module_default()).bloqueDer,
                children: "bloque der"
            })
        ]
    });
};
/* harmony default export */ const Section_2_SectionDos = (SectionDos);

// EXTERNAL MODULE: ./src/componentes/Section_3/sectionTres.module.css
var sectionTres_module = __webpack_require__(945);
var sectionTres_module_default = /*#__PURE__*/__webpack_require__.n(sectionTres_module);
;// CONCATENATED MODULE: ./src/componentes/Section_3/SectionTres.js



const SectionTres = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionTres_module_default()).contenedorSectionTres,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionTres_module_default()).contenedorContenidoUno,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).bloqueIzq,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    "\xbfNecesitas una oficina de cambio en",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (sectionTres_module_default()).linea,
                                        children: "Madrid?"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "En Quickgold tenemos actualmente 3 casas de cambio en la ciudad condal para que puedas cambiar moneda extrajera f\xe1cil y r\xe1pido."
                                    }),
                                    "Tenemos m\xe1s de 30 divisas disponibles para ofrecerte el mejor servicio."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).bloqueDer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "\xbfC\xf3mo cambiar divisa?"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Acude a tu casa de cambio quickgold m\xe1s cercana, ind\xedcanos la moneda extranjera que quieres cambiar y recibe el dinero en efectivo al instante."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                children: [
                    "Cambiar divisa en ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: (sectionTres_module_default()).linea,
                        children: "Madrid"
                    }),
                    " es muy f\xe1cil"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionTres_module_default()).contenedorInfoTres,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Ind\xedcanos la divisa que quieres cambiar"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Acordamos precio. \xa1Hacemos mejoras por cantidad!"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Recibe el dinero en efectivo al instante"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_3_SectionTres = (SectionTres);

// EXTERNAL MODULE: ./src/componentes/Section_4/sectionCuatro.module.css
var sectionCuatro_module = __webpack_require__(406);
var sectionCuatro_module_default = /*#__PURE__*/__webpack_require__.n(sectionCuatro_module);
;// CONCATENATED MODULE: ./src/componentes/Section_4/SectionCuatro.js




const SectionCuatro = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionCuatro_module_default()).contenedorSectionCuatro,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCuatro_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        children: [
                            "Cambia moneda extranjera en",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (sectionCuatro_module_default()).linea,
                                children: "Madrid"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "En las oficinas de cambio de divisa quickgold en Barcelona puedes cambiar d\xf3lares a euros en tan solo unos minutos.. Recuerda llevar el dinero que necesitas cambiar y, al instante, recibir\xe1s la moneda extranjera que necesites en efectivo. Adem\xe1s, ofrecemos mejoras en la tasa de cambio por cantidad, por lo tanto siempre estamos dispuesto a escuchar tus necesidades para ofrecerte el mejor tipo de cambio de la ciudad de Barcelona. Olv\xeddate de cambiar divisa en el aeropuerto o en el banco,. en quickgold ofrecemos las mejores condiciones y ponemos a tu disposici\xf3n diferentes casas de cambio para estar siempre cerca de ti."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (sectionCuatro_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/casa-cambio-madrid.png",
                    alt: "Quickgold Madrid",
                    className: (sectionCuatro_module_default()).Image,
                    width: 480,
                    height: 390,
                    priority: true
                })
            })
        ]
    });
};
/* harmony default export */ const Section_4_SectionCuatro = (SectionCuatro);

// EXTERNAL MODULE: ./src/componentes/Mapa/mapa.module.css
var mapa_module = __webpack_require__(212);
var mapa_module_default = /*#__PURE__*/__webpack_require__.n(mapa_module);
;// CONCATENATED MODULE: ./src/componentes/Mapa/Mapa.js



const Mapa = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (mapa_module_default()).contenedorMapa,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (mapa_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        children: [
                            "Casas de cambio en ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (mapa_module_default()).linea,
                                children: "Madrid"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "Tiendas Quickgold: ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "6"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (mapa_module_default()).bloqueDer
            })
        ]
    });
};
/* harmony default export */ const Mapa_Mapa = (Mapa);

;// CONCATENATED MODULE: ./src/pages/index.js











function Home({ dataIdWp  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Create Next App"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Home_module_default()).main,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_Breadcrumbs, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_1_Section_uno, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_2_SectionDos, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_3_SectionTres, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_4_SectionCuatro, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Mapa_Mapa, {})
                ]
            })
        ]
    });
}
const idWp = "13848";
async function getStaticProps() {
    const response = await fetch(`https://quickgold.es/wp-json/wp/v2/pages/${idWp}`);
    const dataIdWp = await response.json();
    // Pass data to the page via props
    return {
        props: {
            dataIdWp
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,675], () => (__webpack_exec__(697)));
module.exports = __webpack_exports__;

})();