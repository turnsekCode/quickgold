(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 9564:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorTiendas": "bloqueTiendas_contenedorTiendas___fDih",
	"tienda": "bloqueTiendas_tienda__UdgVj"
};


/***/ }),

/***/ 349:
/***/ ((module) => {

// Exports
module.exports = {
	"sectionBreadcrumbs": "breadcrumbs_sectionBreadcrumbs__Dem_8",
	"contenedorBreadcrumbs": "breadcrumbs_contenedorBreadcrumbs__SE9H6"
};


/***/ }),

/***/ 3460:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueDivHabituales": "estilosConversor_bloqueDivHabituales__HxMaH",
	"bloqueTituloSuperior": "estilosConversor_bloqueTituloSuperior__5Zm4u",
	"tituloDivisaHabitual": "estilosConversor_tituloDivisaHabitual__BF_Hz",
	"divisasHabituales": "estilosConversor_divisasHabituales__i8QdB",
	"bloqueDer": "estilosConversor_bloqueDer__1vasI",
	"dolar": "estilosConversor_dolar__LDMdD",
	"libra": "estilosConversor_libra__XdRPp",
	"imgMoneda": "estilosConversor_imgMoneda__zP0CD",
	"nombreMoneda": "estilosConversor_nombreMoneda__G5sy2",
	"contenedorInputSuperior": "estilosConversor_contenedorInputSuperior__rUPKa",
	"contenedorInputInferior": "estilosConversor_contenedorInputInferior__bb84y",
	"bloqueIzqInput": "estilosConversor_bloqueIzqInput__InxHR",
	"select": "estilosConversor_select__qtRpq",
	"bloqueDerInput": "estilosConversor_bloqueDerInput__QVcSI",
	"botonSwith": "estilosConversor_botonSwith__KjdlS",
	"monedaInferior": "estilosConversor_monedaInferior__PKm3n",
	"botonLlamarTienda": "estilosConversor_botonLlamarTienda__OYSNc"
};


/***/ }),

/***/ 3212:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorMapa": "mapa_contenedorMapa__dLdL6",
	"bloqueDer": "mapa_bloqueDer__GHHSM",
	"bloqueIzq": "mapa_bloqueIzq__Jf7Mg",
	"linea": "mapa_linea__GsdUv",
	"reset_map": "mapa_reset_map__ZRTtV"
};


/***/ }),

/***/ 8501:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__TYdi_",
	"linea": "section_uno_linea__sE_iP",
	"bloqueIzq": "section_uno_bloqueIzq__PPsV_",
	"bloqueDer": "section_uno_bloqueDer__tgJlu",
	"madridMobil": "section_uno_madridMobil__6tO4y",
	"botones": "section_uno_botones__62UCW"
};


/***/ }),

/***/ 9586:
/***/ ((module) => {

// Exports
module.exports = {
	"contendorSectionDos": "section_2_contendorSectionDos__bgAdu",
	"contendorBloques": "section_2_contendorBloques__t6Qdu",
	"bloqueIzq": "section_2_bloqueIzq__r_rOI",
	"bloqueDer": "section_2_bloqueDer__fC_NZ",
	"contenedorInfo": "section_2_contenedorInfo__adMl_",
	"contenedorBotones": "section_2_contenedorBotones__DtrVd",
	"botonComprar": "section_2_botonComprar__vC7_i",
	"botonVender": "section_2_botonVender__grQc1",
	"botonActivo": "section_2_botonActivo__iHabU"
};


/***/ }),

/***/ 6945:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorContenidoUno": "sectionTres_contenedorContenidoUno__RIl07",
	"contenedorSectionTres": "sectionTres_contenedorSectionTres__LrKPH",
	"linea": "sectionTres_linea__x2snh",
	"bloqueDer": "sectionTres_bloqueDer__L7ztu",
	"bloqueIzq": "sectionTres_bloqueIzq__qlNuI",
	"contenedorInfoTres": "sectionTres_contenedorInfoTres__KEi43",
	"cards": "sectionTres_cards__HdeRf"
};


/***/ }),

/***/ 1406:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCuatro": "sectionCuatro_contenedorSectionCuatro__p3g_S",
	"bloqueIzq": "sectionCuatro_bloqueIzq__dY_2o",
	"bloqueDer": "sectionCuatro_bloqueDer___Kb4N",
	"linea": "sectionCuatro_linea__3PQG0"
};


/***/ }),

/***/ 8874:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Home_main__EtNt2"
};


/***/ }),

/***/ 4493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _bloqueTiendas_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9564);
/* harmony import */ var _bloqueTiendas_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_bloqueTiendas_module_css__WEBPACK_IMPORTED_MODULE_2__);



const BloqueTiendas = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_bloqueTiendas_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedorTiendas),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_bloqueTiendas_module_css__WEBPACK_IMPORTED_MODULE_2___default().tienda),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        children: "Quickgold Delicias"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Direcci\xf3n: aqui direccion"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        title: "texto",
                        href: "tel:931 434 276",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Telefono: 931 434 276"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "/",
                        children: "C\xf3mo llegar"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_bloqueTiendas_module_css__WEBPACK_IMPORTED_MODULE_2___default().tienda),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        children: "Quickgold Tirso de molino"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Direcci\xf3n: aqui direccion"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        title: "texto",
                        href: "tel:931 434 276",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Telefono: 931 434 276"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        title: "texto",
                        href: "/",
                        children: "C\xf3mo llegar"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BloqueTiendas);


/***/ }),

/***/ 1886:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Mapa_Mapa)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/BloqueTiendas/BloqueTiendas.js
var BloqueTiendas = __webpack_require__(4493);
// EXTERNAL MODULE: ./src/componentes/Mapa/mapa.module.css
var mapa_module = __webpack_require__(3212);
var mapa_module_default = /*#__PURE__*/__webpack_require__.n(mapa_module);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
;// CONCATENATED MODULE: external "react-map-gl"
const external_react_map_gl_namespaceObject = require("react-map-gl");
var external_react_map_gl_default = /*#__PURE__*/__webpack_require__.n(external_react_map_gl_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/Mapa/Mapa.js





//import "mapbox-gl/dist/mapbox-gl.css";

const DynamicBloqueTiendas = dynamic_default()(()=>Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 4493)), {
    loadableGenerated: {
        modules: [
            "..\\componentes\\Mapa\\Mapa.js -> " + "../BloqueTiendas/BloqueTiendas"
        ]
    }
});
const Mapa = ({ markers  })=>{
    const marcador = markers.arrayMarker;
    const [viewState, setViewState] = (0,external_react_.useState)({
        longitude: -3.6883264,
        latitude: 40.4535878,
        zoom: 11,
        cooperativeGestures: true
    });
    const mapRef = (0,external_react_.useRef)();
    const resetMap = ()=>{
        setShowPopup(false);
        mapRef.current?.flyTo({
            center: [
                -3.6883264,
                40.4535878
            ],
            duration: 2000,
            zoom: 11
        });
    };
    const [showPopup, setShowPopup] = (0,external_react_.useState)(null);
    const toggleTab = ()=>{
        setShowPopup(true);
    };
    const [showInfo, setShowInfo] = (0,external_react_.useState)({
        longitude: "",
        latitude: "",
        tienda: "",
        telefono: "",
        direccion: "",
        comoLlegar: "",
        nombreTienda: "",
        duration: "",
        zoom: ""
    });
    const onSelectMarker = (marker)=>{
        setShowInfo({
            longitude: marker.longitude,
            latitude: marker.latitude,
            tienda: marker.tienda,
            telefono: marker.telefono,
            direccion: marker.direccion,
            comoLlegar: marker.comoLlegar,
            nombreTienda: marker.nombreTienda,
            duration: marker.duration,
            zoom: marker.zoom
        });
        mapRef.current?.flyTo({
            center: {
                lng: marker.longitude,
                lat: marker.latitude
            },
            duration: 1500,
            zoom: 11
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        id: "contenedorMapa",
        className: (mapa_module_default()).contenedorMapa,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (mapa_module_default()).contenedorbloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (mapa_module_default()).bloqueIzq,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    "Casas de cambio en ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).linea,
                                        children: "Madrid"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "Tiendas Quickgold: ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "6"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(DynamicBloqueTiendas, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (mapa_module_default()).bloqueDer,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_map_gl_default()), {
                    onStyleLoad: true,
                    ref: mapRef,
                    ...viewState,
                    onMove: (evt)=>setViewState(evt.viewState),
                    className: "mapa",
                    mapStyle: "mapbox://styles/mapbox/streets-v9?optimize=true",
                    mapboxAccessToken: "pk.eyJ1IjoicXVpY2tnb2wiLCJhIjoiY2xhbGNvcHAyMDRyNjNwbWthcm1zMm9nbyJ9.tmZYhqn4Z6U3fcCZH647Zw",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.FullscreenControl, {}),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.GeolocateControl, {}),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.NavigationControl, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (mapa_module_default()).reset_map,
                            onClick: ()=>{
                                resetMap();
                            },
                            children: "Reset Map"
                        }),
                        marcador.map((marker)=>/*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.Marker, {
                                longitude: marker.longitude,
                                latitude: marker.latitude,
                                onClick: ()=>{
                                    onSelectMarker(marker);
                                    toggleTab();
                                },
                                children: showPopup ? /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.Popup, {
                                    style: {
                                        top: -25
                                    },
                                    longitude: showInfo.longitude,
                                    className: "popup",
                                    latitude: showInfo.latitude,
                                    closeOnClick: false,
                                    anchor: null,
                                    onClose: ()=>setShowPopup(false),
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "contenedor_popuop",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "nombre_ciudad_popup",
                                                children: showInfo.nombreTienda
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "nombre_ciudad_popup",
                                                children: "Contacto:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "texto",
                                                href: showInfo.comoLlegar,
                                                rel: "noreferrer",
                                                target: "_blank",
                                                className: "direccion_popup",
                                                children: showInfo.direccion
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "texto",
                                                href: showInfo.comoLlegar,
                                                rel: "noreferrer",
                                                ƒ: true,
                                                className: "boton_como_llegar",
                                                children: "C\xf3mo llegar"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: `tel:${showInfo.telefono}`,
                                                className: "telefono_popup",
                                                title: "texto",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "Llamar: "
                                                    }),
                                                    showInfo.telefono
                                                ]
                                            })
                                        ]
                                    })
                                }) : null
                            }, marker.id))
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Mapa_Mapa = (Mapa);


/***/ }),

/***/ 5559:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(8874);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/Breadcrumbs/breadcrumbs.module.css
var breadcrumbs_module = __webpack_require__(349);
var breadcrumbs_module_default = /*#__PURE__*/__webpack_require__.n(breadcrumbs_module);
;// CONCATENATED MODULE: external "@mui/icons-material/KeyboardArrowRight"
const KeyboardArrowRight_namespaceObject = require("@mui/icons-material/KeyboardArrowRight");
var KeyboardArrowRight_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowRight_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/Breadcrumbs/Breadcrumbs.js




const Breadcrumbs = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (breadcrumbs_module_default()).sectionBreadcrumbs,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (breadcrumbs_module_default()).contenedorBreadcrumbs,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "/",
                        title: "Ir a Quickgold",
                        children: "Home"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "/",
                title: "Ir a casa cambio madrid",
                children: "Casa Cambio Madrid"
            })
        ]
    });
};
/* harmony default export */ const Breadcrumbs_Breadcrumbs = (Breadcrumbs);

// EXTERNAL MODULE: ./src/componentes/Section_1/section_uno.module.css
var section_uno_module = __webpack_require__(8501);
var section_uno_module_default = /*#__PURE__*/__webpack_require__.n(section_uno_module);
;// CONCATENATED MODULE: external "@mui/icons-material/LocationOnOutlined"
const LocationOnOutlined_namespaceObject = require("@mui/icons-material/LocationOnOutlined");
var LocationOnOutlined_default = /*#__PURE__*/__webpack_require__.n(LocationOnOutlined_namespaceObject);
;// CONCATENATED MODULE: external "react-scroll"
const external_react_scroll_namespaceObject = require("react-scroll");
// EXTERNAL MODULE: ./src/utilities/useScreenSize.js
var useScreenSize = __webpack_require__(771);
;// CONCATENATED MODULE: ./src/componentes/Section_1/Section_uno.js


//import Image from "next/image";




const Section_uno = ()=>{
    const { width  } = (0,useScreenSize/* default */.Z)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_uno_module_default()).contenedorSectionUno,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_uno_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        children: [
                            "Casas de cambio en ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (section_uno_module_default()).linea,
                                children: "Madrid"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "En nuestra casas de cambio en Madrid puedes cambiar m\xe1s de 30 monedas extranjeras al momento y sin comisiones. \xbfNecesitas cambiar d\xf3lares por euros o cualquier otra moneda extranjera? Ven a Quickgold."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_uno_module_default()).botones,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_scroll_namespaceObject.Link, {
                                to: "contenedorMapa",
                                smooth: true,
                                offset: -110,
                                spy: true,
                                duration: 500,
                                title: "texto",
                                passive: "true",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((LocationOnOutlined_default()), {}),
                                    "encuentra tu tienda"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "tel:900 373 629",
                                title: "texto",
                                children: "llamar a 900 373 629"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_uno_module_default()).bloqueDer,
                children: width <= 610 ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/madrid_mobil.webp",
                    alt: "Quickgold Madrid",
                    className: (section_uno_module_default()).madridMobil,
                    width: 290,
                    height: 220
                }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/madrid.webp",
                    alt: "Quickgold Madrid",
                    className: (section_uno_module_default()).vector,
                    width: 480,
                    height: 364
                })
            })
        ]
    });
};
/* harmony default export */ const Section_1_Section_uno = (Section_uno);

// EXTERNAL MODULE: ./src/componentes/ConversorDivisa/estilosConversor.module.css
var estilosConversor_module = __webpack_require__(3460);
var estilosConversor_module_default = /*#__PURE__*/__webpack_require__.n(estilosConversor_module);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowDown"
var KeyboardArrowDown_ = __webpack_require__(4845);
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_);
;// CONCATENATED MODULE: external "@mui/icons-material/PowerInput"
const PowerInput_namespaceObject = require("@mui/icons-material/PowerInput");
var PowerInput_default = /*#__PURE__*/__webpack_require__.n(PowerInput_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/ImportExport"
const ImportExport_namespaceObject = require("@mui/icons-material/ImportExport");
var ImportExport_default = /*#__PURE__*/__webpack_require__.n(ImportExport_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/ConversorDivisa/Comprar.js






const Comprar = ()=>{
    const [data, setData] = (0,external_react_.useState)([]);
    const [loading, setLoading] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        fetch("https://quickgold.es/archivos-cache/Fixingalicante.txt").then((response)=>response.json()).then((santantoni)=>{
            setData(santantoni);
            setLoading(true);
        });
    }, []);
    console.log(data.result?.Tarifas?.Divisas_Compra[28].Productos[0].Precio);
    console.log(loading);
    const precioDolar = data.result?.Tarifas?.Divisas_Compra[28].Productos[0].Precio;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (estilosConversor_module_default()).bloqueDer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).bloqueDivHabituales,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueTituloSuperior,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h6", {
                                children: [
                                    "Conversor ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Compra"
                                    }),
                                    " de divisa"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (estilosConversor_module_default()).tituloDivisaHabitual,
                                children: "Divisas m\xe1s habituales"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).divisasHabituales,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).dolar,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).imgMoneda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/banderaUSA.png"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "USD"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).nombreMoneda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "D\xf3lar USA"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: loading ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: precioDolar
                                                }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "loading..."
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (estilosConversor_module_default()).libra,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).imgMoneda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/banderaGBP.png"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "GBP"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (estilosConversor_module_default()).nombreMoneda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Libra Esterlina"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "1.0163"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).contenedorInputSuperior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).bloqueIzqInput,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (estilosConversor_module_default()).select,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((PowerInput_default()), {}),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueDerInput,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "text",
                                pattern: "[0-9]*",
                                placeholder: "Cantidad",
                                inputMode: "numeric"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "1$ = 1.03€"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (estilosConversor_module_default()).botonSwith,
                children: /*#__PURE__*/ jsx_runtime_.jsx((ImportExport_default()), {})
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (estilosConversor_module_default()).contenedorInputInferior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (estilosConversor_module_default()).monedaInferior,
                        children: "EUR"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (estilosConversor_module_default()).bloqueDerInput,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "text",
                                pattern: "[0-9]*",
                                placeholder: "Cantidad",
                                inputMode: "numeric"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "1€ = 1.03$"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                className: (estilosConversor_module_default()).botonLlamarTienda,
                href: "tel:",
                children: "LLAMAR A TIENDA"
            })
        ]
    });
};
/* harmony default export */ const ConversorDivisa_Comprar = (Comprar);

// EXTERNAL MODULE: ./src/componentes/Section_2/section_2.module.css
var section_2_module = __webpack_require__(9586);
var section_2_module_default = /*#__PURE__*/__webpack_require__.n(section_2_module);
;// CONCATENATED MODULE: ./src/componentes/Section_2/SectionDos.js




const SectionDos = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (section_2_module_default()).contendorSectionDos,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (section_2_module_default()).contendorBloques,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (section_2_module_default()).bloqueIzq,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/imagen_calc.png"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (section_2_module_default()).contenedorInfo,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    children: "Cambio de Divisas"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Descubre el valor de la moneda que te interesa."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (section_2_module_default()).contenedorBotones,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: `${(section_2_module_default()).botonComprar} ${(section_2_module_default()).botonActivo}`,
                                    children: "COMPRAR DIVISA"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (section_2_module_default()).botonVender,
                                    children: "VENDER DIVISA"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ConversorDivisa_Comprar, {})
            ]
        })
    });
};
/* harmony default export */ const Section_2_SectionDos = (SectionDos);

// EXTERNAL MODULE: ./src/componentes/Section_3/sectionTres.module.css
var sectionTres_module = __webpack_require__(6945);
var sectionTres_module_default = /*#__PURE__*/__webpack_require__.n(sectionTres_module);
;// CONCATENATED MODULE: ./src/componentes/Section_3/SectionTres.js



const SectionTres = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionTres_module_default()).contenedorSectionTres,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionTres_module_default()).contenedorContenidoUno,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).bloqueIzq,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    "\xbfNecesitas una oficina de cambio en",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (sectionTres_module_default()).linea,
                                        children: "Madrid?"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "En Quickgold tenemos actualmente 3 casas de cambio en la ciudad condal para que puedas cambiar moneda extrajera f\xe1cil y r\xe1pido."
                                    }),
                                    "Tenemos m\xe1s de 30 divisas disponibles para ofrecerte el mejor servicio."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).bloqueDer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "\xbfC\xf3mo cambiar divisa?"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Acude a tu casa de cambio quickgold m\xe1s cercana, ind\xedcanos la moneda extranjera que quieres cambiar y recibe el dinero en efectivo al instante."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                children: [
                    "Cambiar divisa en ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: (sectionTres_module_default()).linea,
                        children: "Madrid"
                    }),
                    " es muy f\xe1cil"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionTres_module_default()).contenedorInfoTres,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Ind\xedcanos la divisa que quieres cambiar"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Acordamos precio. \xa1Hacemos mejoras por cantidad!"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Recibe el dinero en efectivo al instante"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_3_SectionTres = (SectionTres);

// EXTERNAL MODULE: ./src/componentes/Section_4/sectionCuatro.module.css
var sectionCuatro_module = __webpack_require__(1406);
var sectionCuatro_module_default = /*#__PURE__*/__webpack_require__.n(sectionCuatro_module);
;// CONCATENATED MODULE: ./src/componentes/Section_4/SectionCuatro.js


//import Image from "next/image";

const SectionCuatro = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionCuatro_module_default()).contenedorSectionCuatro,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCuatro_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        children: [
                            "Cambia moneda extranjera en",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (sectionCuatro_module_default()).linea,
                                children: "Madrid"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "En las oficinas de cambio de divisa quickgold en Madrid puedes cambiar d\xf3lares a euros en tan solo unos minutos. Recuerda llevar el dinero que necesitas cambiar y, al instante, recibir\xe1s la moneda extranjera que necesites en efectivo. Adem\xe1s, ofrecemos mejoras en la tasa de cambio por cantidad, por lo tanto siempre estamos dispuesto a escuchar tus necesidades para ofrecerte el mejor tipo de cambio de la ciudad de Barcelona. Olv\xeddate de cambiar divisa en el aeropuerto o en el banco, en quickgold ofrecemos las mejores condiciones y ponemos a tu disposici\xf3n diferentes casas de cambio para estar siempre cerca de ti."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (sectionCuatro_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    loading: "lazy",
                    src: "/casa-cambio-madrid.webp",
                    alt: "Quickgold Madrid",
                    className: (sectionCuatro_module_default()).Image,
                    width: 480,
                    height: 390
                })
            })
        ]
    });
};
/* harmony default export */ const Section_4_SectionCuatro = (SectionCuatro);

// EXTERNAL MODULE: ./src/componentes/Mapa/Mapa.js + 1 modules
var Mapa = __webpack_require__(1886);
;// CONCATENATED MODULE: ./src/pages/index.js











const DynamicMapa = dynamic_default()(()=>Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 1886)), {
    loadableGenerated: {
        modules: [
            "index.js -> " + "../componentes/Mapa/Mapa.js"
        ]
    }
});
function Home({ dataIdWp , markers  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Casas de Cambio en Madrid | Cambio de Divisas Madrid"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Casas de cambio en Madrid. Cambia d\xf3lares a euros en nuestras oficinas de cambio quickgold. Cambio de moneda extranjera al momento y sin comisiones. "
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Home_module_default()).main,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_Breadcrumbs, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_1_Section_uno, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_2_SectionDos, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_3_SectionTres, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_4_SectionCuatro, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(DynamicMapa, {
                        markers: markers
                    })
                ]
            })
        ]
    });
}
const idWp = "13848";
async function getStaticProps() {
    const response = await fetch(`https://quickgold.es/wp-json/wp/v2/pages/${idWp}`);
    const dataIdWp = await response.json();
    const marker = await fetch(`https://quickgold.es/markers.json`);
    const markers = await marker.json();
    /*const acf = await fetch(
    `https://quickgold.es/wp-json/acf/v3/pages?per_page=24`
  );
  const acfs = await acf.json();*/ // Pass data to the page via props
    return {
        props: {
            dataIdWp,
            markers
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

if (false) { var height1, width1; }
const useScreenSize = ()=>{
    const [width, setWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(width1);
    const [height, setHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(height1);
    if (false) {}
    return {
        width,
        height
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScreenSize);


/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,486], () => (__webpack_exec__(5559)));
module.exports = __webpack_exports__;

})();