(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 564:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorTiendas": "bloqueTiendas_contenedorTiendas___fDih",
	"tienda": "bloqueTiendas_tienda__UdgVj"
};


/***/ }),

/***/ 349:
/***/ ((module) => {

// Exports
module.exports = {
	"sectionBreadcrumbs": "breadcrumbs_sectionBreadcrumbs__Dem_8",
	"contenedorBreadcrumbs": "breadcrumbs_contenedorBreadcrumbs__SE9H6"
};


/***/ }),

/***/ 212:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorMapa": "mapa_contenedorMapa__dLdL6",
	"bloqueDer": "mapa_bloqueDer__GHHSM",
	"bloqueIzq": "mapa_bloqueIzq__Jf7Mg",
	"linea": "mapa_linea__GsdUv",
	"reset_map": "mapa_reset_map__ZRTtV"
};


/***/ }),

/***/ 501:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__TYdi_",
	"linea": "section_uno_linea__sE_iP",
	"bloqueIzq": "section_uno_bloqueIzq__PPsV_",
	"bloqueDer": "section_uno_bloqueDer__tgJlu",
	"botones": "section_uno_botones__62UCW"
};


/***/ }),

/***/ 586:
/***/ ((module) => {

// Exports
module.exports = {
	"contendorSectionDos": "section_2_contendorSectionDos__bgAdu",
	"contendorBloques": "section_2_contendorBloques__t6Qdu"
};


/***/ }),

/***/ 945:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorContenidoUno": "sectionTres_contenedorContenidoUno__RIl07",
	"contenedorSectionTres": "sectionTres_contenedorSectionTres__LrKPH",
	"linea": "sectionTres_linea__x2snh",
	"bloqueDer": "sectionTres_bloqueDer__L7ztu",
	"bloqueIzq": "sectionTres_bloqueIzq__qlNuI",
	"contenedorInfoTres": "sectionTres_contenedorInfoTres__KEi43",
	"cards": "sectionTres_cards__HdeRf"
};


/***/ }),

/***/ 406:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCuatro": "sectionCuatro_contenedorSectionCuatro__p3g_S",
	"bloqueIzq": "sectionCuatro_bloqueIzq__dY_2o",
	"bloqueDer": "sectionCuatro_bloqueDer___Kb4N",
	"linea": "sectionCuatro_linea__3PQG0"
};


/***/ }),

/***/ 874:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Home_main__EtNt2"
};


/***/ }),

/***/ 489:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(874);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./src/componentes/Breadcrumbs/breadcrumbs.module.css
var breadcrumbs_module = __webpack_require__(349);
var breadcrumbs_module_default = /*#__PURE__*/__webpack_require__.n(breadcrumbs_module);
;// CONCATENATED MODULE: external "@mui/icons-material/KeyboardArrowRight"
const KeyboardArrowRight_namespaceObject = require("@mui/icons-material/KeyboardArrowRight");
var KeyboardArrowRight_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowRight_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/Breadcrumbs/Breadcrumbs.js




const Breadcrumbs = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (breadcrumbs_module_default()).sectionBreadcrumbs,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (breadcrumbs_module_default()).contenedorBreadcrumbs,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "/",
                        title: "Ir a Quickgold",
                        children: "Home"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "/",
                title: "Ir a casa cambio madrid",
                children: "Casa Cambio Madrid"
            })
        ]
    });
};
/* harmony default export */ const Breadcrumbs_Breadcrumbs = (Breadcrumbs);

// EXTERNAL MODULE: ./src/componentes/Section_1/section_uno.module.css
var section_uno_module = __webpack_require__(501);
var section_uno_module_default = /*#__PURE__*/__webpack_require__.n(section_uno_module);
;// CONCATENATED MODULE: external "@mui/icons-material/LocationOnOutlined"
const LocationOnOutlined_namespaceObject = require("@mui/icons-material/LocationOnOutlined");
var LocationOnOutlined_default = /*#__PURE__*/__webpack_require__.n(LocationOnOutlined_namespaceObject);
;// CONCATENATED MODULE: external "react-scroll"
const external_react_scroll_namespaceObject = require("react-scroll");
;// CONCATENATED MODULE: ./src/componentes/Section_1/Section_uno.js


//import Image from "next/image";



const Section_uno = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_uno_module_default()).contenedorSectionUno,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_uno_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        children: [
                            "Casas de cambio en ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (section_uno_module_default()).linea,
                                children: "Madrid"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "En nuestra casas de cambio en Barcelona puedes cambiar m\xe1s de 30 monedas extranjeras al momento y sin comisiones. \xbfNecesitas cambiar d\xf3lares por euros o cualquier otra moneda extranjera? Ven a Quickgold."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_uno_module_default()).botones,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_scroll_namespaceObject.Link, {
                                to: "contenedorMapa",
                                smooth: true,
                                offset: -110,
                                spy: true,
                                duration: 500,
                                title: "texto",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((LocationOnOutlined_default()), {}),
                                    "encuentra tu tienda"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "tel:900 373 629",
                                title: "texto",
                                children: "llamar a 900 373 629"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_uno_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/madrid.webp",
                    alt: "Quickgold Madrid",
                    className: (section_uno_module_default()).vector,
                    width: 480,
                    height: 364
                })
            })
        ]
    });
};
/* harmony default export */ const Section_1_Section_uno = (Section_uno);

// EXTERNAL MODULE: ./src/componentes/Section_2/section_2.module.css
var section_2_module = __webpack_require__(586);
var section_2_module_default = /*#__PURE__*/__webpack_require__.n(section_2_module);
;// CONCATENATED MODULE: ./src/componentes/Section_2/SectionDos.js



const SectionDos = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (section_2_module_default()).contendorSectionDos,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (section_2_module_default()).contendorBloques,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (section_2_module_default()).bloqueIzq,
                    children: "bloque izq"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (section_2_module_default()).bloqueDer,
                    children: "bloque der"
                })
            ]
        })
    });
};
/* harmony default export */ const Section_2_SectionDos = (SectionDos);

// EXTERNAL MODULE: ./src/componentes/Section_3/sectionTres.module.css
var sectionTres_module = __webpack_require__(945);
var sectionTres_module_default = /*#__PURE__*/__webpack_require__.n(sectionTres_module);
;// CONCATENATED MODULE: ./src/componentes/Section_3/SectionTres.js



const SectionTres = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionTres_module_default()).contenedorSectionTres,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionTres_module_default()).contenedorContenidoUno,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).bloqueIzq,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    "\xbfNecesitas una oficina de cambio en",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (sectionTres_module_default()).linea,
                                        children: "Madrid?"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "En Quickgold tenemos actualmente 3 casas de cambio en la ciudad condal para que puedas cambiar moneda extrajera f\xe1cil y r\xe1pido."
                                    }),
                                    "Tenemos m\xe1s de 30 divisas disponibles para ofrecerte el mejor servicio."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).bloqueDer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "\xbfC\xf3mo cambiar divisa?"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Acude a tu casa de cambio quickgold m\xe1s cercana, ind\xedcanos la moneda extranjera que quieres cambiar y recibe el dinero en efectivo al instante."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                children: [
                    "Cambiar divisa en ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: (sectionTres_module_default()).linea,
                        children: "Madrid"
                    }),
                    " es muy f\xe1cil"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionTres_module_default()).contenedorInfoTres,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Ind\xedcanos la divisa que quieres cambiar"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Acordamos precio. \xa1Hacemos mejoras por cantidad!"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionTres_module_default()).cards,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Recibe el dinero en efectivo al instante"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_3_SectionTres = (SectionTres);

// EXTERNAL MODULE: ./src/componentes/Section_4/sectionCuatro.module.css
var sectionCuatro_module = __webpack_require__(406);
var sectionCuatro_module_default = /*#__PURE__*/__webpack_require__.n(sectionCuatro_module);
;// CONCATENATED MODULE: ./src/componentes/Section_4/SectionCuatro.js


//import Image from "next/image";

const SectionCuatro = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionCuatro_module_default()).contenedorSectionCuatro,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCuatro_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        children: [
                            "Cambia moneda extranjera en",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (sectionCuatro_module_default()).linea,
                                children: "Madrid"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "En las oficinas de cambio de divisa quickgold en Madrid puedes cambiar d\xf3lares a euros en tan solo unos minutos. Recuerda llevar el dinero que necesitas cambiar y, al instante, recibir\xe1s la moneda extranjera que necesites en efectivo. Adem\xe1s, ofrecemos mejoras en la tasa de cambio por cantidad, por lo tanto siempre estamos dispuesto a escuchar tus necesidades para ofrecerte el mejor tipo de cambio de la ciudad de Barcelona. Olv\xeddate de cambiar divisa en el aeropuerto o en el banco, en quickgold ofrecemos las mejores condiciones y ponemos a tu disposici\xf3n diferentes casas de cambio para estar siempre cerca de ti."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (sectionCuatro_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    loading: "lazy",
                    src: "/casa-cambio-madrid.webp",
                    alt: "Quickgold Madrid",
                    className: (sectionCuatro_module_default()).Image,
                    width: 480,
                    height: 390
                })
            })
        ]
    });
};
/* harmony default export */ const Section_4_SectionCuatro = (SectionCuatro);

// EXTERNAL MODULE: ./src/componentes/BloqueTiendas/bloqueTiendas.module.css
var bloqueTiendas_module = __webpack_require__(564);
var bloqueTiendas_module_default = /*#__PURE__*/__webpack_require__.n(bloqueTiendas_module);
;// CONCATENATED MODULE: ./src/componentes/BloqueTiendas/BloqueTiendas.js



const BloqueTiendas = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (bloqueTiendas_module_default()).contenedorTiendas,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (bloqueTiendas_module_default()).tienda,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Quickgold Delicias"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Direcci\xf3n: aqui direccion"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        title: "texto",
                        href: "tel:931 434 276",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Telefono: 931 434 276"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "/",
                        children: "C\xf3mo llegar"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (bloqueTiendas_module_default()).tienda,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Quickgold Tirso de molino"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Direcci\xf3n: aqui direccion"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        title: "texto",
                        href: "tel:931 434 276",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Telefono: 931 434 276"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        title: "texto",
                        href: "/",
                        children: "C\xf3mo llegar"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const BloqueTiendas_BloqueTiendas = (BloqueTiendas);

// EXTERNAL MODULE: ./src/componentes/Mapa/mapa.module.css
var mapa_module = __webpack_require__(212);
var mapa_module_default = /*#__PURE__*/__webpack_require__.n(mapa_module);
;// CONCATENATED MODULE: external "react-map-gl"
const external_react_map_gl_namespaceObject = require("react-map-gl");
var external_react_map_gl_default = /*#__PURE__*/__webpack_require__.n(external_react_map_gl_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/Mapa/Mapa.js




//import "mapbox-gl/dist/mapbox-gl.css";

const Mapa = ({ markers , api  })=>{
    const marcador = markers.arrayMarker;
    const [viewState, setViewState] = (0,external_react_.useState)({
        longitude: -3.6883264,
        latitude: 40.4535878,
        zoom: 11,
        cooperativeGestures: true
    });
    const mapRef = (0,external_react_.useRef)();
    const resetMap = ()=>{
        setShowPopup(false);
        mapRef.current?.flyTo({
            center: [
                -3.6883264,
                40.4535878
            ],
            duration: 2000,
            zoom: 11
        });
    };
    const [showPopup, setShowPopup] = (0,external_react_.useState)(null);
    const toggleTab = ()=>{
        setShowPopup(true);
    };
    const [showInfo, setShowInfo] = (0,external_react_.useState)({
        longitude: "",
        latitude: "",
        tienda: "",
        telefono: "",
        direccion: "",
        comoLlegar: "",
        nombreTienda: "",
        duration: "",
        zoom: ""
    });
    const onSelectMarker = (marker)=>{
        setShowInfo({
            longitude: marker.longitude,
            latitude: marker.latitude,
            tienda: marker.tienda,
            telefono: marker.telefono,
            direccion: marker.direccion,
            comoLlegar: marker.comoLlegar,
            nombreTienda: marker.nombreTienda,
            duration: marker.duration,
            zoom: marker.zoom
        });
        mapRef.current?.flyTo({
            center: {
                lng: marker.longitude,
                lat: marker.latitude
            },
            duration: 1500,
            zoom: 11
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        id: "contenedorMapa",
        className: (mapa_module_default()).contenedorMapa,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (mapa_module_default()).contenedorbloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (mapa_module_default()).bloqueIzq,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    "Casas de cambio en ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).linea,
                                        children: "Madrid"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "Tiendas Quickgold: ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "6"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(BloqueTiendas_BloqueTiendas, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (mapa_module_default()).bloqueDer,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_map_gl_default()), {
                    ref: mapRef,
                    ...viewState,
                    onMove: (evt)=>setViewState(evt.viewState),
                    className: "mapa",
                    mapStyle: "mapbox://styles/mapbox/streets-v9",
                    mapboxAccessToken: api,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.FullscreenControl, {}),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.GeolocateControl, {}),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.NavigationControl, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (mapa_module_default()).reset_map,
                            onClick: ()=>{
                                resetMap();
                            },
                            children: "Reset Map"
                        }),
                        marcador.map((marker)=>/*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.Marker, {
                                longitude: marker.longitude,
                                latitude: marker.latitude,
                                onClick: ()=>{
                                    onSelectMarker(marker);
                                    toggleTab();
                                },
                                children: showPopup ? /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_namespaceObject.Popup, {
                                    style: {
                                        top: -25
                                    },
                                    longitude: showInfo.longitude,
                                    className: "popup",
                                    latitude: showInfo.latitude,
                                    closeOnClick: false,
                                    anchor: null,
                                    onClose: ()=>setShowPopup(false),
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "contenedor_popuop",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "nombre_ciudad_popup",
                                                children: showInfo.nombreTienda
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "nombre_ciudad_popup",
                                                children: "Contacto:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "texto",
                                                href: showInfo.comoLlegar,
                                                rel: "noreferrer",
                                                target: "_blank",
                                                className: "direccion_popup",
                                                children: showInfo.direccion
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "texto",
                                                href: showInfo.comoLlegar,
                                                rel: "noreferrer",
                                                ƒ: true,
                                                className: "boton_como_llegar",
                                                children: "C\xf3mo llegar"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: `tel:${showInfo.telefono}`,
                                                className: "telefono_popup",
                                                title: "texto",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "Llamar: "
                                                    }),
                                                    showInfo.telefono
                                                ]
                                            })
                                        ]
                                    })
                                }) : null
                            }, marker.id))
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Mapa_Mapa = (Mapa);

;// CONCATENATED MODULE: ./src/pages/index.js










function Home({ dataIdWp , markers  }) {
    const api = "pk.eyJ1IjoicXVpY2tnb2wiLCJhIjoiY2xhbGNvcHAyMDRyNjNwbWthcm1zMm9nbyJ9.tmZYhqn4Z6U3fcCZH647Zw";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Create Next App"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Home_module_default()).main,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_Breadcrumbs, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_1_Section_uno, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_2_SectionDos, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_3_SectionTres, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_4_SectionCuatro, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Mapa_Mapa, {
                        markers: markers,
                        api: api
                    })
                ]
            })
        ]
    });
}
const idWp = "13848";
async function getStaticProps() {
    const response = await fetch(`https://quickgold.es/wp-json/wp/v2/pages/${idWp}`);
    const dataIdWp = await response.json();
    const marker = await fetch(`https://quickgold.es/markers.json`);
    const markers = await marker.json();
    // Pass data to the page via props
    return {
        props: {
            dataIdWp,
            markers
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,675], () => (__webpack_exec__(489)));
module.exports = __webpack_exports__;

})();