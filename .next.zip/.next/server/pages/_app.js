(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 657:
/***/ ((module) => {

// Exports
module.exports = {
	"botonLlamar": "botonLamarFijo_botonLlamar__ywd7X"
};


/***/ }),

/***/ 459:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "header_header__m90mM",
	"contenedorLogo": "header_contenedorLogo__A23yT",
	"contenedorMenuSticky": "header_contenedorMenuSticky__cMMAA",
	"contenedorMenu": "header_contenedorMenu__8QZ3M",
	"contenedorRedes": "header_contenedorRedes___aLiz",
	"botonLlamar": "header_botonLlamar__kG7iW",
	"headersticky": "header_headersticky__AyGyP",
	"contenedorIconos": "header_contenedorIconos__CtQpt",
	"linkedin": "header_linkedin__ZUB84",
	"vector": "header_vector__mz4tH"
};


/***/ }),

/***/ 420:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorFooter": "footer_contenedorFooter__dIRp5",
	"contenedorContenidoFooter": "footer_contenedorContenidoFooter__bZfry",
	"contenedorEnlaces": "footer_contenedorEnlaces__Swl9R",
	"enlaces": "footer_enlaces__ryhqp",
	"iconosRedes": "footer_iconosRedes__2_GQ_",
	"twitter": "footer_twitter__ObDwB",
	"politicaPrivacidad": "footer_politicaPrivacidad__a3_VZ",
	"linea": "footer_linea__9g7KO",
	"registro": "footer_registro__Btk3v"
};


/***/ }),

/***/ 88:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor": "layout_contenedor__ry__i"
};


/***/ }),

/***/ 283:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/styles/globals.css
var globals = __webpack_require__(108);
// EXTERNAL MODULE: ./src/componentes/Layout/layout.module.css
var layout_module = __webpack_require__(88);
var layout_module_default = /*#__PURE__*/__webpack_require__.n(layout_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./src/componentes/Cabecera/header.module.css
var header_module = __webpack_require__(459);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
;// CONCATENATED MODULE: external "@mui/icons-material/LinkedIn"
const LinkedIn_namespaceObject = require("@mui/icons-material/LinkedIn");
var LinkedIn_default = /*#__PURE__*/__webpack_require__.n(LinkedIn_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Facebook"
const Facebook_namespaceObject = require("@mui/icons-material/Facebook");
var Facebook_default = /*#__PURE__*/__webpack_require__.n(Facebook_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Instagram"
const Instagram_namespaceObject = require("@mui/icons-material/Instagram");
var Instagram_default = /*#__PURE__*/__webpack_require__.n(Instagram_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/KeyboardArrowDown"
const KeyboardArrowDown_namespaceObject = require("@mui/icons-material/KeyboardArrowDown");
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_namespaceObject);
;// CONCATENATED MODULE: ./src/utilities/useSticky.js

const useSticky = ()=>{
    const stickyRef = (0,external_react_.useRef)(null);
    const [sticky, setSticky] = (0,external_react_.useState)(false);
    const [offset, setOffset] = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        if (!stickyRef.current) {
            return;
        }
        setOffset(stickyRef.current.offsetTop);
    }, [
        stickyRef,
        setOffset
    ]);
    (0,external_react_.useEffect)(()=>{
        const handleScroll = ()=>{
            if (!stickyRef.current) {
                return;
            }
            setSticky(window.scrollY > offset);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, [
        setSticky,
        stickyRef,
        offset
    ]);
    return {
        stickyRef,
        sticky
    };
};
/* harmony default export */ const utilities_useSticky = (useSticky);

;// CONCATENATED MODULE: ./src/componentes/Cabecera/Header.js



//import Image from "next/image";





const Header = ()=>{
    const { sticky , stickyRef  } = utilities_useSticky();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: (header_module_default()).header,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: (header_module_default()).contenedorLogo,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/",
                            title: "texto",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/logo.png",
                                alt: "Quickgold Logo",
                                className: (header_module_default()).logo,
                                width: 163,
                                height: 30
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (header_module_default()).contenedorRedes,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (header_module_default()).contenedorIconos,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: (header_module_default()).linkedin,
                                        href: "/",
                                        title: "texto",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/Vector12.png",
                                                alt: "Quickgold Logo",
                                                className: (header_module_default()).vector
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((LinkedIn_default()), {})
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/",
                                        title: "texto",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Facebook_default()), {})
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/",
                                        title: "texto",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Instagram_default()), {})
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (header_module_default()).botonLlamar,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "tel:900 373 629",
                                    title: "texto",
                                    children: "LLAMA GRATIS AL 900 373 629"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                ref: stickyRef,
                className: sticky ? `${(header_module_default()).contenedorMenuSticky} ${(header_module_default()).headersticky}` : `${(header_module_default()).contenedorMenu}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: (header_module_default()).contenedorMenu,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/",
                                title: "texto",
                                children: "Compro Oro"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/",
                                title: "texto",
                                children: "Cambio de divisas"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/",
                                title: "texto",
                                children: "Empe\xf1o de joyas"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                title: "texto",
                                children: [
                                    "Otros servicios ",
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                title: "texto",
                                children: [
                                    "Tiendas ",
                                    /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Cabecera_Header = (Header);

// EXTERNAL MODULE: ./src/componentes/Footer/footer.module.css
var footer_module = __webpack_require__(420);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
;// CONCATENATED MODULE: external "@mui/icons-material/Twitter"
const Twitter_namespaceObject = require("@mui/icons-material/Twitter");
var Twitter_default = /*#__PURE__*/__webpack_require__.n(Twitter_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Lock"
const Lock_namespaceObject = require("@mui/icons-material/Lock");
var Lock_default = /*#__PURE__*/__webpack_require__.n(Lock_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/CheckCircle"
const CheckCircle_namespaceObject = require("@mui/icons-material/CheckCircle");
var CheckCircle_default = /*#__PURE__*/__webpack_require__.n(CheckCircle_namespaceObject);
;// CONCATENATED MODULE: ./src/componentes/Footer/Footer.js









const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: (footer_module_default()).contenedorFooter,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (footer_module_default()).contenedorContenidoFooter,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "/",
                        title: "texto",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/logo.png",
                            alt: "Quickgold Logo",
                            className: (footer_module_default()).logo,
                            width: 221,
                            height: 42
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (footer_module_default()).contenedorEnlaces,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).enlaces,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "servicios"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Compra de oro",
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "texto",
                                                href: "/",
                                                children: "Compra de divisas"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Compra de plata",
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Compra de diamantes",
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Oro de inversi\xf3n",
                                                    " "
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).enlaces,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "acerca de nosotros"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "texto",
                                                href: "/",
                                                children: "Conoce Quickgold"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "texto",
                                                href: "/",
                                                children: "Preguntas frecuentes"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Localizador de tiendas",
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Mapa del sitio",
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Contacto",
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Blog",
                                                    " "
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).enlaces,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "\xfanete a quickgold"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "texto",
                                                href: "/",
                                                children: "Abrir un tienda Quickgold"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Dossier Franquicia",
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                title: "texto",
                                                href: "/",
                                                children: [
                                                    "Trabaja con nosotros",
                                                    " "
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).enlaces,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Llama gratis al"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "te:900 373 629",
                                    children: "900 373 629"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (footer_module_default()).iconosRedes,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            title: "texto",
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((LinkedIn_default()), {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            title: "texto",
                                            className: (footer_module_default()).twitter,
                                            href: "",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Twitter_default()), {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            title: "texto",
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Facebook_default()), {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            title: "texto",
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Instagram_default()), {})
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (footer_module_default()).politicaPrivacidad,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            title: "texto",
                            href: "/",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Lock_default()), {}),
                                    " pol\xedtica de privacidad"
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            title: "texto",
                            href: "/",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((CheckCircle_default()), {}),
                                    "pol\xedtica de calidad"
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: (footer_module_default()).linea
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: (footer_module_default()).registro,
                    children: "\xa9 2023 Quickgold | GRUNGO, S.L. - B53910071 - RONDA AUGUSTE Y LOUIS LUMIERE, 23, NAVE 9 46980 PATERNA, VALENCIA - central@quickgold.es - 900 373 629 Registro Mercantil de Valencia , Tomo 9220, Libro 6503, Folio 215, Hoja V-140170, Inscripci\xf3n 2\xaa."
                })
            ]
        })
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

// EXTERNAL MODULE: ./src/componentes/BotonLlamarFijo/botonLamarFijo.module.css
var botonLamarFijo_module = __webpack_require__(657);
var botonLamarFijo_module_default = /*#__PURE__*/__webpack_require__.n(botonLamarFijo_module);
;// CONCATENATED MODULE: ./src/componentes/BotonLlamarFijo/BotonLamarFijo.js



const BotonLamarFijo = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (botonLamarFijo_module_default()).botonLlamar,
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            title: "texto",
            href: "tel:900 373 629",
            children: "LLAMAR A 900 373 629"
        })
    });
};
/* harmony default export */ const BotonLlamarFijo_BotonLamarFijo = (BotonLamarFijo);

;// CONCATENATED MODULE: ./src/componentes/Layout/Layout.js





function Layout({ children  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
            className: (layout_module_default()).contenedor,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Cabecera_Header, {}),
                children,
                /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(BotonLlamarFijo_BotonLamarFijo, {})
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/pages/_app.js



function App({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Layout, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}


/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(283));
module.exports = __webpack_exports__;

})();