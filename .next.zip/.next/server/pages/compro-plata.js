(() => {
var exports = {};
exports.id = 9080;
exports.ids = [9080];
exports.modules = {

/***/ 1591:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueDer": "selecCiudad_bloqueDer__IRNfI",
	"contenidoBloqueDer": "selecCiudad_contenidoBloqueDer__1Zw0P",
	"linea": "selecCiudad_linea__fXlOm",
	"bloqueSuperiorTexto": "selecCiudad_bloqueSuperiorTexto__1kXEb",
	"bloqueIzqInferior": "selecCiudad_bloqueIzqInferior__KwLqO",
	"bloqueInferior": "selecCiudad_bloqueInferior__erJqZ",
	"bloqueInferiorTexto1": "selecCiudad_bloqueInferiorTexto1__W9_ob",
	"bloqueInferiorTexto2": "selecCiudad_bloqueInferiorTexto2___3Qzl",
	"bloqueInferiorTexto3": "selecCiudad_bloqueInferiorTexto3__sUo0T",
	"ContenedorSelect": "selecCiudad_ContenedorSelect__iBxv2",
	"select": "selecCiudad_select__eLpdS",
	"botonIrCiudad": "selecCiudad_botonIrCiudad__gyZGT",
	"bloqueInferiorTexto4": "selecCiudad_bloqueInferiorTexto4__0fqTl",
	"botonLlamar": "selecCiudad_botonLlamar__v9rUQ"
};


/***/ }),

/***/ 9685:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionUno": "section_uno_contenedorSectionUno__6Uh52",
	"linea": "section_uno_linea__AtAot",
	"bloqueIzq": "section_uno_bloqueIzq__OW4MR",
	"bloqueDer": "section_uno_bloqueDer__hz272",
	"botones": "section_uno_botones__t_oTm",
	"botonPopUp": "section_uno_botonPopUp__M1mDT",
	"imagenPlata": "section_uno_imagenPlata__gDk7v"
};


/***/ }),

/***/ 2250:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionDos": "sectionDos_contenedorSectionDos__knVDp",
	"bloqueInferior": "sectionDos_bloqueInferior__y5Sdy",
	"bloqueSuperior": "sectionDos_bloqueSuperior__7YGfP",
	"imagenventaja1": "sectionDos_imagenventaja1__4X73_",
	"contenedorVentajas": "sectionDos_contenedorVentajas__qc1o0",
	"linea": "sectionDos_linea__e_WO9"
};


/***/ }),

/***/ 376:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionTresMargen": "sectionTres_contenedorSectionTresMargen__rlY_e",
	"bloqueIzq": "sectionTres_bloqueIzq__qTtqW",
	"bloqueDer": "sectionTres_bloqueDer__IBB0F",
	"contenidoBloqueDer": "sectionTres_contenidoBloqueDer__CrT7q",
	"linea": "sectionTres_linea__Tdbzw",
	"bloqueSuperiorTexto": "sectionTres_bloqueSuperiorTexto__5TUtF",
	"bloqueIzqInferior": "sectionTres_bloqueIzqInferior__Bboqr",
	"telefono": "sectionTres_telefono__xJO1E"
};


/***/ }),

/***/ 5366:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCinco": "sectionCuatro_contenedorSectionCinco__b0QAu",
	"sectionCincoContenido": "sectionCuatro_sectionCincoContenido___REHh",
	"contenedorSectionCincoMargen": "sectionCuatro_contenedorSectionCincoMargen__iEL05",
	"linea": "sectionCuatro_linea__n_xXq",
	"contenidoCard": "sectionCuatro_contenidoCard__WbZpy"
};


/***/ }),

/***/ 6152:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCinco": "sectionSeis_contenedorSectionCinco__OzQmM",
	"bloqueInferior": "sectionSeis_bloqueInferior__3tPgO",
	"bloqueSuperior": "sectionSeis_bloqueSuperior__5h_nQ",
	"contenedorVentajas1": "sectionSeis_contenedorVentajas1__hLnqi",
	"contenedorVentajas2": "sectionSeis_contenedorVentajas2__eMHpQ",
	"contenedorVentajas3": "sectionSeis_contenedorVentajas3__jWQIi",
	"contenedorVentajas4": "sectionSeis_contenedorVentajas4__kMPFZ",
	"contenedorVentajas5": "sectionSeis_contenedorVentajas5__2uHuT",
	"contenedorVentajas6": "sectionSeis_contenedorVentajas6__2qgdg",
	"contenedorVentajas7": "sectionSeis_contenedorVentajas7__R2Lzw",
	"contenedorVentajas8": "sectionSeis_contenedorVentajas8__mo1Ef",
	"contenedorVentajas9": "sectionSeis_contenedorVentajas9__M8fQB",
	"linea": "sectionSeis_linea__IeZeZ"
};


/***/ }),

/***/ 6855:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionCincoMobil": "sectionSeisMobil_contenedorSectionCincoMobil__IHQ__",
	"bloqueInferior": "sectionSeisMobil_bloqueInferior__r3nUS",
	"bloqueSuperior": "sectionSeisMobil_bloqueSuperior__oA_RL",
	"imagenventaja1": "sectionSeisMobil_imagenventaja1__s8bFy",
	"contenedorVentajas": "sectionSeisMobil_contenedorVentajas__de5RQ",
	"linea": "sectionSeisMobil_linea__EAso1",
	"botones": "sectionSeisMobil_botones__lpKcA",
	"botonPopUp": "sectionSeisMobil_botonPopUp__aSKRI",
	"texto": "sectionSeisMobil_texto__19IW9"
};


/***/ }),

/***/ 8148:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorSectionSeis": "sectionSiete_contenedorSectionSeis__o6goM",
	"contenedorSectionSeisMargen": "sectionSiete_contenedorSectionSeisMargen__Yb2N6",
	"BannerSelectorCiudad": "sectionSiete_BannerSelectorCiudad__2bOlg",
	"tituloMobil": "sectionSiete_tituloMobil__sAaaN",
	"SelectCiudades": "sectionSiete_SelectCiudades__3hIu9",
	"contenedorTexto": "sectionSiete_contenedorTexto___1MTw",
	"contenedorTiposOro": "sectionSiete_contenedorTiposOro__i4p9n",
	"contenedorTiposOroCard1": "sectionSiete_contenedorTiposOroCard1__ybJsG",
	"contenedorTiposOroCard2": "sectionSiete_contenedorTiposOroCard2__yVbNF"
};


/***/ }),

/***/ 4031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ComproPlata),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/componentes/BreadcrumbsRaiz/Breadcrumbs.js
var Breadcrumbs = __webpack_require__(9206);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowRight"
var KeyboardArrowRight_ = __webpack_require__(547);
var KeyboardArrowRight_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowRight_);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(8874);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: ./src/componentes/Layout/Layout.js + 6 modules
var Layout = __webpack_require__(7699);
// EXTERNAL MODULE: external "@bradgarropy/next-seo"
var next_seo_ = __webpack_require__(4579);
var next_seo_default = /*#__PURE__*/__webpack_require__.n(next_seo_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/Compro-plata/Section_1/section_uno.module.css
var section_uno_module = __webpack_require__(9685);
var section_uno_module_default = /*#__PURE__*/__webpack_require__.n(section_uno_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
;// CONCATENATED MODULE: ./src/componentes/Compro-plata/Section_1/Section_uno.js





const Section_uno = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (section_uno_module_default()).contenedorSectionUno,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (section_uno_module_default()).bloqueIzq,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        children: [
                            "Tiendas compro plata ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (section_uno_module_default()).linea,
                                children: "quickgold"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "En quickgold compramos todo tipo de piezas de plata como joyas, monedas, elementos de decoraci\xf3n o cuberter\xedas y lingotes. Si tienes plata que quieras vender ven a cualquiera de nuestras tiendas y obt\xe9n dinero en efectivo por ellas. Garantizamos el mejor servicio y precio por tus piezas de plata"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (section_uno_module_default()).botones,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                to: "calculadoraOro",
                                smooth: true,
                                offset: -110,
                                spy: true,
                                duration: 500,
                                title: "texto",
                                passive: "true",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (section_uno_module_default()).botonPopUp,
                                    title: "texto",
                                    children: "CONOCE EL PRECIO DE LA PLATA"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (section_uno_module_default()).botonLlamar,
                                href: `tel:${ciudad?.acf?.telefono}`,
                                title: "Tel\xe9fono",
                                children: "llama gratis"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (section_uno_module_default()).bloqueDer,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/assets/img/imagenComproPlata.png",
                    alt: "Compro plata",
                    className: (section_uno_module_default()).imagenPlata,
                    width: 432,
                    height: 383,
                    priority: true
                })
            })
        ]
    });
};
/* harmony default export */ const Section_1_Section_uno = (Section_uno);

// EXTERNAL MODULE: ./src/componentes/Compro-plata/Section_2/sectionDos.module.css
var sectionDos_module = __webpack_require__(2250);
var sectionDos_module_default = /*#__PURE__*/__webpack_require__.n(sectionDos_module);
;// CONCATENATED MODULE: ./src/componentes/Compro-plata/Section_2/Section_dos.js




const Section_dos = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionDos_module_default()).contenedorSectionDos,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionDos_module_default()).bloqueSuperior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        children: [
                            "Disfruta de ventajas exclusivas en",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (sectionDos_module_default()).linea,
                                children: "quickgold"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "*Para realizar una venta de plata es necesario ser mayor de edad y aportar DNI en vigor."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionDos_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenventaja1.png",
                                    alt: "compro plata",
                                    width: 40,
                                    height: 42
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Mejor servicio y precio garantizado."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenventaja2.png",
                                    alt: "precio plata",
                                    width: 39,
                                    height: 36
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Precio de la plata siempre actualizado."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenventaja3.png",
                                    alt: "tiendas compro plata",
                                    width: 36,
                                    height: 36
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "M\xe1s de 50 tiendas para vender plata."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenventaja4.png",
                                    alt: "vender plata",
                                    width: 41,
                                    height: 32
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Atenci\xf3n personalizada."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenventaja5.png",
                                    alt: "compra de plata",
                                    width: 38,
                                    height: 38
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Dinero en efectivo al instante."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionDos_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionDos_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenventaja6.png",
                                    alt: "vender plata precio",
                                    width: 39,
                                    height: 39
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Tasaci\xf3n profesional, justa y segura."
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_2_Section_dos = (Section_dos);

// EXTERNAL MODULE: ./src/componentes/Compro-plata/Section_3/sectionTres.module.css
var sectionTres_module = __webpack_require__(376);
var sectionTres_module_default = /*#__PURE__*/__webpack_require__.n(sectionTres_module);
// EXTERNAL MODULE: ./src/componentes/Compro-plata/ComponenteSelectCiudades/selecCiudad.module.css
var selecCiudad_module = __webpack_require__(1591);
var selecCiudad_module_default = /*#__PURE__*/__webpack_require__.n(selecCiudad_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/componentes/Compro-plata/ComponenteSelectCiudades/SelectCiudad.js




const SelectCiudad = ({ listadoUrlCiudad , ciudad  })=>{
    const [urlSelect, setUrlSelect] = (0,external_react_.useState)("");
    const listadoCiudades = listadoUrlCiudad?.arrayMarker;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "calculadoraOro",
        className: (selecCiudad_module_default()).bloqueDer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (selecCiudad_module_default()).bloqueSuperiorTexto,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Precio de la plata"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "\xbfCu\xe1nto cuesta ahora la plata?"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (selecCiudad_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto1,
                        children: "\xbfTe gustar\xeda conocer el precio de la plata?"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto3,
                        children: [
                            "Selecciona tu ciudad y haz clic en",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "conoce el precio de la plata para saberlo."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (selecCiudad_module_default()).ContenedorSelect,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                onChange: (e)=>{
                                    setUrlSelect(e.target.value);
                                },
                                className: (selecCiudad_module_default()).select,
                                children: listadoCiudades?.map((ciudad, i)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: ciudad.nombreMinusculas,
                                        children: ciudad.nombre
                                    }, i))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                className: (selecCiudad_module_default()).botonIrCiudad,
                                href: `/tiendas/compro-oro-${urlSelect}`,
                                children: "CONOCE EL PRECIO DE LA PLATA"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (selecCiudad_module_default()).bloqueInferiorTexto4,
                        children: "Si lo prefieres, tambi\xe9n puedes llamarnos e informarte. \xa1Estaremos encantados de resolver todas tus dudas!"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: `tel:${ciudad?.acf?.telefono}`,
                        className: (selecCiudad_module_default()).botonLlamar,
                        children: "LLAMA GRATIS"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ComponenteSelectCiudades_SelectCiudad = (SelectCiudad);

;// CONCATENATED MODULE: ./src/componentes/Compro-plata/Section_3/Section_tres.js





const Section_tres = ({ ciudad , listadoUrlCiudad  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (sectionTres_module_default()).contenedorSectionTres,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (sectionTres_module_default()).contenedorSectionTresMargen,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionTres_module_default()).bloqueIzq,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                            children: [
                                "Vender plata en ",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (sectionTres_module_default()).linea,
                                    children: "quickgold"
                                }),
                                " es f\xe1cil"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Al igual que con cualquier otro metal precioso, el precio de la plata var\xeda en el tiempo seg\xfan ciertos criterios como: el peso o la pureza. Por eso es necesario realizar una tasaci\xf3n previa a la venta de plata."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Nuestro equipo cualificado ser\xe1 el encargado de realizar todas las pruebas necesarias para fijar el precio de las piezas. \xc9stas se realizan, como siempre, a la vista del cliente y se complementan aportando toda la informaci\xf3n precisa por cada paso que van dando."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            children: [
                                "Obt\xe9n r\xe1pidamente dinero extra al vender tus piezas de plata en Quickgold, puedes fijar el precio de venta directamente llam\xe1ndonos gratuitamente al",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (sectionTres_module_default()).telefono,
                                    href: `tel:${ciudad?.acf?.telefono}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: ciudad?.acf?.telefono
                                    })
                                }),
                                ", estaremos encantados de atenderte."
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (sectionTres_module_default()).bloqueIzqInferior,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Ven a cualquier tienda quickgold sin necesidad de cita previa, estaremos encantados de atenderte y ayudarte en la venta de tus piezas de plata."
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ComponenteSelectCiudades_SelectCiudad, {
                    listadoUrlCiudad: listadoUrlCiudad
                })
            ]
        })
    });
};
/* harmony default export */ const Section_3_Section_tres = (Section_tres);

// EXTERNAL MODULE: ./src/componentes/Compro-plata/Section_4/sectionCuatro.module.css
var sectionCuatro_module = __webpack_require__(5366);
var sectionCuatro_module_default = /*#__PURE__*/__webpack_require__.n(sectionCuatro_module);
;// CONCATENATED MODULE: ./src/componentes/Compro-plata/Section_4/Section_cuatro.js



const Section_cuatro = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionCuatro_module_default()).contenedorSectionCinco,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (sectionCuatro_module_default()).contenedorSectionCincoMargen,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                    children: [
                        "C\xf3mo vender plata en ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (sectionCuatro_module_default()).linea,
                            children: "quickgold"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionCuatro_module_default()).sectionCincoContenido,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCuatro_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Pesaje"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Todas las piezas se pesan a la vista de nuestros clientes en balanzas homologadas y certificadas por el Ministerio de Industria."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCuatro_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Comprobaci\xf3n"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "La pureza de la plata viene determinada por los contrastes que se pueden encontrar en las propias piezas. Estas son visibles a simple vista."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCuatro_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Importe a pagar"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "En caso de haber fijado precio, se pagar\xe1n los gramos pesados por el peso fijado (para fijar precio, llame gratis al",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: `tel:${ciudad?.acf?.telefono}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: ciudad?.acf?.telefono
                                        })
                                    }),
                                    " ",
                                    "). En caso contrario, se aplicar\xe1 el precio publicado en el momento de la venta."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionCuatro_module_default()).contenidoCard,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "#4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Pago"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Tras esto, se proceder\xe1 al pago correspondiente a la venta de las piezas. Asimismo, en cumplimiento con la legislaci\xf3n vigente, se requerir\xe1 el DNI del cliente para dejar constancia de la venta. El pago puede realizarse en efectivo o por transferencia."
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_4_Section_cuatro = (Section_cuatro);

// EXTERNAL MODULE: ./src/componentes/Compro-plata/Section_6/sectionSeis.module.css
var sectionSeis_module = __webpack_require__(6152);
var sectionSeis_module_default = /*#__PURE__*/__webpack_require__.n(sectionSeis_module);
;// CONCATENATED MODULE: ./src/componentes/Compro-plata/Section_6/Section_seis.js




const Section_seis = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionSeis_module_default()).contenedorSectionCinco,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (sectionSeis_module_default()).bloqueSuperior,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    children: "\xbfPor qu\xe9 elegirnos?"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionSeis_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas1,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Recibo de compra con el precio y el peso desglosado"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas2,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Cumplimos la normativa de seguridad privada garantizando una custodia segura"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Precios publicados reales y actualizados cada 3 horas"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Protecci\xf3n de sus piezas mediante normas de seguridad exigidas por la jefatura de polic\xeda"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas5,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Comprobaci\xf3n y pesaje a la vista del cliente"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "B\xe1sculas homologadas por el ministerio de industria"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas7,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Profesionales formados y en constante formaci\xf3n"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas8,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Descartes seg\xfan cat\xe1logo de gemas"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (sectionSeis_module_default()).contenedorVentajas9,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Registro de todas las operaciones"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Section_6_Section_seis = (Section_seis);

// EXTERNAL MODULE: ./src/componentes/Compro-plata/Section_6_mobil/sectionSeisMobil.module.css
var sectionSeisMobil_module = __webpack_require__(6855);
var sectionSeisMobil_module_default = /*#__PURE__*/__webpack_require__.n(sectionSeisMobil_module);
;// CONCATENATED MODULE: ./src/componentes/Compro-plata/Section_6_mobil/Section_seis_mobil.js




const Section_seis_mobil = ({ ciudad  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (sectionSeisMobil_module_default()).contenedorSectionCincoMobil,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (sectionSeisMobil_module_default()).bloqueSuperior,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    children: "\xbfPor qu\xe9 elegirnos?"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (sectionSeisMobil_module_default()).bloqueInferior,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil1.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Recibo de compra con el precio y el peso desglosado."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil2.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Cumplimos la normativa de seguridad privada garantizando una custodia segura."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil3.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Precios publicados reales y actualizados cada 3 horas."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil4.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Protecci\xf3n de sus piezas mediante normas de seguridad exigidas por la jefatura de polic\xeda."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil5.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Comprobaciones y pesaje a la vista del cliente."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil6.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "B\xe1sculas homologadas por el ministerio de industria."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil7.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Profesionales formados y en constante formaci\xf3n."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil8.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Descartes seg\xfan cat\xe1logo de gemas."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (sectionSeisMobil_module_default()).contenedorVentajas,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (sectionSeisMobil_module_default()).imagenventaja1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/assets/img/imagenPorqueElegirnosMovil9.png",
                                    alt: "Mejor servicio y precio",
                                    width: 56,
                                    height: 56
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Registro de todas las operaciones."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: (sectionSeisMobil_module_default()).texto,
                children: "Informaci\xf3n de inter\xe9s"
            })
        ]
    });
};
/* harmony default export */ const Section_6_mobil_Section_seis_mobil = (Section_seis_mobil);

// EXTERNAL MODULE: ./src/componentes/Compro-plata/Section_7/sectionSiete.module.css
var sectionSiete_module = __webpack_require__(8148);
var sectionSiete_module_default = /*#__PURE__*/__webpack_require__.n(sectionSiete_module);
// EXTERNAL MODULE: ./src/componentes/SelectorCiudadesServicio/SelectorCiudadesServicio.js
var SelectorCiudadesServicio = __webpack_require__(5709);
;// CONCATENATED MODULE: ./src/componentes/Compro-plata/Section_7/Section_siete.js




const Section_siete = ({ ciudad , listadoCiudadesServicios  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (sectionSiete_module_default()).contenedorSectionSeis,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (sectionSiete_module_default()).contenedorSectionSeisMargen,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionSiete_module_default()).contenedorTexto,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            children: "Los contrastes de la plata"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "La plata como el oro tiene diferentes caracter\xedsticas que hace que se distingan diferentes tipolog\xedas, te indicamos las m\xe1s comunes."
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (sectionSiete_module_default()).contenedorTiposOro,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSiete_module_default()).contenedorTiposOroCard1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Plata 800 "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Este tipo contiene un 80% de plata y un 20% de otros metales. Se le conoce como “plata de segunda ley”. Se suele usar para cadenas por su resistencia."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSiete_module_default()).contenedorTiposOroCard2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Plata 925 o esterlina "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Est\xe1 formada por un 92,5% de plata que junto con otras fusiones le dan dureza para la elaboraci\xf3n de las joyas. Es la m\xe1s empleada y tambi\xe9n muy habitual en monedas de plata."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (sectionSiete_module_default()).contenedorTiposOroCard1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Plata 900 "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "No se puede obtener plata m\xe1s fina que esta. Es el tipo con mayor pureza con un 99,9% de plata. No se trabaja en joyer\xeda porque es blanda y se marca con facilidad."
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Section_7_Section_siete = (Section_siete);

;// CONCATENATED MODULE: ./src/pages/compro-plata/index.js














function ComproPlata({ menu_list , ciudad , listadoUrlCiudad  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((next_seo_default()), {
                title: ciudad?.acf?.titulo_del_meta,
                description: ciudad?.acf?.descripcion_del_meta,
                icon: "/favicon.png",
                facebook: {
                    image: "/facebook.png",
                    url: "https://www.facebook.com/quickgold.es/",
                    type: "article"
                },
                twitter: {
                    image: "/twitter.png",
                    site: "@quickgoldQG",
                    card: "summary_large_image"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet preload prefetch",
                        href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css",
                        as: "style"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("noscript", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("link", {
                            rel: "stylesheet",
                            href: "https://api.mapbox.com/mapbox-gl-js/v2.8.1/mapbox-gl.css"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
                menu_list: menu_list,
                ciudad: ciudad,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Home_module_default()).main,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs/* default */.Z, {
                                raiz: "Quickgold",
                                iconoRaiz: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {}),
                                urlUbicacionActual: "/compro-plata/",
                                iconoUbiccionActual: /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowRight_default()), {}),
                                ubicacionActual: "Compro Plata"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_1_Section_uno, {
                                ciudad: ciudad
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_3_Section_tres, {
                                ciudad: ciudad,
                                listadoUrlCiudad: listadoUrlCiudad
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Section_2_Section_dos, {
                                ciudad: ciudad
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_4_Section_cuatro, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_6_Section_seis, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_6_mobil_Section_seis_mobil, {
                        ciudad: ciudad
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Section_7_Section_siete, {
                        ciudad: ciudad
                    })
                ]
            })
        ]
    });
}
const idTienda = "comproplata";
const idPaginaWp = "377";
const apiGeneral = "13848";
//const idWp = "13848";
async function getStaticProps() {
    //datos de los campos personalizados de la ciudad
    const ciudad1 = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${idPaginaWp}`);
    const ciudad = await ciudad1.json();
    //fin datos de los campos personalizados de la ciudad
    const res = await fetch(`https://panel.quickgold.es/wp-json/acf/v3/pages/${apiGeneral}`);
    const Listado = await fetch(`https://panel.quickgold.es/ListadoDeUrlDeCiudad/listadoUrlCiudad.json`);
    const listadoUrlCiudad = await Listado.json();
    const general = await res.json();
    /*const response = await fetch(
    `https://quickgold.es/wp-json/wp/v2/pages/${idWp}`
  );
  const dataIdWp = await response.json();*/ const menu = await fetch(`https://panel.quickgold.es/wp-json/menus/v1/menus/2219`);
    const menu_list = await menu.json();
    return {
        props: {
            menu_list,
            ciudad,
            listadoUrlCiudad
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 4579:
/***/ ((module) => {

"use strict";
module.exports = require("@bradgarropy/next-seo");

/***/ }),

/***/ 6741:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CheckCircle");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 7666:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 547:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowRight");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 5939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LinkedIn");

/***/ }),

/***/ 2906:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 5631:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4180:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/SwipeableDrawer");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 5337:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll-to-top");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,5675,3573,676,1664,7699,5799,5709], () => (__webpack_exec__(4031)));
module.exports = __webpack_exports__;

})();